@echo off
setlocal
title Install Outline Glow
echo Installing Outline Glow for EffectCraft...
echo.
if not exist "%~dp01_Plugin\ec_outline_glow.wasm" (
  echo Could not find 1_Plugin\ec_outline_glow.wasm.
  echo Unzip the whole zip first, then double-click this file again.
  pause
  exit /b 1
)
set "PLUG=%APPDATA%\EffectCraft\Plug-ins"
if not exist "%PLUG%" mkdir "%PLUG%"
copy /Y "%~dp01_Plugin\ec_outline_glow.wasm" "%PLUG%\" >nul || goto fail
echo   Plug-in copied to:  %PLUG%
echo.
echo Done. Restart EffectCraft, then search "Outline Glow" in Effects ^& Presets.
echo.
pause
exit /b 0
:fail
echo.
echo Something went wrong while copying. Copy the files by hand: see INSTALL.txt.
pause
exit /b 1
