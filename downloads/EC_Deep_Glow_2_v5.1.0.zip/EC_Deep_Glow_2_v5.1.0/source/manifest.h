/* generated from manifest.json by gen_manifest.py */
#define K_hdr_main 0
#define K_glow_mode 1
#define K_blend 2
#define K_radius 3
#define K_exposure 4
#define K_intensity 5
#define K_falloff 6
#define K_iris_quality 7
#define K_iris_iterations 8
#define K_iris_easing 9
#define K_iris_blades 10
#define K_iris_rotation 11
#define K_iris_opacity 12
#define K_iris_aspect 13
#define K_iris_continuous 14
#define K_hdr_input 15
#define K_threshold 16
#define K_softness 17
#define K_thr_mode 18
#define K_sat_bias 19
#define K_hdr_style 20
#define K_gamma 21
#define K_aspect 22
#define K_angle_enable 23
#define K_angle 24
#define K_chroma 25
#define K_ca_mode 26
#define K_pixel_channels 27
#define K_radius_r 28
#define K_radius_g 29
#define K_radius_b 30
#define K_ab_order 31
#define K_tint_style 32
#define K_tint_blend 33
#define K_tint_inner 34
#define K_tint_outer 38
#define K_tint_strength 42
#define K_tint_amount 43
#define K_tint_low 44
#define K_tint_mid 48
#define K_tint_high 52
#define K_tonemap 56
#define K_tm_mix 57
#define K_dither 58
#define K_dither_mono 59
#define K_dirt_amount 60
#define K_dirt_inherit 61
#define K_dirt_exposure 62
#define K_dirt_gamma 63
#define K_dirt_scale 64
#define K_dirt_contrast 65
#define K_dirt_seed 66
#define K_hdr_quality 67
#define K_quality 68
#define K_q_downsample 69
#define K_q_steps 70
#define K_q_iterations 71
#define K_half_float 72
#define K_hdr_view 73
#define K_view 74
#define K_src_opacity 75
#define K_unmult 76
#define K_glow_only 77
#define N_SLOTS 78
static const char MANIFEST[] =
  "{\"api\": 1, \"id\": \"org.effectcraft.open.deep-glow-2\", \"name\": \"EC Deep Glow 2\", \""
  "category\": \"Stylize\", \"version\": \"5.1.0\", \"author\": \"Original implementation\", \""
  "description\": \"Physically-based multi-scale glow: inverse-square, exponential or"
  " procedural lens-iris kernel fitted to an anisotropic Gaussian pyramid; per-chan"
  "nel radius and dispersion, rotatable aspect, saturation bias, HDR-safe threshold"
  "/blend/tonemap, inner/outer tint, lens dirt, unmult.\", \"params\": [{\"id\": \"hdr_ma"
  "in\", \"name\": \"=== MAIN ===\", \"type\": \"checkbox\", \"default\": false}, {\"id\": \"glow"
  "_mode\", \"name\": \"Glow Mode\", \"type\": \"popup\", \"default\": 0, \"options\": [\"Exponen"
  "tial\", \"Pure Exponential\", \"Lens Iris\"]}, {\"id\": \"blend\", \"name\": \"Blend Mode\", "
  "\"type\": \"popup\", \"default\": 0, \"options\": [\"Screen\", \"Add\", \"Normal\", \"Lighten\","
  " \"Color Dodge\", \"Linear Dodge\", \"Overlay\", \"Soft Light\"]}, {\"id\": \"radius\", \"nam"
  "e\": \"Radius\", \"type\": \"slider\", \"default\": 300, \"min\": 1, \"max\": 5000, \"decimals"
  "\": 1, \"sliderMax\": 1000}, {\"id\": \"exposure\", \"name\": \"Exposure\", \"type\": \"slider"
  "\", \"default\": 1.5, \"min\": -8, \"max\": 12, \"decimals\": 2, \"sliderMax\": 6}, {\"id\": "
  "\"intensity\", \"name\": \"Intensity\", \"type\": \"slider\", \"default\": 100, \"min\": 0, \"m"
  "ax\": 1000, \"decimals\": 1, \"sliderMax\": 300}, {\"id\": \"falloff\", \"name\": \"Falloff\""
  ", \"type\": \"slider\", \"default\": 2.0, \"min\": 0.25, \"max\": 4, \"decimals\": 2}, {\"id\""
  ": \"iris_quality\", \"name\": \"Iris Sampling Quality\", \"type\": \"popup\", \"default\": 1"
  ", \"options\": [\"Low\", \"Standard\", \"High\"]}, {\"id\": \"iris_iterations\", \"name\": \"Ir"
  "is Iterations\", \"type\": \"slider\", \"default\": 16, \"min\": 1, \"max\": 64, \"decimals\""
  ": 0, \"sliderMax\": 64}, {\"id\": \"iris_easing\", \"name\": \"Radii Easing\", \"type\": \"sl"
  "ider\", \"default\": 50, \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\""
  "id\": \"iris_blades\", \"name\": \"Iris Blades\", \"type\": \"slider\", \"default\": 6, \"min\""
  ": 0, \"max\": 16, \"decimals\": 0, \"sliderMax\": 16}, {\"id\": \"iris_rotation\", \"name\":"
  " \"Iris Rotation\", \"type\": \"slider\", \"default\": 0, \"min\": -360, \"max\": 360, \"deci"
  "mals\": 1, \"sliderMax\": 360}, {\"id\": \"iris_opacity\", \"name\": \"Iris Opacity\", \"typ"
  "e\": \"slider\", \"default\": 100, \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": "
  "100}, {\"id\": \"iris_aspect\", \"name\": \"Iris Aspect Ratio\", \"type\": \"slider\", \"defa"
  "ult\": 1.0, \"min\": 0.1, \"max\": 10, \"decimals\": 3}, {\"id\": \"iris_continuous\", \"nam"
  "e\": \"Continuous Rasterization\", \"type\": \"checkbox\", \"default\": true}, {\"id\": \"hd"
  "r_input\", \"name\": \"=== INPUT ===\", \"type\": \"checkbox\", \"default\": false}, {\"id\":"
  " \"threshold\", \"name\": \"Threshold\", \"type\": \"slider\", \"default\": 35, \"min\": 0, \"m"
  "ax\": 400, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"softness\", \"name\": \"Threshol"
  "d Smooth\", \"type\": \"slider\", \"default\": 50, \"min\": 0, \"max\": 100, \"decimals\": 1,"
  " \"sliderMax\": 100}, {\"id\": \"thr_mode\", \"name\": \"Threshold Mode\", \"type\": \"popup\""
  ", \"default\": 0, \"options\": [\"Luminance\", \"Chrominance\"]}, {\"id\": \"sat_bias\", \"na"
  "me\": \"Saturation Bias\", \"type\": \"slider\", \"default\": 0, \"min\": 0, \"max\": 100, \"d"
  "ecimals\": 1, \"sliderMax\": 100}, {\"id\": \"hdr_style\", \"name\": \"=== STYLE ===\", \"ty"
  "pe\": \"checkbox\", \"default\": false}, {\"id\": \"gamma\", \"name\": \"Gamma Correction\", "
  "\"type\": \"slider\", \"default\": 1.0, \"min\": 0.2, \"max\": 5, \"decimals\": 2}, {\"id\": \""
  "aspect\", \"name\": \"Aspect Ratio\", \"type\": \"slider\", \"default\": 1.0, \"min\": 0.1, \""
  "max\": 10, \"decimals\": 3}, {\"id\": \"angle_enable\", \"name\": \"Enable Angle\", \"type\":"
  " \"checkbox\", \"default\": false}, {\"id\": \"angle\", \"name\": \"Angle\", \"type\": \"slider"
  "\", \"default\": 0, \"min\": -360, \"max\": 360, \"decimals\": 1, \"sliderMax\": 360}, {\"id"
  "\": \"chroma\", \"name\": \"Chromatic Aberration\", \"type\": \"slider\", \"default\": 0, \"mi"
  "n\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"ca_mode\", \"name\": \""
  "Aberration Mode\", \"type\": \"popup\", \"default\": 0, \"options\": [\"Radius Offset\", \"P"
  "ixel Offset\", \"Both\"]}, {\"id\": \"pixel_channels\", \"name\": \"Aberration Channels\", "
  "\"type\": \"popup\", \"default\": 0, \"options\": [\"Red & Blue\", \"Red & Green\", \"Green &"
  " Blue\", \"Red\", \"Green\", \"Blue\"]}, {\"id\": \"radius_r\", \"name\": \"Multiply Red\", \"ty"
  "pe\": \"slider\", \"default\": 1.0, \"min\": 0.01, \"max\": 8, \"decimals\": 3}, {\"id\": \"ra"
  "dius_g\", \"name\": \"Multiply Green\", \"type\": \"slider\", \"default\": 1.0, \"min\": 0.01"
  ", \"max\": 8, \"decimals\": 3}, {\"id\": \"radius_b\", \"name\": \"Multiply Blue\", \"type\": "
  "\"slider\", \"default\": 1.0, \"min\": 0.01, \"max\": 8, \"decimals\": 3}, {\"id\": \"ab_orde"
  "r\", \"name\": \"Shuffle Channels\", \"type\": \"popup\", \"default\": 0, \"options\": [\"RGB\""
  ", \"RBG\", \"GRB\", \"GBR\", \"BRG\", \"BGR\"]}, {\"id\": \"tint_style\", \"name\": \"Tint Mode\","
  " \"type\": \"popup\", \"default\": 0, \"options\": [\"3-Tone\", \"Inner & Outer\"]}, {\"id\": "
  "\"tint_blend\", \"name\": \"Tint Blend Mode\", \"type\": \"popup\", \"default\": 0, \"options"
  "\": [\"Multiply\", \"Normal\", \"Add\", \"Screen\", \"Overlay\", \"Soft Light\"]}, {\"id\": \"ti"
  "nt_inner\", \"name\": \"Color Inner\", \"type\": \"color\", \"default\": [1.0, 0.9, 0.7, 1."
  "0]}, {\"id\": \"tint_outer\", \"name\": \"Color Outer\", \"type\": \"color\", \"default\": [0."
  "6, 0.4, 1.0, 1.0]}, {\"id\": \"tint_strength\", \"name\": \"Tint Strength\", \"type\": \"sl"
  "ider\", \"default\": 100, \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {"
  "\"id\": \"tint_amount\", \"name\": \"Tint Amount (3-Tone)\", \"type\": \"slider\", \"default\""
  ": 0, \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"tint_low\", "
  "\"name\": \"Tint Low\", \"type\": \"color\", \"default\": [1.0, 0.45, 0.1, 1.0]}, {\"id\": \""
  "tint_mid\", \"name\": \"Tint Mid\", \"type\": \"color\", \"default\": [1.0, 0.75, 0.45, 1.0"
  "]}, {\"id\": \"tint_high\", \"name\": \"Tint High\", \"type\": \"color\", \"default\": [1.0, 0"
  ".95, 0.85, 1.0]}, {\"id\": \"tonemap\", \"name\": \"Tone Mapping\", \"type\": \"popup\", \"de"
  "fault\": 0, \"options\": [\"None\", \"Reinhard\", \"ACES\", \"Filmic\", \"Reinhard 2\", \"Lott"
  "es\"]}, {\"id\": \"tm_mix\", \"name\": \"Tone Mapping Mix\", \"type\": \"slider\", \"default\":"
  " 100, \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"dither\", \""
  "name\": \"Dither\", \"type\": \"slider\", \"default\": 100, \"min\": 0, \"max\": 100, \"decima"
  "ls\": 1, \"sliderMax\": 100}, {\"id\": \"dither_mono\", \"name\": \"Dither Monochromatic\","
  " \"type\": \"checkbox\", \"default\": true}, {\"id\": \"dirt_amount\", \"name\": \"Lens Dirt "
  "Opacity\", \"type\": \"slider\", \"default\": 0, \"min\": 0, \"max\": 100, \"decimals\": 1, \""
  "sliderMax\": 100}, {\"id\": \"dirt_inherit\", \"name\": \"Inherit Glow Color\", \"type\": \""
  "slider\", \"default\": 100, \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100},"
  " {\"id\": \"dirt_exposure\", \"name\": \"Matte Exposure\", \"type\": \"slider\", \"default\": "
  "0, \"min\": -6, \"max\": 6, \"decimals\": 2, \"sliderMax\": 6}, {\"id\": \"dirt_gamma\", \"na"
  "me\": \"Matte Gamma\", \"type\": \"slider\", \"default\": 1.0, \"min\": 0.1, \"max\": 6, \"dec"
  "imals\": 2}, {\"id\": \"dirt_scale\", \"name\": \"Lens Dirt Scale\", \"type\": \"slider\", \"d"
  "efault\": 1.0, \"min\": 0.05, \"max\": 10, \"decimals\": 2}, {\"id\": \"dirt_contrast\", \"n"
  "ame\": \"Lens Dirt Contrast\", \"type\": \"slider\", \"default\": 1.0, \"min\": 0.05, \"max\""
  ": 8, \"decimals\": 2}, {\"id\": \"dirt_seed\", \"name\": \"Lens Dirt Seed\", \"type\": \"slid"
  "er\", \"default\": 1, \"min\": 1, \"max\": 9999, \"decimals\": 0, \"sliderMax\": 100}, {\"id"
  "\": \"hdr_quality\", \"name\": \"=== QUALITY ===\", \"type\": \"checkbox\", \"default\": fals"
  "e}, {\"id\": \"quality\", \"name\": \"Quality Preset\", \"type\": \"popup\", \"default\": 2, \""
  "options\": [\"Draft\", \"Low\", \"Medium\", \"Standard\", \"High\", \"Extreme\", \"Custom\"]}, "
  "{\"id\": \"q_downsample\", \"name\": \"Downsampling\", \"type\": \"slider\", \"default\": 0, \""
  "min\": 0, \"max\": 6, \"decimals\": 0, \"sliderMax\": 6}, {\"id\": \"q_steps\", \"name\": \"Gl"
  "ow Steps Multiplier\", \"type\": \"slider\", \"default\": 3, \"min\": 1, \"max\": 8, \"decim"
  "als\": 0, \"sliderMax\": 8}, {\"id\": \"q_iterations\", \"name\": \"Iterations\", \"type\": \""
  "slider\", \"default\": 15, \"min\": 1, \"max\": 15, \"decimals\": 0, \"sliderMax\": 15}, {\""
  "id\": \"half_float\", \"name\": \"Half Float\", \"type\": \"checkbox\", \"default\": false}, "
  "{\"id\": \"hdr_view\", \"name\": \"=== VIEW ===\", \"type\": \"checkbox\", \"default\": false}"
  ", {\"id\": \"view\", \"name\": \"View\", \"type\": \"popup\", \"default\": 0, \"options\": [\"Fin"
  "al Result\", \"Glow Only\", \"Glow Input\"]}, {\"id\": \"src_opacity\", \"name\": \"Source O"
  "pacity\", \"type\": \"slider\", \"default\": 100, \"min\": 0, \"max\": 100, \"decimals\": 1, "
  "\"sliderMax\": 100}, {\"id\": \"unmult\", \"name\": \"Unmult (Required for Alpha)\", \"type"
  "\": \"checkbox\", \"default\": true}, {\"id\": \"glow_only\", \"name\": \"Glow Only (Legacy)"
  "\", \"type\": \"checkbox\", \"default\": false}]}"
;
#define MANIFEST_LEN ((int)(sizeof(MANIFEST)-1))
