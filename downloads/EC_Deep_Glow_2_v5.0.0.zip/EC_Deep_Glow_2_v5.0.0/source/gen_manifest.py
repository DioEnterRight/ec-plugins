#!/usr/bin/env python3
"""manifest.json -> manifest.h  (run before build.sh)
Emits the manifest string and one K_<id> define per parameter: its slot in the host's flat parameter array
(colour parameters take 4 slots).  The C code reads parameters through K_<id>, so the control panel can be
reordered by editing manifest.json only."""
import json
m = json.load(open('manifest.json'))
s = json.dumps(m, separators=(', ', ': '))
esc = lambda t: t.replace('\\', '\\\\').replace('"', '\\"')
with open('manifest.h', 'w') as f:
    f.write('/* generated from manifest.json by gen_manifest.py */\n')
    i = 0
    for p in m['params']:
        f.write('#define K_%s %d\n' % (p['id'], i))
        i += 4 if p['type'] == 'color' else 1
    f.write('#define N_SLOTS %d\n' % i)
    f.write('static const char MANIFEST[] =\n')
    for i in range(0, len(s), 80):
        f.write('  "%s"\n' % esc(s[i:i + 80]))
    f.write(';\n#define MANIFEST_LEN ((int)(sizeof(MANIFEST)-1))\n')
print(len(s), 'bytes,', len(m['params']), 'param entries')
