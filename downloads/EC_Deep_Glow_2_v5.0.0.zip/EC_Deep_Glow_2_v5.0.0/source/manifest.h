/* generated from manifest.json by gen_manifest.py */
#define K_glow_mode 0
#define K_blend 1
#define K_radius 2
#define K_exposure 3
#define K_intensity 4
#define K_falloff 5
#define K_threshold 6
#define K_thr_mode 7
#define K_softness 8
#define K_sat_bias 9
#define K_iris_quality 10
#define K_iris_iterations 11
#define K_iris_easing 12
#define K_iris_blades 13
#define K_iris_rotation 14
#define K_iris_opacity 15
#define K_iris_aspect 16
#define K_iris_continuous 17
#define K_gamma 18
#define K_aspect 19
#define K_angle_enable 20
#define K_angle 21
#define K_chroma 22
#define K_ca_mode 23
#define K_pixel_channels 24
#define K_radius_r 25
#define K_radius_g 26
#define K_radius_b 27
#define K_ab_order 28
#define K_tint_style 29
#define K_tint_blend 30
#define K_tint_inner 31
#define K_tint_outer 35
#define K_tint_strength 39
#define K_tint_amount 40
#define K_tint_low 41
#define K_tint_mid 45
#define K_tint_high 49
#define K_tonemap 53
#define K_tm_mix 54
#define K_dither 55
#define K_dither_mono 56
#define K_dirt_amount 57
#define K_dirt_inherit 58
#define K_dirt_exposure 59
#define K_dirt_gamma 60
#define K_dirt_scale 61
#define K_dirt_contrast 62
#define K_dirt_seed 63
#define K_quality 64
#define K_q_downsample 65
#define K_q_steps 66
#define K_q_iterations 67
#define K_half_float 68
#define K_view 69
#define K_src_opacity 70
#define K_unmult 71
#define K_glow_only 72
#define N_SLOTS 73
static const char MANIFEST[] =
  "{\"api\": 1, \"id\": \"org.effectcraft.open.deep-glow-2\", \"name\": \"EC Deep Glow 2\", \""
  "category\": \"Stylize\", \"version\": \"5.0.0\", \"author\": \"Original implementation\", \""
  "description\": \"Physically-based multi-scale glow: inverse-square, exponential or"
  " procedural lens-iris kernel fitted to an anisotropic Gaussian pyramid; per-chan"
  "nel radius and dispersion, rotatable aspect, saturation bias, HDR-safe threshold"
  "/blend/tonemap, inner/outer tint, lens dirt, unmult.\", \"params\": [{\"id\": \"glow_m"
  "ode\", \"name\": \"Glow Mode\", \"type\": \"popup\", \"default\": 0, \"options\": [\"Exponenti"
  "al\", \"Pure Exponential\", \"Lens Iris\"]}, {\"id\": \"blend\", \"name\": \"Blend Mode\", \"t"
  "ype\": \"popup\", \"default\": 0, \"options\": [\"Screen\", \"Add\", \"Normal\", \"Lighten\", \""
  "Color Dodge\", \"Linear Dodge\", \"Overlay\", \"Soft Light\"]}, {\"id\": \"radius\", \"name\""
  ": \"Radius\", \"type\": \"slider\", \"default\": 300, \"min\": 1, \"max\": 5000, \"decimals\":"
  " 1, \"sliderMax\": 1000}, {\"id\": \"exposure\", \"name\": \"Exposure\", \"type\": \"slider\","
  " \"default\": 1.5, \"min\": -8, \"max\": 12, \"decimals\": 2, \"sliderMax\": 6}, {\"id\": \"i"
  "ntensity\", \"name\": \"Intensity\", \"type\": \"slider\", \"default\": 100, \"min\": 0, \"max"
  "\": 1000, \"decimals\": 1, \"sliderMax\": 300}, {\"id\": \"falloff\", \"name\": \"Falloff\", "
  "\"type\": \"slider\", \"default\": 2.0, \"min\": 0.25, \"max\": 4, \"decimals\": 2}, {\"id\": "
  "\"threshold\", \"name\": \"Threshold\", \"type\": \"slider\", \"default\": 35, \"min\": 0, \"ma"
  "x\": 400, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"thr_mode\", \"name\": \"Threshold"
  " Mode\", \"type\": \"popup\", \"default\": 0, \"options\": [\"Luminance\", \"Chrominance\"]},"
  " {\"id\": \"softness\", \"name\": \"Threshold Smooth\", \"type\": \"slider\", \"default\": 50,"
  " \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"sat_bias\", \"nam"
  "e\": \"Saturation Bias\", \"type\": \"slider\", \"default\": 0, \"min\": 0, \"max\": 100, \"de"
  "cimals\": 1, \"sliderMax\": 100}, {\"id\": \"iris_quality\", \"name\": \"Iris Sampling Qua"
  "lity\", \"type\": \"popup\", \"default\": 1, \"options\": [\"Low\", \"Standard\", \"High\"]}, {"
  "\"id\": \"iris_iterations\", \"name\": \"Iris Iterations\", \"type\": \"slider\", \"default\":"
  " 16, \"min\": 1, \"max\": 64, \"decimals\": 0, \"sliderMax\": 64}, {\"id\": \"iris_easing\","
  " \"name\": \"Radii Easing\", \"type\": \"slider\", \"default\": 50, \"min\": 0, \"max\": 100, "
  "\"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"iris_blades\", \"name\": \"Iris Blades\", \""
  "type\": \"slider\", \"default\": 6, \"min\": 0, \"max\": 16, \"decimals\": 0, \"sliderMax\": "
  "16}, {\"id\": \"iris_rotation\", \"name\": \"Iris Rotation\", \"type\": \"slider\", \"default"
  "\": 0, \"min\": -360, \"max\": 360, \"decimals\": 1, \"sliderMax\": 360}, {\"id\": \"iris_op"
  "acity\", \"name\": \"Iris Opacity\", \"type\": \"slider\", \"default\": 100, \"min\": 0, \"max"
  "\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"iris_aspect\", \"name\": \"Iris As"
  "pect Ratio\", \"type\": \"slider\", \"default\": 1.0, \"min\": 0.1, \"max\": 10, \"decimals\""
  ": 3}, {\"id\": \"iris_continuous\", \"name\": \"Continuous Rasterization\", \"type\": \"che"
  "ckbox\", \"default\": true}, {\"id\": \"gamma\", \"name\": \"Scene Gamma\", \"type\": \"slider"
  "\", \"default\": 1.0, \"min\": 0.2, \"max\": 5, \"decimals\": 2}, {\"id\": \"aspect\", \"name\""
  ": \"Aspect Ratio\", \"type\": \"slider\", \"default\": 1.0, \"min\": 0.1, \"max\": 10, \"deci"
  "mals\": 3}, {\"id\": \"angle_enable\", \"name\": \"Enable Angle\", \"type\": \"checkbox\", \"d"
  "efault\": false}, {\"id\": \"angle\", \"name\": \"Angle\", \"type\": \"slider\", \"default\": 0"
  ", \"min\": -360, \"max\": 360, \"decimals\": 1, \"sliderMax\": 360}, {\"id\": \"chroma\", \"n"
  "ame\": \"Chromatic Aberration\", \"type\": \"slider\", \"default\": 0, \"min\": 0, \"max\": 1"
  "00, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"ca_mode\", \"name\": \"Aberration Mode"
  "\", \"type\": \"popup\", \"default\": 0, \"options\": [\"Radius Offset\", \"Pixel Offset\", \""
  "Both\"]}, {\"id\": \"pixel_channels\", \"name\": \"Aberration Channels\", \"type\": \"popup\""
  ", \"default\": 0, \"options\": [\"Red & Blue\", \"Red & Green\", \"Green & Blue\", \"Red\", "
  "\"Green\", \"Blue\"]}, {\"id\": \"radius_r\", \"name\": \"Multiply Red\", \"type\": \"slider\", "
  "\"default\": 1.0, \"min\": 0.01, \"max\": 8, \"decimals\": 3}, {\"id\": \"radius_g\", \"name\""
  ": \"Multiply Green\", \"type\": \"slider\", \"default\": 1.0, \"min\": 0.01, \"max\": 8, \"de"
  "cimals\": 3}, {\"id\": \"radius_b\", \"name\": \"Multiply Blue\", \"type\": \"slider\", \"defa"
  "ult\": 1.0, \"min\": 0.01, \"max\": 8, \"decimals\": 3}, {\"id\": \"ab_order\", \"name\": \"Sh"
  "uffle Channels\", \"type\": \"popup\", \"default\": 0, \"options\": [\"RGB\", \"RBG\", \"GRB\","
  " \"GBR\", \"BRG\", \"BGR\"]}, {\"id\": \"tint_style\", \"name\": \"Tint Mode\", \"type\": \"popup"
  "\", \"default\": 0, \"options\": [\"3-Tone\", \"Inner & Outer\"]}, {\"id\": \"tint_blend\", \""
  "name\": \"Tint Blend Mode\", \"type\": \"popup\", \"default\": 0, \"options\": [\"Multiply\","
  " \"Normal\", \"Add\", \"Screen\", \"Overlay\", \"Soft Light\"]}, {\"id\": \"tint_inner\", \"nam"
  "e\": \"Color Inner\", \"type\": \"color\", \"default\": [1.0, 0.9, 0.7, 1.0]}, {\"id\": \"ti"
  "nt_outer\", \"name\": \"Color Outer\", \"type\": \"color\", \"default\": [0.6, 0.4, 1.0, 1."
  "0]}, {\"id\": \"tint_strength\", \"name\": \"Tint Strength\", \"type\": \"slider\", \"default"
  "\": 100, \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"tint_amo"
  "unt\", \"name\": \"Tint Amount (3-Tone)\", \"type\": \"slider\", \"default\": 0, \"min\": 0, "
  "\"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"tint_low\", \"name\": \"Tint L"
  "ow\", \"type\": \"color\", \"default\": [1.0, 0.45, 0.1, 1.0]}, {\"id\": \"tint_mid\", \"nam"
  "e\": \"Tint Mid\", \"type\": \"color\", \"default\": [1.0, 0.75, 0.45, 1.0]}, {\"id\": \"tin"
  "t_high\", \"name\": \"Tint High\", \"type\": \"color\", \"default\": [1.0, 0.95, 0.85, 1.0]"
  "}, {\"id\": \"tonemap\", \"name\": \"Tone Mapping\", \"type\": \"popup\", \"default\": 0, \"opt"
  "ions\": [\"None\", \"Reinhard\", \"ACES\", \"Filmic\", \"Reinhard 2\", \"Lottes\"]}, {\"id\": \""
  "tm_mix\", \"name\": \"Tone Mapping Mix\", \"type\": \"slider\", \"default\": 100, \"min\": 0,"
  " \"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"dither\", \"name\": \"Dither\""
  ", \"type\": \"slider\", \"default\": 100, \"min\": 0, \"max\": 100, \"decimals\": 1, \"slider"
  "Max\": 100}, {\"id\": \"dither_mono\", \"name\": \"Dither Monochromatic\", \"type\": \"check"
  "box\", \"default\": true}, {\"id\": \"dirt_amount\", \"name\": \"Lens Dirt Opacity\", \"type"
  "\": \"slider\", \"default\": 0, \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100"
  "}, {\"id\": \"dirt_inherit\", \"name\": \"Inherit Glow Color\", \"type\": \"slider\", \"defau"
  "lt\": 100, \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"dirt_e"
  "xposure\", \"name\": \"Matte Exposure\", \"type\": \"slider\", \"default\": 0, \"min\": -6, \""
  "max\": 6, \"decimals\": 2, \"sliderMax\": 6}, {\"id\": \"dirt_gamma\", \"name\": \"Matte Gam"
  "ma\", \"type\": \"slider\", \"default\": 1.0, \"min\": 0.1, \"max\": 6, \"decimals\": 2}, {\"i"
  "d\": \"dirt_scale\", \"name\": \"Lens Dirt Scale\", \"type\": \"slider\", \"default\": 1.0, \""
  "min\": 0.05, \"max\": 10, \"decimals\": 2}, {\"id\": \"dirt_contrast\", \"name\": \"Lens Dir"
  "t Contrast\", \"type\": \"slider\", \"default\": 1.0, \"min\": 0.05, \"max\": 8, \"decimals\""
  ": 2}, {\"id\": \"dirt_seed\", \"name\": \"Lens Dirt Seed\", \"type\": \"slider\", \"default\":"
  " 1, \"min\": 1, \"max\": 9999, \"decimals\": 0, \"sliderMax\": 100}, {\"id\": \"quality\", \""
  "name\": \"Quality\", \"type\": \"popup\", \"default\": 2, \"options\": [\"Draft\", \"Low\", \"Me"
  "dium\", \"Standard\", \"High\", \"Extreme\", \"Custom\"]}, {\"id\": \"q_downsample\", \"name\":"
  " \"Downsampling\", \"type\": \"slider\", \"default\": 0, \"min\": 0, \"max\": 6, \"decimals\":"
  " 0, \"sliderMax\": 6}, {\"id\": \"q_steps\", \"name\": \"Glow Steps Multiplier\", \"type\": "
  "\"slider\", \"default\": 3, \"min\": 1, \"max\": 8, \"decimals\": 0, \"sliderMax\": 8}, {\"id"
  "\": \"q_iterations\", \"name\": \"Iterations\", \"type\": \"slider\", \"default\": 15, \"min\":"
  " 1, \"max\": 15, \"decimals\": 0, \"sliderMax\": 15}, {\"id\": \"half_float\", \"name\": \"Ha"
  "lf Float\", \"type\": \"checkbox\", \"default\": false}, {\"id\": \"view\", \"name\": \"View\","
  " \"type\": \"popup\", \"default\": 0, \"options\": [\"Final Result\", \"Glow Only\", \"Glow I"
  "nput\"]}, {\"id\": \"src_opacity\", \"name\": \"Source Opacity\", \"type\": \"slider\", \"defa"
  "ult\": 100, \"min\": 0, \"max\": 100, \"decimals\": 1, \"sliderMax\": 100}, {\"id\": \"unmul"
  "t\", \"name\": \"Unmult (Required for Alpha)\", \"type\": \"checkbox\", \"default\": true},"
  " {\"id\": \"glow_only\", \"name\": \"Glow Only (Legacy)\", \"type\": \"checkbox\", \"default\""
  ": false}]}"
;
#define MANIFEST_LEN ((int)(sizeof(MANIFEST)-1))
