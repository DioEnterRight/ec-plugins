// node kernel_err.mjs <wasm...>  -> relative error of the impulse response against the analytic kernel (glow only, no dither)
import fs from 'fs';
async function load(p){ const {instance}=await WebAssembly.instantiate(fs.readFileSync(p),{}); const ex=instance.exports;
  const man=JSON.parse(new TextDecoder().decode(new Uint8Array(ex.memory.buffer).slice(ex.ec_manifest_ptr(),ex.ec_manifest_ptr()+ex.ec_manifest_len())));
  const idx={}; const base=[]; for(const p of man.params){ idx[p.id]=base.length; if(p.type==='color') base.push(...p.default); else base.push(p.type==='checkbox'?(p.default?1:0):p.default); }
  return {ex,idx,base}; }
function run(M, over, W, H, img){ const slots=M.base.slice(); for(const [k,v] of Object.entries(over)) slots[M.idx[k]]=v;
  const bytes=W*H*16; const ptr=M.ex.ec_alloc(bytes+slots.length*8+64); new Float32Array(M.ex.memory.buffer,ptr,W*H*4).set(img);
  const pp=(ptr+bytes+15)&~15; new Float64Array(M.ex.memory.buffer,pp,slots.length).set(slots);
  const rc=M.ex.ec_render(ptr,W,H,pp,slots.length,0,1); return {rc,out:new Float32Array(M.ex.memory.buffer,ptr,W*H*4).slice()}; }
const W=1024,H=1024; const img=new Float32Array(W*H*4); for(let i=0;i<W*H;i++) img[i*4+3]=1; const cx=W/2,cy=H/2; const i0=(cy*W+cx)*4; img[i0]=img[i0+1]=img[i0+2]=1000;
for (const p of process.argv.slice(2)) { const M=await load(p);
 for (const R of [30,100]) for (const q of [1,2,3,5]) {
  const r=run(M,{threshold:0,softness:0,radius:R,exposure:0,intensity:100,quality:q,view:1,dither:0},W,H,img);
  // analytic: K(r)=(1+(r/a)^2)^-1 exp(-(r/R)^2), a=max(1,1.5,0.004R)=1.5 ; normalise numerically
  const a=1.5; const K=(rr)=>Math.exp(-Math.log(1+rr*rr/(a*a))-(rr/R)*(rr/R));
  let Z=0; for(let y=-6*R;y<=6*R;y++)for(let x=-6*R;x<=6*R;x++) Z+=K(Math.hypot(x,y)); // pixel sum
  let maxrel=0, l1=0, tot=0, tail=0;
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const rr=Math.hypot(x-cx,y-cy); if(rr>3*R) continue; const ideal=1000*K(rr)/Z; const m=r.out[(y*W+x)*4+1];
    const e=Math.abs(m-ideal); l1+=e; tot+=ideal; if(ideal>1e-3*1000*K(0)/Z && rr<2*R) maxrel=Math.max(maxrel,e/ideal); }
  console.log(`${p.split('/').pop().padEnd(10)} R=${String(R).padEnd(3)} q=${q} rc=${r.rc} L1err/energy=${(l1/tot).toExponential(2)} maxrel(core..2R,>1e-3 peak)=${maxrel.toExponential(2)}`);
 } }
