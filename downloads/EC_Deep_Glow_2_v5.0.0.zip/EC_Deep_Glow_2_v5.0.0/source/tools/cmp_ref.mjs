// node cmp_ref.mjs <ref.wasm> <new.wasm> [W H]   -> per-config max abs / relative difference between two builds
import fs from 'fs';
const [,, refP, newP, Ws='480', Hs='270'] = process.argv;
async function load(p){ const {instance}=await WebAssembly.instantiate(fs.readFileSync(p),{}); const ex=instance.exports;
  const man=JSON.parse(new TextDecoder().decode(new Uint8Array(ex.memory.buffer).slice(ex.ec_manifest_ptr(),ex.ec_manifest_ptr()+ex.ec_manifest_len())));
  const idx={}; const base=[]; for(const p of man.params){ idx[p.id]=base.length; if(p.type==='color') base.push(...p.default); else base.push(p.type==='checkbox'?(p.default?1:0):p.default); }
  return {ex,idx,base,man}; }
const A=await load(refP), B=await load(newP);
function scene(W,H,name){ const a=new Float32Array(W*H*4);
  const put=(x,y,r,g,b,al=1)=>{ if(x<0||y<0||x>=W||y>=H) return; const i=(y*W+x)*4; a[i]=r*al; a[i+1]=g*al; a[i+2]=b*al; a[i+3]=al; };
  if(name==='impulse'){ put(W>>1,H>>1,1000,1000,1000); return a; }
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const v=0.02+0.03*y/H; put(x,y,v*0.6,v*0.8,v,1); }
  const aad=(cx,cy,rad,r,g,b)=>{ for(let y=-rad-2;y<=rad+2;y++)for(let x=-rad-2;x<=rad+2;x++){ const d=Math.hypot(x,y); const c=Math.min(1,Math.max(0,rad+0.5-d)); if(c>0&&cx+x>=0&&cy+y>=0&&cx+x<W&&cy+y<H){ const i=((cy+y)*W+cx+x)*4; a[i]=a[i]*(1-c)+r*c; a[i+1]=a[i+1]*(1-c)+g*c; a[i+2]=a[i+2]*(1-c)+b*c; } } };
  const s=Math.max(1,Math.round(H/270));
  aad(W*0.22|0,H*0.35|0,3*s,30,30,30); aad(W*0.5|0,H*0.5|0,10*s,12,12,12); aad(W*0.78|0,H*0.3|0,22*s,0.1,0.9,1.0);
  aad(W*0.7|0,H*0.72|0,18*s,1,0.05,0.6); aad(W*0.3|0,H*0.75|0,14*s,1,0.5,0.05);
  for(let x=W*0.08|0;x<W*0.45;x++) for(let t=0;t<3*s;t++){ const y=(H*0.58|0)+t; const i=(y*W+x)*4; a[i]=0.2; a[i+1]=1.6; a[i+2]=0.3; }
  for(let y=H*0.1|0;y<H*0.55;y++) for(let t=0;t<2*s;t++){ const x=(W*0.9|0)+t; const i=(y*W+x)*4; a[i]=8; a[i+1]=0.4; a[i+2]=0.4; }
  for(let y=H-12*s;y<H;y++) for(let x=W*0.55|0;x<W*0.7;x++){ const i=(y*W+x)*4; a[i]=4; a[i+1]=4; a[i+2]=3.5; }
  if (name==='alpha'){ for(let i=0;i<W*H;i++){ const f=((i%W)/W); a[i*4+3]=Math.max(0.05,f); a[i*4]*=a[i*4+3]; a[i*4+1]*=a[i*4+3]; a[i*4+2]*=a[i*4+3]; } }
  return a; }
function run(M, over, W, H, img, scale=1){
  const slots=M.base.slice();
  for(const [k,v] of Object.entries(over)){ if(!(k in M.idx)) throw new Error('unknown '+k); if(Array.isArray(v)) v.forEach((x,i)=>slots[M.idx[k]+i]=x); else slots[M.idx[k]]=v; }
  const bytes=W*H*16; const ptr=M.ex.ec_alloc(bytes+slots.length*8+64);
  new Float32Array(M.ex.memory.buffer,ptr,W*H*4).set(img);
  const pp=(ptr+bytes+15)&~15; new Float64Array(M.ex.memory.buffer,pp,slots.length).set(slots);
  const t0=performance.now(); const rc=M.ex.ec_render(ptr,W,H,pp,slots.length,0,scale); const ms=performance.now()-t0;
  return {rc,ms,out:new Float32Array(M.ex.memory.buffer,ptr,W*H*4).slice()}; }
const W=+Ws,H=+Hs;
const cfgs = {
 'default':{}, 'draft':{quality:0}, 'low':{quality:1}, 'standard':{quality:3}, 'high':{quality:4}, 'extreme':{quality:5},
 'custom':{quality:6,q_downsample:1,q_steps:3,q_iterations:9}, 'exp mode':{glow_mode:1}, 'iris':{glow_mode:2,iris_iterations:12},
 'aspect3':{aspect:3}, 'aspect.3':{aspect:0.3}, 'aspect4+angle30':{aspect:4,angle_enable:1,angle:30},
 'chroma':{chroma:60}, 'chroma px':{chroma:60,ca_mode:1}, 'glow ab radii':{radius_r:1.6,radius_b:0.6},
 'tint3':{tint_amount:80}, 'tint io':{tint_style:1,tint_blend:4}, 'dirt':{dirt_amount:70}, 'tonemap aces':{tonemap:2}, 'gamma2.2':{gamma:2.2},
 'blend1':{blend:1}, 'blend2':{blend:2}, 'blend3':{blend:3}, 'blend4':{blend:4}, 'blend5':{blend:5}, 'blend6':{blend:6}, 'blend7':{blend:7},
 'dither poly':{dither_mono:0,dither:60}, 'dither off':{dither:0}, 'srcop50 nounmult':{src_opacity:50,unmult:0}, 'blend7+tm':{blend:7,tonemap:3,tm_mix:60},
 'big radius':{radius:1200}, 'small radius':{radius:12}, 'thr 100 sat':{threshold:100,sat_bias:60}, 'half float':{half_float:1}, 'glow only':{view:1}, 'matte':{view:2},
};
let worstRel=0;
for (const sc of ['neon','alpha','impulse']) {
  const img=scene(W,H,sc);
  for (const [name,o] of Object.entries(cfgs)) {
    if (sc==='impulse' && !['default','high','aspect4+angle30','iris','big radius','small radius','custom'].includes(name)) continue;
    const a=run(A,o,W,H,img), b=run(B,o,W,H,img);
    let mx=0, md=0, n=0, sum=0; for(let i=0;i<a.out.length;i++){ const d=Math.abs(a.out[i]-b.out[i]); if(!(d<=1e30)) { md=Infinity; } if(d>md) md=d; if(Math.abs(a.out[i])>mx) mx=Math.abs(a.out[i]); if(d>1e-4*Math.max(1,0)) n++; sum+=d; }
    const rel=md/Math.max(mx,1e-9); if(rel>worstRel) worstRel=rel;
    console.log(`${sc.padEnd(7)} ${name.padEnd(16)} rc ${a.rc}/${b.rc}  maxabs ${md.toExponential(2)}  rel ${rel.toExponential(2)}  mean ${(sum/a.out.length).toExponential(1)}  ${Math.round(a.ms)}ms -> ${Math.round(b.ms)}ms`);
  }
}
console.log('WORST relative diff', worstRel.toExponential(3));
