#!/bin/sh
# usage: phases.sh <source.c> <manifest dir> [W H] [json]   -> per-phase wasmi fuel / ms
SRC=$1; MD=$2; W=${3:-1920}; H=${4:-1080}; CFG=${5:-'{}'}
T=$(mktemp -d); cp $MD/manifest.h $T/; cp $MD/params_gen.h $T/ 2>/dev/null
python3 - "$SRC" "$T/p.c" <<'PY'
import sys
s=open(sys.argv[1]).read()
def ins(marker,n,after=True):
    global s
    assert s.count(marker)==1, marker
    add="\n#ifdef EC_STOP\n if (EC_STOP==%d) return 0;\n#endif\n"%n
    s=s.replace(marker, marker+add if after else add+marker)
ins("    Tab tb; mk(&tb, &m);\n    TH0 = m.TH;\n",1)
ins("    if (P.view == 2) {",2,after=False)
ins("    /* ---- 3. weights",3,after=False)
ins("    /* ---- 4. anisotropic pyramid",4,after=False)
ins("    /* ---- 5. reconstruction",5,after=False)
ins("    /* ---- rotate the glow back */",6,after=False)
ins("    /* ---- 6. style and output */",7,after=False)
open(sys.argv[2],'w').write(s)
PY
HS=${HS:-./test/hostsim/target/release/hostsim}
prev=0; prevms=0
for n in 1 2 3 4 5 6 7 99; do
  clang --target=wasm32 -O3 -DEC_STOP=$n -I$MD -ffreestanding -fno-builtin -fno-math-errno -nostdlib -Wno-unused-parameter -Wno-unused-variable -Wl,--no-entry -Wl,--allow-undefined -Wl,-z,stack-size=16384 -Wl,--initial-memory=65536 -Wl,--global-base=1024 -Wl,--strip-all $T/p.c -o $T/s$n.wasm 2>&1 | grep error
  best=999999; for r in 1 2; do o=$($HS $T/s$n.wasm $W $H "$CFG" ${SCENE:-neon}); ms=$(echo "$o" | python3 -c "import sys,json;print(json.load(sys.stdin)['ms'])"); [ $ms -lt $best ] && best=$ms; done
  fu=$(echo "$o" | python3 -c "import sys,json;print(json.load(sys.stdin)['fuel_used_M'])")
  name=$(echo "stop1:layout stop2:input stop3:matte stop4:rot+fit stop5:pyramid stop6:recon stop7:rotback stop99:output" | tr ' ' '\n' | grep "stop$n:" | cut -d: -f2)
  python3 -c "print('%-10s cum fuel %9.1fM  cum ms %5d   | step fuel %8.1fM  step ms %5d'%('$name',$fu,$best,$fu-$prev,$best-$prevms))"
  prev=$fu; prevms=$best
done
rm -rf $T
