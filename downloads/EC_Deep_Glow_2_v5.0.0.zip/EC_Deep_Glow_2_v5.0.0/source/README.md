# EC Deep Glow 2 — v5.0.0 (EffectCraft wasm plugin)

Same plugin id (`org.effectcraft.open.deep-glow-2`) and the same ABI as before. `deep_glow_open.c` is the whole
source: freestanding C, no libc, compiled to wasm32.

## What changed in 5.0.0

### 1. The control panel follows Deep Glow 2
Tutorials for Deep Glow 2 go top to bottom: **Glow Mode, Blend Mode, Radius, Exposure, Threshold, Threshold Mode,
Threshold Smooth, Saturation Bias, … Aspect Ratio, Enable Angle, Angle, … Tint, Tone Mapping, Lens Dirt, Quality, View,
Source Opacity, Unmult**. EC Deep Glow 2 now has the same names in the same order (see the tables below). Things renamed:

| Before | Now |
|---|---|
| Threshold Softness | Threshold Smooth |
| Glow Aberration Order | Shuffle Channels |
| Glow Radius Red / Green / Blue | Multiply Red / Green / Blue |
| Pixel Aberration Channels | Aberration Channels |
| Tint Style / Tint Inner / Tint Outer | Tint Mode / Color Inner / Color Outer |
| Lens Dirt Amount | Lens Dirt Opacity |
| Dirt Inherit Glow Color | Inherit Glow Color |
| Dirt Matte Exposure / Gamma | Matte Exposure / Matte Gamma |
| Custom Downsampling / Steps Multiplier / Iterations | Downsampling / Glow Steps Multiplier / Iterations |
| Unmult | Unmult (Required for Alpha) |
| Glow Mode option "Inverse Square" / "Exponential" | "Exponential" (the default, physically based look) / "Pure Exponential" |
| View option "Composite" / "Threshold Matte" | "Final Result" / "Glow Input" |
| Blend option "Screen (HDR-safe)" | "Screen" (still HDR-safe) |
| Iris Radii Easing | Radii Easing |

Parameter **ids did not change**. If EffectCraft stores effect parameters by id, saved
projects and presets keep their values; if one of yours looks off, set it again and re-save the preset. The only thing that
changed in the plug-in code is that parameters are read through `K_<id>` slot numbers generated from `manifest.json`
(`gen_manifest.py`), so reordering the panel is a one-file edit from now on.

What cannot be the same (plug-in API v1): collapsible groups, the Mask / Iris / Lens Dirt *layer* inputs, Buffer Expansion
and buttons. The names above were taken from the public Deep Glow 2 feature descriptions, tutorials and the built-in
EffectCraft Deep Glow effect; I could not open the real panel, so a label can still differ by a word.

### 2. Speed (same maths, far fewer instructions)
EffectCraft runs plug-ins in wasmi, an interpreter. The old timings in the README were measured in Node (V8, a JIT) and
were 5 to 10 times too optimistic. Measured through a copy of the real host (`test/hostsim`, wasmi, this slow server):

| 1080p unless noted | v4.1.1 | 5.0.0, mostly dark frame | 5.0.0, bright full frame |
|---|---|---|---|
| default (Medium) | 5.6 s | **1.0 s** | **2.3 s** |
| Draft | 1.8 s | 0.9 s | 1.1 s |
| Standard | 6.7 s | 1.0 s | 3.1 s |
| Extreme | 7.9 s | 1.0 s | 3.9 s |
| Aspect 3 + Angle 30 | 9.7 s | 4.2 s | 5.9 s |
| Lens Iris (defaults) | 7.7 s | 1.1 s | 6.4 s |
| 4K default | 9.9 s | 3.7 s | 5.6 s |
| 4K Aspect 3 + Angle 30 | no glow (out of memory) | 9.8 s | 11.4 s |

"Mostly dark" is a typical glow shot (lights, text, lines on a dark picture: under a few percent of the pixels pass the
Threshold); "bright full frame" is the worst case (most of the frame passes). A normal desktop is roughly 2 to 3 times
faster than this server. What was done, in order of effect:

* **Sparse rows.** Every Gaussian and every iris ring maps black to black, so rows and row stretches with no light are
  skipped (row extents, no approximation) in the Gaussian terms, the iris convolution and the rotation.
* **Unrolled Gaussian kernels** (taps unrolled per radius, symmetric weights folded, vertical passes accumulate in
  registers), constant-weight halving / doubling filters: 1.7x on its own.
* **Pyramid collapse** for the usual isotropic case: half the up-sampling work of the general staircase walk.
* **The sigma = 1.6 Gaussian** of the default ladder moves to pyramid level 1, where it is a plain addition instead of two
  full-resolution filter passes. Its realised sigma (1.607) is what the kernel fit uses, so the glow stays fitted to the
  same target (see the next section for what this does to the numbers).
* **Input pass** skips pixels that cannot pass the Threshold (exact test); **output pass** has a lean loop per blend mode
  and one dither hash per row instead of two per pixel; **rotation** uses a separable 4x4 window with no bounds tests inside.
* Cost model refitted to the new code (median error 3 %, worst under-estimate 13 %).

### 3. Quality: what is bit-for-bit and what is not
Every step above except the sigma = 1.6 move was checked against the build before it with `tools/cmp_ref.mjs` (45 configs,
three scenes): the same pixels up to float rounding, worst relative difference 2e-7 of the brightest pixel. The sigma = 1.6 move changes the fit a
little: impulse, R = 100, Medium: L1 error against the analytic kernel 0.80 % to 0.89 % of the energy, maximum
relative error 3.3 % to 4.1 %; on the test scene the glow differs by up to 0.7 % of its brightest pixel, which is below
the default Dither (about 1/255). `kern_test.py` (median / max error against the target, energy 1.0000) is as good as or
better than 4.1.1 in every case.

### 4. Bugs found and fixed in this pass
| Bug | Effect in the app | Fix |
|---|---|---|
| A plan that needed more than the host's 1 GiB of memory was refused | **4K (and larger) with Aspect Ratio + Angle came back with no glow at all** (the host swallows the error) | the planner now measures the plan's memory and coarsens the pyramid until it fits under 960 MiB (4K rotated needs 749 MB now) |
| The planner's time budget was 70 % of the host's instruction budget | up to 14 s per 1080p frame and about 25 s per 4K frame were allowed: the app looks frozen or "crashed" | absolute cap of 24 G fuel (about 10 s of wasmi on a slow core, 3 to 5 s on a desktop); only extreme settings are coarsened |
| Cost model was fitted to the old kernels | planner over- or under-reacted | refitted on bright full frames (the worst case) |
| Test harness passed only the first 36 of the parameters to wasm files not named `open_4` | continuity / kernel / unit tests ignored the v4 controls | harness passes all of them |
| INSTALL.txt speed table | measured in V8, not wasmi | replaced with wasmi numbers |

Frames larger than about 5 K pixels wide (for example 8K) still need more memory than the host allows
(`ec_render` returns 2, the frame is left without glow). 4K and below work.

## Control panel (top to bottom)

**Main**

| Control | Range / options |
|---|---|
| Glow Mode | Exponential / Pure Exponential / Lens Iris |
| Blend Mode | Screen / Add / Normal / Lighten / Color Dodge / Linear Dodge / Overlay / Soft Light |
| Radius | 1 to 5000, default 300 |
| Exposure | -8 to 12, default 1.5 |
| Intensity | 0 to 1000, default 100 |
| Falloff | 0.25 to 4, default 2 |

**Input**

| Control | Range / options |
|---|---|
| Threshold | 0 to 400, default 35 |
| Threshold Mode | Luminance / Chrominance |
| Threshold Smooth | 0 to 100, default 50 |
| Saturation Bias | 0 to 100, default 0 |

**Iris (Glow Mode = Lens Iris)**

| Control | Range / options |
|---|---|
| Iris Sampling Quality | Low / Standard / High |
| Iris Iterations | 1 to 64, default 16 |
| Radii Easing | 0 to 100, default 50 |
| Iris Blades | 0 to 16, default 6 |
| Iris Rotation | -360 to 360, default 0 |
| Iris Opacity | 0 to 100, default 100 |
| Iris Aspect Ratio | 0.1 to 10, default 1 |
| Continuous Rasterization | checkbox, on |

**Style: Gamma Correction**

| Control | Range / options |
|---|---|
| Scene Gamma | 0.2 to 5, default 1 |

**Style: Aspect Ratio**

| Control | Range / options |
|---|---|
| Aspect Ratio | 0.1 to 10, default 1 |
| Enable Angle | checkbox, off |
| Angle | -360 to 360, default 0 |

**Style: Chromatic Aberration**

| Control | Range / options |
|---|---|
| Chromatic Aberration | 0 to 100, default 0 |
| Aberration Mode | Radius Offset / Pixel Offset / Both |
| Aberration Channels | Red & Blue / Red & Green / Green & Blue / Red / Green / Blue |
| Multiply Red | 0.01 to 8, default 1 |
| Multiply Green | 0.01 to 8, default 1 |
| Multiply Blue | 0.01 to 8, default 1 |
| Shuffle Channels | RGB / RBG / GRB / GBR / BRG / BGR |

**Style: Tint**

| Control | Range / options |
|---|---|
| Tint Mode | 3-Tone / Inner & Outer |
| Tint Blend Mode | Multiply / Normal / Add / Screen / Overlay / Soft Light |
| Color Inner | colour |
| Color Outer | colour |
| Tint Strength | 0 to 100, default 100 |
| Tint Amount (3-Tone) | 0 to 100, default 0 |
| Tint Low | colour |
| Tint Mid | colour |
| Tint High | colour |

**Style: Tone Mapping**

| Control | Range / options |
|---|---|
| Tone Mapping | None / Reinhard / ACES / Filmic / Reinhard 2 / Lottes |
| Tone Mapping Mix | 0 to 100, default 100 |

**Style: Dither**

| Control | Range / options |
|---|---|
| Dither | 0 to 100, default 100 |
| Dither Monochromatic | checkbox, on |

**Style: Lens Dirt**

| Control | Range / options |
|---|---|
| Lens Dirt Opacity | 0 to 100, default 0 |
| Inherit Glow Color | 0 to 100, default 100 |
| Matte Exposure | -6 to 6, default 0 |
| Matte Gamma | 0.1 to 6, default 1 |
| Lens Dirt Scale | 0.05 to 10, default 1 |
| Lens Dirt Contrast | 0.05 to 8, default 1 |
| Lens Dirt Seed | 1 to 9999, default 1 |

**Quality**

| Control | Range / options |
|---|---|
| Quality | Draft / Low / Medium / Standard / High / Extreme / Custom |
| Downsampling | 0 to 6, default 0 |
| Glow Steps Multiplier | 1 to 8, default 3 |
| Iterations | 1 to 15, default 15 |
| Half Float | checkbox, off |

**Output**

| Control | Range / options |
|---|---|
| View | Final Result / Glow Only / Glow Input |
| Source Opacity | 0 to 100, default 100 |
| Unmult (Required for Alpha) | checkbox, on |
| Glow Only (Legacy) | checkbox, off |

Panel order is the order of the tables above, top to bottom, with the group names as headings here only: plug-in API v1 has no collapsible groups, so EffectCraft shows one flat list.

## Kernel model, Lens Iris
* Inverse Square: `K(r) = (1 + (r/a)^2)^(-p/2) * exp(-(r/R)^2)`, p = Falloff (2.0 = the inverse-square law),
  a = soft core (>= 1.5 px), Gaussian window at R so the energy is finite. Exponential: `K(r) = exp(-3 r / R)`.
* The fit is done once for the isotropic kernel: a smoothness-regularised non-negative least-squares sum of the
  ladder Gaussians, relative error on log-spaced radii, renormalised to unit energy. An anisotropic kernel is the
  same kernel with its axes scaled, so Aspect Ratio changes where each Gaussian is placed but not its weight —
  Radius, Falloff, chroma and the radius multipliers only move the fit weights, so every control is continuous.
* Aspect Ratio is area preserving: `aspect = 2` is twice as wide and half as tall, same total size.
* Measured against the analytic target (impulse, R = 100, Standard): median error 1.6–4.3 %, max 21 % for the
  shallowest falloff (p = 1) in the far tail where K is already tiny. Energy is 1.0000 in every case.

## Lens Iris
Rings at `r_i = R (i/N)^g`, `g = 1 + 2(1 - easing)`, weighted `1/(r_i^2 + a^2)` so the density follows the same
inverse-square law as the fitted kernel, each softened by `sigma = max(dr/3, 0.5)` and drawn with the aperture's
outline (`blades` sides, `rotation`, stretched by Aspect Ratio). Every ring goes on the coarsest pyramid level
that still holds it within the sampling quality's kernel half-width (5 / 7 / 11 level pixels), and the whole bank
is normalised to unit energy per channel.

**Known limit:** the blade shape is only resolved while the blade bulge spans more than a level pixel. The
aperture reads clearly over most of the glow at Standard and High; at Low, and in the far tail of very large
radii, it fades to a circle. Making it exact everywhere needs a kernel half-width of ~10 level pixels at every
level, which costs 16x per level finer — a GPU job, not a scalar wasm one. Glow Aberration shifts the ring radii
per channel; Pixel Aberration works as usual.


## Build / test
    python3 gen_manifest.py     # manifest.json -> manifest.h (also writes the K_<id> slot numbers)
    ./build.sh                  # clang --target=wasm32, freestanding, no libc
    node test/v4_test.mjs                       # 97 behavioural checks of the engine
    (cd test/hostsim && cargo build --release) && python3 test/host_fuzz.py test/hostsim/target/release/hostsim ec_deep_glow_2.wasm
    python3 test/native_fuzz.py                 # needs gcc with ASan/UBSan
    cd test && python3 kern_test.py && python3 unit_test.py && python3 fuzz.py \
            && python3 fuzz_v4.py && python3 continuity.py
    # tools/: compare two builds (cmp_ref.mjs), kernel error against the analytic kernel (kernel_err.mjs),
    #         per-phase cost in wasmi (phases.sh).  tools/ref_v4.1.1.wasm is the previous release for comparisons.
    # hostsim scenes: `neon` (dark frame with lights, sparse) and `dense` (most of the frame passes the threshold)

## How close to Deep Glow 2 is this?
Not proven 1:1. The controls now cover what the public documentation lists (within API v1), but the kernel constants,
the Exposure and Threshold curves and the popup lists were never compared with real Deep Glow 2 output. `deepglow_calibration.zip`
holds the black-box way to close that: test frames, an After Effects run list, and an analyser that measures renders and fits
the constants. Note the plug-in's default **Exponential** mode (called Inverse Square before 5.0) is the one that corresponds to Deep Glow 2's default glow.
