// EC Outline Glow Setup: one-click setup for the EC Outline Glow plug-in. A ScriptUI panel (Window > EC Outline Glow Setup).
// Installed together with ec_outline_glow.wasm by Effect > Install Effect Plug-in Bundle (Folder)...
// Adds the effect and the animation expression for you. (c) 2026 DioEnterRight.
(function ecSetup(thisObj) {
  var FX = "EC Outline Glow", FXID = "org.neonforge.outline-glow", CLOCK_NAME = "Animation Time (s)", CLOCK = "time - thisLayer.startTime";
  var OPT_NAME = "Glow Type", OPTS = ["Neon", "Electric", "Water", "Galaxy", "Ice", "Fire", "Plasma"];
  var ui = thisObj instanceof Panel ? thisObj : new Window("palette", "EC Outline Glow Setup", undefined, { resizeable: true });
  ui.orientation = "column"; ui.alignChildren = ["fill", "top"];
  ui.add("statictext", undefined, "Select a layer, then click a button.");
  var dd = null, bOpt = null;
  if (OPTS.length) { dd = ui.add("dropdownlist", undefined, OPTS); dd.selection = 0; bOpt = ui.add("button", undefined, "Apply " + OPT_NAME, { name: "opt" }); }
  var bAdd = ui.add("button", undefined, "Add " + FX + " (animated)", { name: "add" });
  var status = ui.add("statictext", undefined, "Ready.", { multiline: true }); status.alignment = ["fill", "top"];
  function getFx(layer) {
    var fxs = layer.property("ADBE Effect Parade");
    for (var i = 1; i <= fxs.numProperties; i++) if (fxs.property(i).name == FX) return fxs.property(i);
    try { return fxs.addProperty(FX); } catch (e) { return fxs.addProperty(FXID); }
  }
  function wire(fx) { fx.property(CLOCK_NAME).expression = CLOCK; }  // the layer cache keys on parameters only
  function run(label, fn) {
    var c = app.project.activeItem;
    if (!(c instanceof CompItem) || c.selectedLayers.length == 0) { status.text = "Select a layer in a composition first."; return; }
    app.beginUndoGroup(label); var done = 0, err = "";
    try { for (var i = 0; i < c.selectedLayers.length; i++) { fn(c.selectedLayers[i]); done++; } }
    catch (e) { err = " Problem: " + e.toString(); }
    app.endUndoGroup(); status.text = label + ": " + done + " layer(s)." + err;
  }
  bAdd.onClick = function () { run("Add " + FX, function (l) { wire(getFx(l)); }); };
  if (bOpt) bOpt.onClick = function () {
    var v = dd.selection.index + 1;   // scripts use 1-based popups, as After Effects
    run("Apply " + OPT_NAME, function (l) { var fx = getFx(l); wire(fx); fx.property(OPT_NAME).setValue(v); });
  };
  if (ui instanceof Window) ui.show(); else ui.layout.layout(true);
})(this);
