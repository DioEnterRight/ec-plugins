#!/usr/bin/env bash
# Robustness sweep: every popup branch, extreme values, odd frame sizes and preview scales.
# Any non-zero exit from the harness (non-finite output, non-determinism, bad rc) fails the run.
set -u
WASM="$1"; H="$(dirname "$0")/harness.mjs"
fail=0; n=0
run() { n=$((n+1)); if ! out=$(node "$H" "$WASM" "$@" 2>&1); then echo "FAIL: $*"; echo "$out" | sed 's/^/      /'; fail=$((fail+1)); fi; }

for sz in "1 1" "2 3" "7 5" "64 64" "320 180" "640 360"; do
  set -- $sz; run --w $1 --h $2
done
for sc in 0.125 0.25 0.5 1 2; do run --w 320 --h 180 --scale $sc; done
for i in 0 1 2 3 4; do run --w 320 --h 180 --set combine=$i; done
for i in 0 1; do run --w 320 --h 180 --set edge_mode=$i; done
for i in 0 1; do run --w 320 --h 180 --set show=$i; done
for i in 0 1; do run --w 320 --h 180 --set dilation_quality=$i; done
for i in 0 1 2; do run --w 320 --h 180 --set combine_masks=$i --set mocha_project=1; done
run --w 320 --h 180 --set mocha_project=1 --set show_mocha_only=1
run --w 320 --h 180 --set mocha_project=1 --set bypass_mocha=1
run --w 320 --h 180 --set mocha_project=1 --set invert_mocha=1
for v in 0 0.001 0.4 2 100; do run --w 320 --h 180 --set glow_width=$v; done
for v in 0 0.5 100; do run --w 320 --h 180 --set threshold=$v; done
for v in 0 2 100; do run --w 320 --h 180 --set brightness=$v; done
for v in 0 1 100; do run --w 320 --h 180 --set width_x=$v; done
for v in 0 1 100; do run --w 320 --h 180 --set width_y=$v; done
run --w 320 --h 180 --set width_red=0 --set width_green=0 --set width_blue=0
run --w 320 --h 180 --set subpixel=0
run --w 320 --h 180 --set expand_borders=1
run --w 320 --h 180 --set invert_mask=1
run --w 320 --h 180 --set glow_from_alpha=1
run --w 320 --h 180 --set glow_under_source=1
run --w 320 --h 180 --set light_background=1
run --w 320 --h 180 --set source_opacity=0
run --w 320 --h 180 --set affect_alpha=1
run --w 320 --h 180 --set bg_brightness=0
run --w 320 --h 180 --set threshold_add_color=1,0.5,0
for t in 0 0.5 3.7 1e5; do run --w 320 --h 180 --set atmosphere_amp=0.8 --set ec_time=$t; done
for v in 0.1 20; do run --w 320 --h 180 --set atmosphere_amp=1 --set atmosphere_freq=$v; done
run --w 320 --h 180 --set atmosphere_amp=1 --set atmosphere_speed=-10 --set ec_time=2
run --w 320 --h 180 --set color=0,0,0
run --w 320 --h 180 --set color=8,8,8 --set brightness=100 --set glow_width=2

echo "sweep: $((n-fail))/$n passed"
exit $((fail > 0))
