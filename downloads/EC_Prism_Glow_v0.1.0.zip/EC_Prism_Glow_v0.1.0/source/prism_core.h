/*
 * prism_core.h - shared engine for the EC Prism plug-in suite (EffectCraft plug-in API v1).
 *
 * Header-only. Include once per plug-in translation unit, after "params_gen.h".
 *
 * Design rules (inherited from the EC Twitch / Outline Glow house style):
 *   - No imports: no libm, no clock, no files, no rand. Module must link with -nostdlib.
 *   - MVP wasm only: every float->int cast is NaN-checked and clamped first.
 *   - Resolution independent: every pixel distance is multiplied by `scale`.
 *   - Float everywhere, HDR safe (values may exceed 1), NaN/Inf safe.
 *   - No O(radius^2) kernels: large blurs run on a mip level, 3-pass box approximates a gaussian.
 *   - One arena placed after the host pixel buffer; never touches the manifest; <= 1 GiB.
 *   - Deterministic: identical output for identical (params, time, scale, pixels) on any machine.
 *
 * Fuel budget (crates/plugin/src/wasm.rs): 50_000_000 + 20_000 per pixel.
 *   1920x1080 -> ~41.5e9 fuel, i.e. ~20k interpreter instructions per pixel. Roomy, but the
 *   per-pixel composite loop is still the thing to keep lean: rare features go in noinline
 *   helpers so clang does not if-convert them into the hot loop.
 */
#ifndef PRISM_CORE_H
#define PRISM_CORE_H

#include <stdint.h>
#include <stddef.h>

#define EXPORT(name) __attribute__((export_name(name)))
#define NOINLINE __attribute__((noinline))
typedef float f32;

extern unsigned char __heap_base;

/* ------------------------------------------------------------------ freestanding libc shims */
void *memcpy(void *d, const void *s, size_t n) {
    unsigned char *dd = (unsigned char *)d; const unsigned char *ss = (const unsigned char *)s;
    while (n--) *dd++ = *ss++;
    return d;
}
void *memset(void *d, int v, size_t n) {
    unsigned char *dd = (unsigned char *)d;
    while (n--) *dd++ = (unsigned char)v;
    return d;
}

/* ------------------------------------------------------------------ scalar math */
static inline f32 pc_clamp(f32 x, f32 a, f32 b) { return x < a ? a : (x > b ? b : x); }
static inline f32 pc_min(f32 a, f32 b) { return a < b ? a : b; }
static inline f32 pc_max(f32 a, f32 b) { return a > b ? a : b; }
static inline f32 pc_abs(f32 x) { return x < 0 ? -x : x; }
static inline f32 pc_floor(f32 x) { return __builtin_floorf(x); }
static inline f32 pc_sqrt(f32 x) { return __builtin_sqrtf(x); }
static inline f32 pc_lerp(f32 a, f32 b, f32 t) { return a + (b - a) * t; }
static inline f32 pc_smooth(f32 t) { return t * t * (3.0f - 2.0f * t); }
/* NaN -> 0, +Inf -> hi, negatives -> 0. Comparison order matters: NaN fails every test. */
static inline f32 pc_sat(f32 x, f32 hi) { return x > 0.0f ? (x < hi ? x : hi) : 0.0f; }
/* NaN / huge -> 0, otherwise unchanged. Use on every value read from host pixels. */
static inline f32 pc_fin(f32 v) { return (v == v && v > -1e18f && v < 1e18f) ? v : 0.0f; }
static inline int pc_i(f32 x) { if (!(x == x)) return 0; return (int)pc_clamp(x, -2.0e9f, 2.0e9f); }
static inline int pc_ifloor(f32 x) { if (!(x == x)) return 0; return (int)__builtin_floorf(pc_clamp(x, -1.0e9f, 1.0e9f)); }
static inline f32 pc_rcp(f32 x) { return pc_abs(x) > 1e-20f ? 1.0f / x : 0.0f; }

/* Rec.709 luma of a non-premultiplied triple. */
static inline f32 pc_luma(f32 r, f32 g, f32 b) { return 0.2126f * r + 0.7152f * g + 0.0722f * b; }

/* Minimax sin/cos, no libm. Accurate to ~1e-7 over the reduced range. */
static f32 pc_sin(f32 x) {
    x = pc_clamp(x, -1.0e5f, 1.0e5f);
    x -= 6.2831853f * pc_floor(x * 0.15915494f + 0.5f);
    if (x > 1.5707963f) x = 3.1415927f - x; else if (x < -1.5707963f) x = -3.1415927f - x;
    f32 x2 = x * x;
    return x * (1.0f + x2 * (-0.16666667f + x2 * (0.008333333f + x2 * (-0.0001984127f + x2 * 2.7557319e-6f))));
}
static inline f32 pc_cos(f32 x) { return pc_sin(x + 1.5707963f); }
/* Phase in radians from a double clock: keeps precision at large times. */
static f32 pc_phase(double x) {
    if (!(x == x) || x > 1.0e9 || x < -1.0e9) return 0.0f;
    double k = x * 0.15915494309189535;
    k = k - (double)(long long)(k < 0 ? k - 1.0 : k);
    k = k - (double)(long long)k;
    return (f32)(k * 6.283185307179586);
}
/* Bounded exp for falloff curves; no libm. exp(x) for x <= 0, 0 below -30. */
static f32 pc_exp_neg(f32 x) {
    if (!(x == x) || x >= 0.0f) return 1.0f;
    if (x < -30.0f) return 0.0f;
    /* exp(x) = 2^(x/ln2): split into integer and fractional parts. */
    f32 t = x * 1.4426950408889634f;
    int i = pc_ifloor(t);
    f32 fr = t - (f32)i;
    /* 2^fr on [0,1), degree-4 minimax */
    f32 p = 1.0f + fr * (0.6931472f + fr * (0.2402265f + fr * (0.0555041f + fr * 0.0096181f)));
    union { f32 f; uint32_t u; } s;
    int e = 127 + i;
    if (e <= 0) return 0.0f;
    if (e >= 255) return 3.4e38f;
    s.u = (uint32_t)e << 23;
    return p * s.f;
}

/* ------------------------------------------------------------------ hashing (deterministic, stateless) */
static inline uint32_t pc_hash2(uint32_t a, uint32_t b) {
    uint32_t h = a * 0x9E3779B1u ^ (b + 0x7F4A7C15u) * 0x85EBCA77u;
    h ^= h >> 15; h *= 0x2C1B3C6Du; h ^= h >> 12; h *= 0x297A2D39u; h ^= h >> 15;
    return h;
}
static inline uint32_t pc_hash3(uint32_t a, uint32_t b, uint32_t c) { return pc_hash2(pc_hash2(a, b), c); }
static inline f32 pc_u01(uint32_t h) { return (f32)(h >> 8) * (1.0f / 16777216.0f); }
/* Signed [-1,1). */
static inline f32 pc_s01(uint32_t h) { return pc_u01(h) * 2.0f - 1.0f; }

/* ------------------------------------------------------------------ value-noise lattice
   A 2-component smooth-interpolated lattice. Cheap, deterministic, no gradients to store.
   Used for atmosphere / turbulence / flicker fields. Cell size is `lambda` buffer pixels. */
typedef struct { f32 *v; int nx, ny, ix0, iy0; f32 inv, ox, oy; } PcGrid;

static void pc_grid_build(PcGrid *g, f32 *mem, int w, int h, f32 lambda, f32 ox, f32 oy,
                          uint32_t tseed, uint32_t seed) {
    g->inv = pc_rcp(lambda); g->ox = ox; g->oy = oy;
    g->ix0 = pc_ifloor(ox); g->iy0 = pc_ifloor(oy);
    g->nx = pc_ifloor((f32)w * g->inv + (ox - (f32)g->ix0)) + 3;
    g->ny = pc_ifloor((f32)h * g->inv + (oy - (f32)g->iy0)) + 3;
    if (g->nx < 2) g->nx = 2;
    if (g->ny < 2) g->ny = 2;
    g->v = mem;
    for (int j = 0; j < g->ny; j++)
        for (int i = 0; i < g->nx; i++) {
            uint32_t k = pc_hash3((uint32_t)(i + g->ix0) + seed * 0x51ED27u,
                                  (uint32_t)(j + g->iy0) * 0x2545F491u + tseed,
                                  seed ^ 0xA511E9B3u);
            f32 *o = mem + ((size_t)j * g->nx + i) * 2;
            o[0] = (f32)(k & 0xFFFFu) * (1.0f / 65535.0f);
            o[1] = (f32)(k >> 16) * (1.0f / 65535.0f);
        }
}
/* Cells needed for a w x h frame at cell size lambda (floats, 2 per cell). */
static inline size_t pc_grid_floats(int w, int h, f32 lambda) {
    f32 inv = pc_rcp(lambda);
    return ((size_t)pc_ifloor((f32)w * inv) + 5) * ((size_t)pc_ifloor((f32)h * inv) + 5) * 2;
}
static inline void pc_grid_at(const PcGrid *g, f32 x, f32 y, f32 *o0, f32 *o1) {
    f32 fx = x * g->inv + g->ox - (f32)g->ix0, fy = y * g->inv + g->oy - (f32)g->iy0;
    int ix = pc_i(fx), iy = pc_i(fy);
    f32 tx = pc_smooth(fx - (f32)ix), ty = pc_smooth(fy - (f32)iy);
    if (ix < 0) ix = 0; if (iy < 0) iy = 0;
    if (ix > g->nx - 2) ix = g->nx - 2; if (iy > g->ny - 2) iy = g->ny - 2;
    const f32 *a = g->v + ((size_t)iy * g->nx + ix) * 2, *b = a + 2;
    const f32 *c = a + (size_t)g->nx * 2, *d = c + 2;
    f32 t0 = a[0] + (b[0] - a[0]) * tx, b0 = c[0] + (d[0] - c[0]) * tx;
    f32 t1 = a[1] + (b[1] - a[1]) * tx, b1 = c[1] + (d[1] - c[1]) * tx;
    *o0 = t0 + (b0 - t0) * ty; *o1 = t1 + (b1 - t1) * ty;
}
/* fBm over one lattice by sampling it at several frequencies (detail in [0,1]). */
static f32 pc_fbm(const PcGrid *g, f32 x, f32 y, int octaves, f32 detail) {
    f32 sum = 0.0f, amp = 1.0f, norm = 0.0f, fx = x, fy = y;
    f32 gain = 0.35f + 0.35f * pc_clamp(detail, 0.0f, 1.0f);
    for (int o = 0; o < octaves; o++) {
        f32 a0, a1;
        pc_grid_at(g, fx, fy, &a0, &a1);
        sum += amp * (a0 - 0.5f);
        norm += amp;
        amp *= gain;
        fx = fx * 2.0f + 37.0f; fy = fy * 2.0f + 17.0f;
    }
    return 0.5f + sum * pc_rcp(norm);
}

/* ------------------------------------------------------------------ arena
   Linear memory layout:  [module data + manifest] [host params+pixels] [our arena]
   The host buffer is ec_alloc's block; everything we need afterwards starts past its end. */
static uint32_t pc_main_end = 0;
static inline uint32_t pc_align16(uint32_t v) { return (v + 15u) & ~15u; }

static int pc_mem_ensure(uint64_t end) {
    if (end > 0x3F000000ull) return 0;            /* stay under 1 GiB with headroom */
    uint64_t cur = (uint64_t)__builtin_wasm_memory_size(0) * 65536ull;
    if (end <= cur) return 1;
    uint64_t pages = (end - cur + 65535ull) / 65536ull;
    return __builtin_wasm_memory_grow(0, (size_t)pages) != (size_t)-1;
}

/* The standard ec_alloc: a 16-byte aligned block past the module's own data.
   (Naive plug-ins return a fixed small address and overwrite their own manifest.) */
static inline int pc_alloc(int bytes) {
    if (bytes <= 0) return 0;
    uint32_t base = pc_align16((uint32_t)(uintptr_t)&__heap_base);
    uint64_t end = (uint64_t)base + (uint64_t)(uint32_t)bytes + 16u;
    if (!pc_mem_ensure(end)) return 0;
    pc_main_end = pc_align16((uint32_t)end);
    return (int)base;
}

typedef struct { f32 *top; uint64_t end; } PcArena;

/* Start the arena after the host pixel buffer, reserving `floats` floats. */
static int pc_arena_begin(PcArena *a, const f32 *px, size_t npixels, size_t floats) {
    uint64_t start = ((uint64_t)(uintptr_t)px + (uint64_t)npixels * 16u + 15u) & ~15ull;
    if ((uint64_t)pc_main_end > start) start = pc_main_end;
    if (!pc_mem_ensure(start + (uint64_t)floats * 4u + 4096u)) return 0;
    a->top = (f32 *)(uintptr_t)start;
    a->end = start + (uint64_t)floats * 4u;
    return 1;
}
static inline f32 *pc_take(PcArena *a, size_t count) {
    size_t n = (count + 3u) & ~3u;
    f32 *p = a->top;
    a->top += n;
    return p;
}
/* Sizing-bug guard. Returns 0 when the arena overran its reservation. */
static inline int pc_arena_ok(const PcArena *a) { return (uint64_t)(uintptr_t)a->top <= a->end; }

/* ------------------------------------------------------------------ edge handling
   Edge Mode decides what lies outside the source image while the glow is being spread:
   Transparent treats it as zero, Reflect mirrors the plane. */
enum { PC_EDGE_TRANSPARENT = 0, PC_EDGE_REFLECT = 1 };
static inline int pc_mirror(int i, int n) {
    if (n <= 1) return 0;
    while (i < 0 || i >= n) { if (i < 0) i = -i - 1; if (i >= n) i = 2 * n - i - 1; }
    return i;
}

/* ------------------------------------------------------------------ 3-pass box blur == gaussian
   `acc` must hold at least as many floats as the widest plane ever blurred (see pc_blur_edge,
   which blurs a plane padded by up to PC_PAD_MAX on each side).
   Kutskir's box-radius solution: three box passes whose widths approximate a gaussian of sigma.
   Zero-padded at the edges, so a glow fades out at the layer border instead of smearing. */
static void pc_box_radii(f32 sigma, int *rad) {
    f32 wi = pc_sqrt(4.0f * sigma * sigma + 1.0f);
    int wl = pc_ifloor(wi); if ((wl & 1) == 0) wl--; if (wl < 1) wl = 1;
    int wu = wl + 2;
    f32 mi = (12.0f * sigma * sigma - 3.0f * (f32)(wl * wl) - 12.0f * (f32)wl - 9.0f) / (-4.0f * (f32)wl - 4.0f);
    int m = pc_ifloor(pc_clamp(mi, -10.0f, 10.0f) + 0.5f);
    for (int i = 0; i < 3; i++) rad[i] = ((i < m ? wl : wu) - 1) / 2;
}
static void pc_box_h(const f32 *s, f32 *d, int w, int h, int r) {
    f32 inv = 1.0f / (f32)(2 * r + 1);
    for (int y = 0; y < h; y++) {
        const f32 *row = s + (size_t)y * w; f32 *out = d + (size_t)y * w;
        f32 a = 0;
        for (int i = 0; i <= r && i < w; i++) a += row[i];
        for (int x = 0; x < w; x++) {
            out[x] = a * inv;
            int ia = x + r + 1, ir = x - r;
            if (ia < w) a += row[ia];
            if (ir >= 0) a -= row[ir];
        }
    }
}
static void pc_box_v(const f32 *s, f32 *d, f32 *acc, int w, int h, int r) {
    f32 inv = 1.0f / (f32)(2 * r + 1);
    for (int x = 0; x < w; x++) acc[x] = 0;
    for (int j = 0; j <= r && j < h; j++) { const f32 *row = s + (size_t)j * w; for (int x = 0; x < w; x++) acc[x] += row[x]; }
    for (int y = 0; y < h; y++) {
        f32 *out = d + (size_t)y * w;
        for (int x = 0; x < w; x++) out[x] = acc[x] * inv;
        int ia = y + r + 1, ir = y - r;
        if (ia < h) { const f32 *row = s + (size_t)ia * w; for (int x = 0; x < w; x++) acc[x] += row[x]; }
        if (ir >= 0) { const f32 *row = s + (size_t)ir * w; for (int x = 0; x < w; x++) acc[x] -= row[x]; }
    }
}
/* Blur `s` into `d` (d != s). tmp is a scratch plane the same size; acc >= w floats.
   sx / sy are sigmas in *level* pixels (already divided by the mip factor). */
static void pc_blur(const f32 *s, f32 *d, f32 *tmp, f32 *acc, int w, int h, f32 sx, f32 sy) {
    int rx[3] = {0, 0, 0}, ry[3] = {0, 0, 0};
    if (sx >= 0.3f) pc_box_radii(sx, rx);
    if (sy >= 0.3f) pc_box_radii(sy, ry);
    const f32 *cur = s; f32 *bufs[2] = {d, tmp};
    int which = 0, did = 0;
    for (int i = 0; i < 3; i++) if (rx[i] > 0) { f32 *o = bufs[which]; pc_box_h(cur, o, w, h, rx[i]); cur = o; which ^= 1; did = 1; }
    for (int i = 0; i < 3; i++) if (ry[i] > 0) { f32 *o = bufs[which]; pc_box_v(cur, o, acc, w, h, ry[i]); cur = o; which ^= 1; did = 1; }
    if (!did) { for (size_t i = 0; i < (size_t)w * h; i++) d[i] = s[i]; return; }
    if (cur != d) { for (size_t i = 0; i < (size_t)w * h; i++) d[i] = cur[i]; }
}

/* Blur with a chosen boundary behaviour.
 *
 * The box passes above are zero-padded, which is exactly Edge Mode "Transparent": outside the
 * image there is nothing, so a glow fades as it approaches the border. "Reflect" instead mirrors
 * the image outside, so a glow keeps its brightness at the border. That is implemented by
 * copying the plane into a mirrored-border scratch, blurring that, and taking the interior back.
 *
 * `scratch` must hold (w + 2*PC_PAD_MAX) * (h + 2*PC_PAD_MAX) floats; `tmp2` the same.
 * The pad is 3 sigma (the gaussian is numerically zero past that), capped so the scratch bound
 * holds at every mip level. */
#define PC_PAD_MAX 32
static void pc_blur_edge(const f32 *s, f32 *d, f32 *tmp, f32 *acc, int w, int h,
                         f32 sx, f32 sy, int edge, f32 *scratch, f32 *tmp2) {
    if (edge != PC_EDGE_REFLECT) { pc_blur(s, d, tmp, acc, w, h, sx, sy); return; }
    int p = pc_i(pc_max(sx, sy) * 3.0f + 2.0f);
    if (p > PC_PAD_MAX) p = PC_PAD_MAX;
    if (p > w) p = w;
    if (p > h) p = h;
    if (p < 1) { pc_blur(s, d, tmp, acc, w, h, sx, sy); return; }
    int pw = w + 2 * p, ph = h + 2 * p;
    for (int y = 0; y < ph; y++) {
        const f32 *src = s + (size_t)pc_mirror(y - p, h) * w;
        f32 *o = scratch + (size_t)y * pw;
        for (int x = 0; x < pw; x++) o[x] = src[pc_mirror(x - p, w)];
    }
    pc_blur(scratch, tmp2, tmp, acc, pw, ph, sx, sy);
    for (int y = 0; y < h; y++) {
        const f32 *src = tmp2 + (size_t)(y + p) * pw + p;
        f32 *o = d + (size_t)y * w;
        for (int x = 0; x < w; x++) o[x] = src[x];
    }
}

/* ------------------------------------------------------------------ mip pyramid (box 2x2 downsample) */
static inline int pc_mip_w(int w, int lvl) { return (w + (1 << lvl) - 1) >> lvl; }
static void pc_downsample(const f32 *src, int sw, int sh, f32 *dst, int dw, int dh) {
    for (int y = 0; y < dh; y++) {
        int y0 = 2 * y, y1 = y0 + 1 < sh ? y0 + 1 : y0;
        const f32 *r0 = src + (size_t)y0 * sw, *r1 = src + (size_t)y1 * sw;
        f32 *o = dst + (size_t)y * dw;
        for (int x = 0; x < dw; x++) {
            int x0 = 2 * x, x1 = x0 + 1 < sw ? x0 + 1 : x0;
            o[x] = 0.25f * (r0[x0] + r0[x1] + r1[x0] + r1[x1]);
        }
    }
}
/* Pick the mip level at which a blur of `sigma` buffer pixels costs little, and report the
   residual sigma to apply at that level. Never goes below a 2x2 plane. */
static int pc_level_for(f32 sigma, int w, int h, int maxlvl) {
    int lvl = 0;
    if (sigma < 0.6f) return 0;
    while (lvl < maxlvl && sigma / (f32)(1 << lvl) > 3.4f
           && (w >> (lvl + 1)) >= 2 && (h >> (lvl + 1)) >= 2) lvl++;
    return lvl;
}

/* Bilinear up-sample taps for one axis, precomputed per column / row (not per pixel). */
typedef struct { int *i0, *i1; f32 *t; } PcTaps;
static void pc_taps_build(PcTaps *tp, int dst_n, int src_n, int lvl, f32 offset) {
    f32 ik = 1.0f / (f32)(1 << lvl);
    for (int x = 0; x < dst_n; x++) {
        f32 fx = ((f32)x + 0.5f + offset) * ik - 0.5f;
        int x0 = pc_ifloor(fx); f32 t = fx - (f32)x0; int x1 = x0 + 1;
        if (x0 < 0) x0 = 0; if (x1 < 0) x1 = 0;
        if (x0 > src_n - 1) x0 = src_n - 1; if (x1 > src_n - 1) x1 = src_n - 1;
        tp->i0[x] = x0; tp->i1[x] = x1; tp->t[x] = t;
    }
}

/* ------------------------------------------------------------------ bilinear sample of a scalar plane */
static inline f32 pc_sample(const f32 *p, int w, int h, f32 x, f32 y) {
    f32 fx = pc_clamp(x, 0.0f, (f32)(w - 1)), fy = pc_clamp(y, 0.0f, (f32)(h - 1));
    int x0 = pc_i(fx), y0 = pc_i(fy);
    int x1 = x0 < w - 1 ? x0 + 1 : x0, y1 = y0 < h - 1 ? y0 + 1 : y0;
    f32 tx = fx - (f32)x0, ty = fy - (f32)y0;
    const f32 *r0 = p + (size_t)y0 * w, *r1 = p + (size_t)y1 * w;
    f32 a = r0[x0] + (r0[x1] - r0[x0]) * tx, b = r1[x0] + (r1[x1] - r1[x0]) * tx;
    return a + (b - a) * ty;
}

/* ------------------------------------------------------------------ directional exponential streak (glints)
   One forward and one backward IIR pass along a rotated axis. Cost is O(taps) per pixel with
   taps independent of streak length, which is what makes long glints affordable.
   `dx, dy` is the unit step; `decay` in (0,1) per step; `len` steps. */
static void pc_streak(const f32 *src, f32 *dst, int w, int h, f32 dx, f32 dy, f32 decay, int len) {
    for (size_t i = 0; i < (size_t)w * h; i++) dst[i] = 0.0f;
    if (len < 1) len = 1;
    for (int y = 0; y < h; y++) {
        f32 *o = dst + (size_t)y * w;
        for (int x = 0; x < w; x++) {
            f32 acc = 0.0f, amp = 1.0f;
            f32 sx = (f32)x + 0.5f, sy = (f32)y + 0.5f;
            for (int k = 0; k < len; k++) {
                acc += amp * pc_sample(src, w, h, sx - 0.5f, sy - 0.5f);
                amp *= decay;
                if (amp < 0.004f) break;
                sx += dx; sy += dy;
            }
            o[x] = acc;
        }
    }
}

/* ------------------------------------------------------------------ hierarchical radial gather (rays)
   Crytek-style: `passes` rounds of `taps` samples with geometric step growth give
   taps^passes effective reach for taps*passes samples per pixel. */
static void pc_radial(const f32 *src, f32 *dst, f32 *tmp, int w, int h,
                      f32 cx, f32 cy, f32 decay, int taps, int passes) {
    const f32 *cur = src; f32 *bufs[2] = {dst, tmp}; int which = 0;
    f32 step = 1.0f;
    for (int p = 0; p < passes; p++) {
        f32 *o = bufs[which];
        for (int y = 0; y < h; y++) {
            f32 *row = o + (size_t)y * w;
            for (int x = 0; x < w; x++) {
                f32 vx = (f32)x + 0.5f - cx, vy = (f32)y + 0.5f - cy;
                f32 acc = 0.0f, amp = 1.0f, norm = 0.0f;
                for (int k = 0; k < taps; k++) {
                    f32 s = 1.0f - (f32)k * step * 0.004f;
                    if (s < 0.0f) s = 0.0f;
                    acc += amp * pc_sample(cur, w, h, cx + vx * s - 0.5f, cy + vy * s - 0.5f);
                    norm += amp;
                    amp *= decay;
                }
                row[x] = acc * pc_rcp(norm);
            }
        }
        cur = o; which ^= 1;
        step *= (f32)taps;
    }
    if (cur != dst) for (size_t i = 0; i < (size_t)w * h; i++) dst[i] = cur[i];
}

/* ------------------------------------------------------------------ signed distance fields (flare elements) */
static inline f32 pc_sdf_circle(f32 px, f32 py, f32 r) { return pc_sqrt(px * px + py * py) - r; }
/* Regular n-gon with rounded corners, rotated by `rot` radians. */
static f32 pc_sdf_ngon(f32 px, f32 py, f32 r, int n, f32 rot, f32 round) {
    if (n < 3) return pc_sdf_circle(px, py, r);
    f32 c = pc_cos(-rot), s = pc_sin(-rot);
    f32 qx = px * c - py * s, qy = px * s + py * c;
    f32 ang = 6.2831853f / (f32)n;
    /* distance to the nearest edge plane of the polygon */
    f32 best = -1e18f;
    for (int i = 0; i < n; i++) {
        f32 a = (f32)i * ang;
        f32 d = qx * pc_cos(a) + qy * pc_sin(a) - (r - round);
        if (d > best) best = d;
    }
    return best - round;
}
/* SDF -> coverage with `soft` buffer pixels of anti-aliasing. */
static inline f32 pc_cover(f32 d, f32 soft) {
    if (soft < 0.35f) soft = 0.35f;
    return pc_clamp(0.5f - d / soft, 0.0f, 1.0f);
}

/* ------------------------------------------------------------------ blend / combine
   Sapphire's Combine popup: Mult, Add, Screen, Difference, Overlay.
   `a` is the background (source), `b` the glow layer. Operates per channel, HDR safe. */
enum { PC_COMB_MULT = 0, PC_COMB_ADD = 1, PC_COMB_SCREEN = 2, PC_COMB_DIFF = 3, PC_COMB_OVERLAY = 4 };
static inline f32 pc_combine(int mode, f32 a, f32 b) {
    switch (mode) {
        case PC_COMB_MULT:   return a * b;
        case PC_COMB_ADD:    return a + b;
        case PC_COMB_DIFF:   return pc_abs(a - b);
        case PC_COMB_OVERLAY: {
            f32 ac = pc_clamp(a, 0.0f, 1.0f);
            return ac < 0.5f ? 2.0f * a * b : 1.0f - 2.0f * (1.0f - a) * (1.0f - b);
        }
        case PC_COMB_SCREEN:
        default:
            /* 1-(1-a)(1-b) == a + b(1-a). Clamping the *source's* shadowing factor keeps the
             * identity exactly on [0,1] while stopping an overbright source (a > 1) from being
             * driven down - or inside out - by the glow it emits. */
            return a + b * (1.0f - pc_clamp(a, 0.0f, 1.0f));
    }
}

/* ------------------------------------------------------------------ premultiplied alpha helpers
   Host pixels are premultiplied RGBA f32. Glow math is linear, so premultiplied data blurs
   correctly; un-premultiply only where a ratio is needed (hue, luma of the matte). */
static inline f32 pc_unpremul(f32 c, f32 a) { return a > 1e-4f ? c / a : 0.0f; }

/* ------------------------------------------------------------------ parameter reading
   The host hands `nparams` little-endian f64s in declaration order. Sanitise once into an f32
   table, then index with the K_* macros that build.py generates. */
static inline void pc_read_params(const double *pp, f32 *q, int n) {
    for (int i = 0; i < n; i++) {
        double v = pp[i];
        q[i] = (v == v && v > -1e18 && v < 1e18) ? (f32)v : 0.0f;
    }
}
/* A popup arrives as a 0-based index; clamp defensively. */
static inline int pc_popup(f32 v, int lo, int hi) { return (int)pc_clamp((f32)pc_i(v + 0.5f), (f32)lo, (f32)hi); }
/* `scale` is buffer pixels per layer pixel. Sanitise it the same way. */
static inline f32 pc_scale(double scale) {
    return (scale == scale && scale > 0.02 && scale < 50.0) ? (f32)scale : 1.0f;
}
/* Layer time, bounded. */
static inline double pc_time(double t) {
    return (t == t && t < 1.0e6 && t > -1.0e6) ? t : 0.0;
}

#endif /* PRISM_CORE_H */
