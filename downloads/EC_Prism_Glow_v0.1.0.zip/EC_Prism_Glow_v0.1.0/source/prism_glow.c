/*
 * EC Prism Glow - EffectCraft plug-in API v1.
 *
 *   threshold (per channel, matted by alpha)  ->  mip pyramid  ->  octave-spaced gaussians
 *   accumulated per level  ->  one coarse-to-fine collapse  ->  atmosphere  ->  composite
 *
 * Parameter names, order and defaults follow the reference plug-in exactly (see build.py);
 * the implementation is ours, written from the published behaviour of each control and from
 * standard image-processing literature.
 *
 * Point-spread function. The glow is sum_k w_k * G(sigma0 * 2^k) with w_k = PSF_RATIO^k.
 * A single gaussian falls off far too fast to read as optical glow. The geometric stack is a
 * power law: a normalised 2-D gaussian of sigma has peak amplitude proportional to 1/sigma^2,
 * so octave k contributes (PSF_RATIO/4)^k at radius r ~ sigma0*2^k, and substituting
 * k = log2(r/sigma0) gives
 *
 *     PSF(r)  ~  r^-alpha,   alpha = 2 - log2(PSF_RATIO)
 *
 * PSF_RATIO 0.70 puts alpha at about 2.5, between the r^-2 of broad veiling glare and the r^-3
 * of a tight lens bloom - the bright core with a long faint tail that photographic glow has.
 * Each octave's gaussian is area-preserving (box passes preserve the mean) and the stack is
 * normalised by sum(w_k), so widening the glow spreads the same light instead of adding light.
 *
 * Everything in prism_core.h applies: no imports, no libm, NaN/Inf safe, deterministic.
 */
#include "params_gen.h"
#include "prism_core.h"

/* ---------------------------------------------------------------- calibration constants
 * These two numbers carry the entire "matches the reference" surface, deliberately isolated so
 * a calibration pass against reference stills tunes one place. To calibrate: render a single
 * bright pixel, plot radial energy log-log, least-squares fit against reference frame grabs. */
#define WIDTH_REF   0.11f    /* Glow Width 1.0 == sigma0 of 0.11 * the frame's short side */
#define PSF_RATIO   0.70f    /* octave weight ratio; alpha = 2 - log2(ratio) ~= 2.5 */
#define PSF_OCTAVES 6        /* sigma0 .. 32*sigma0 */
#define MAX_MIP     5

static f32 Q[NPARAMS];

/* ---------------------------------------------------------------- threshold planes
 * One pass over the frame builds all three channels of the glow source.
 *
 * Pixels are premultiplied, so the comparison against Threshold is made on the straight colour:
 * a threshold on premultiplied data would make the glow depend on the layer's opacity, which is
 * not what the control means. The emitted energy is then scaled by alpha, which is the role the
 * reference's Matte input plays - it is applied to the source before the glows are generated, so
 * it scales the glow colours without clipping the glows themselves.
 *
 *   e_c = max(straight_c - (Threshold + Threshold Add Color_c), 0) * alpha
 *
 * Glow From Alpha interpolates the source from RGB towards the alpha channel; at 1 all three
 * channels carry alpha, so the glow is white and picks up no colour from the source.           */
static void build_threshold(const f32 *px, f32 *T3, size_t n, int w, int h,
                            f32 thr, const f32 *add, f32 from_alpha) {
    f32 t0 = thr + add[0], t1 = thr + add[1], t2 = thr + add[2];
    for (int y = 0; y < h; y++) {
        const f32 *p = px + (size_t)y * w * 4;
        size_t o = (size_t)y * w;
        for (int x = 0; x < w; x++, p += 4, o++) {
            f32 a = pc_fin(p[3]);
            f32 ac = pc_clamp(a, 0.0f, 1.0f);
            f32 ia = a > 1e-4f ? 1.0f / a : 0.0f;        /* one divide per pixel, not three */
            f32 c0 = pc_fin(p[0]) * ia, c1 = pc_fin(p[1]) * ia, c2 = pc_fin(p[2]) * ia;
            if (from_alpha > 0.0f) {
                c0 = pc_lerp(c0, ac, from_alpha);
                c1 = pc_lerp(c1, ac, from_alpha);
                c2 = pc_lerp(c2, ac, from_alpha);
            }
            f32 e0 = c0 - t0, e1 = c1 - t1, e2 = c2 - t2;
            T3[o]         = e0 > 0.0f ? e0 * ac : 0.0f;
            T3[n + o]     = e1 > 0.0f ? e1 * ac : 0.0f;
            T3[2 * n + o] = e2 > 0.0f ? e2 * ac : 0.0f;
        }
    }
}

/* ---------------------------------------------------------------- octave accumulation
 * Each octave is blurred on the coarsest mip level that still resolves its kernel and
 * accumulated *into that level*; the levels are then collapsed once, coarse to fine, by
 * bilinear up-sample-and-add.
 *
 * Accumulating per level and collapsing once costs one pass per level (sum 4/3 n) instead of one
 * full-resolution up-sample per octave (6 n). The collapse stops at `floor_lvl`, the finest
 * level any octave needed, and the composite samples that plane directly: with a typical Glow
 * Width every octave lands on a deep level, so no full-resolution glow buffer is ever written. */
static void upsample_add(const f32 *src, int sw, int sh, f32 *dst, int dw, int dh,
                         int subpixel, PcTaps *tx, f32 *rowbuf) {
    pc_taps_build(tx, dw, sw, 1, 0.0f);
    if (!subpixel) for (int x = 0; x < dw; x++) tx->t[x] = tx->t[x] < 0.5f ? 0.0f : 1.0f;
    for (int y = 0; y < dh; y++) {
        f32 fy = ((f32)y + 0.5f) * 0.5f - 0.5f;
        int y0 = pc_ifloor(fy); f32 ty = fy - (f32)y0; int y1 = y0 + 1;
        if (y0 < 0) y0 = 0; if (y1 < 0) y1 = 0;
        if (y0 > sh - 1) y0 = sh - 1; if (y1 > sh - 1) y1 = sh - 1;
        if (!subpixel) ty = ty < 0.5f ? 0.0f : 1.0f;
        const f32 *r0 = src + (size_t)y0 * sw, *r1 = src + (size_t)y1 * sw;
        for (int i = 0; i < sw; i++) rowbuf[i] = r0[i] + (r1[i] - r0[i]) * ty;
        f32 *d = dst + (size_t)y * dw;
        for (int x = 0; x < dw; x++) {
            int a = tx->i0[x], b = tx->i1[x];
            d[x] += rowbuf[a] + (rowbuf[b] - rowbuf[a]) * tx->t[x];
        }
    }
}

/* ---------------------------------------------------------------- entry points */
EXPORT("ec_api_version") int ec_api_version(void) { return 1; }
EXPORT("ec_manifest_ptr") int ec_manifest_ptr(void) { return (int)(uintptr_t)MANIFEST; }
EXPORT("ec_manifest_len") int ec_manifest_len(void) { return (int)(sizeof(MANIFEST) - 1); }
EXPORT("ec_alloc") int ec_alloc(int bytes) { return pc_alloc(bytes); }

EXPORT("ec_render")
int ec_render(f32 *px, int w, int h, double *pp, int np, double time, double scale) {
    if (w <= 0 || h <= 0 || w > 16384 || h > 16384 || np < NPARAMS) return 1;
    size_t n = (size_t)w * (size_t)h;
    if (n > 20000000u) return 2;
    pc_read_params(pp, Q, NPARAMS);

    /* `scale` (buffer pixels per layer pixel) is not applied here. It converts a quantity given
     * in *layer* pixels (an absolute pixel count, as EffectCraft's point parameters already
     * arrive) into buffer pixels. Glow Width is not such a quantity: it is a fraction of the
     * frame's own short side, and the buffer's short side already equals the layer's short side
     * times scale, so the conversion happens for free. Multiplying by `scale` again would halve
     * the glow every time the preview resolution halves, instead of keeping it the same size
     * relative to the image - the opposite of what resolution independence means here. `scale`
     * is still sanitised, in case a later control needs it. */
    (void)pc_scale(scale);
    double tt = Q[K_ec_time] != 0.0f ? (double)Q[K_ec_time] : pc_time(time);
    tt = pc_time(tt);

    /* ---- Mocha mask block ------------------------------------------------------------
     * Plug-in API v1 gives an effect one input (this layer, after its masks and the effects
     * above) and flat numeric parameters only: there is no way to reach a Mocha project file or
     * a second layer. The block is declared in full, in the reference's order and with the
     * reference's names and defaults, and is inert while Mocha Project is 0 - which is also how
     * the reference behaves with no project chosen. API 2 adds a `hidden` string parameter and
     * `layer` inputs; the block becomes live there without the panel changing.               */
    int mocha_on = pc_i(Q[K_mocha_project] + 0.5f) > 0 && Q[K_bypass_mocha] == 0.0f;
    f32 mocha_k = 1.0f;                      /* coverage multiplier; 1 == no masking */
    if (mocha_on) {
        f32 op = pc_clamp(Q[K_mocha_opacity], 0.0f, 1.0f);
        if (Q[K_invert_mocha] != 0.0f) op = 1.0f - op;
        int comb = pc_popup(Q[K_combine_masks], 0, 2);
        mocha_k = (comb == 1) ? op : 1.0f;   /* Union with an absent mask is the identity */
        if (Q[K_show_mocha_only] != 0.0f) {
            for (size_t i = 0; i < n; i++) {
                f32 *p = px + i * 4;
                p[0] = p[1] = p[2] = mocha_k; p[3] = 1.0f;
            }
            return 0;
        }
    }

    /* ---- parameters ------------------------------------------------------------------ */
    f32 brightness   = pc_clamp(Q[K_brightness], 0.0f, 100.0f);
    f32 col[3]       = {pc_clamp(Q[K_color], 0.0f, 64.0f),
                        pc_clamp(Q[K_color + 1], 0.0f, 64.0f),
                        pc_clamp(Q[K_color + 2], 0.0f, 64.0f)};
    f32 threshold    = pc_clamp(Q[K_threshold], 0.0f, 100.0f);
    f32 thr_add[3]   = {pc_clamp(Q[K_threshold_add_color], -64.0f, 64.0f),
                        pc_clamp(Q[K_threshold_add_color + 1], -64.0f, 64.0f),
                        pc_clamp(Q[K_threshold_add_color + 2], -64.0f, 64.0f)};
    f32 glow_width   = pc_clamp(Q[K_glow_width], 0.0f, 100.0f);
    f32 width_x      = pc_clamp(Q[K_width_x], 0.0f, 100.0f);
    f32 width_y      = pc_clamp(Q[K_width_y], 0.0f, 100.0f);
    f32 width_c[3]   = {pc_clamp(Q[K_width_red], 0.0f, 100.0f),
                        pc_clamp(Q[K_width_green], 0.0f, 100.0f),
                        pc_clamp(Q[K_width_blue], 0.0f, 100.0f)};
    int subpixel     = Q[K_subpixel] != 0.0f;
    int show         = pc_popup(Q[K_show], 0, 1);
    f32 affect_alpha = pc_clamp(Q[K_affect_alpha], 0.0f, 100.0f);
    f32 from_alpha   = pc_clamp(Q[K_glow_from_alpha], 0.0f, 1.0f);
    f32 under_source = pc_clamp(Q[K_glow_under_source], 0.0f, 1.0f);
    f32 light_bg     = pc_clamp(Q[K_light_background], 0.0f, 1.0f);
    f32 src_opacity  = pc_clamp(Q[K_source_opacity], 0.0f, 1.0f);
    int combine      = pc_popup(Q[K_combine], 0, 4);
    int edge_mode    = pc_popup(Q[K_edge_mode], 0, 1);
    f32 bg_bright    = pc_clamp(Q[K_bg_brightness], 0.0f, 100.0f);
    f32 atmos_amp    = pc_clamp(Q[K_atmosphere_amp], 0.0f, 100.0f);
    f32 atmos_freq   = pc_clamp(Q[K_atmosphere_freq], 0.1f, 20.0f);
    f32 atmos_detail = pc_clamp(Q[K_atmosphere_detail], 0.0f, 1.0f);
    f32 atmos_seed   = pc_clamp(Q[K_atmosphere_seed], 0.0f, 1000.0f);
    f32 atmos_speed  = pc_clamp(Q[K_atmosphere_speed], -100.0f, 100.0f);

    /* Three controls the reference exposes that API v1 cannot carry. They are declared in place,
     * with the reference's names, and documented here rather than renamed or silently dropped.
     *
     *   Expand Borders - the reference adds transparent borders before processing so the result
     *     can include soft edges beyond the original image size. API v1 renders into the layer's
     *     own buffer and cannot ask for padding (API 2 adds EffectPlugin::padding, up to 4096 px
     *     a side). This build therefore always behaves as the reference does with the control
     *     off: "the effect only occurs within the frame and the result will retain an edge at
     *     the borders", which is what the plug-in's own buffer boundary already produces.
     *   Invert Mask - inverts the Matte input. API v1 has no second input, so there is no matte
     *     to invert.
     *   Show Glow Width - the reference's own note is that it "only appears on AE and Premiere,
     *     where on-screen widgets are supported": it toggles a canvas widget, not pixels. A
     *     plug-in cannot draw host overlays.                                                  */
    (void)Q[K_expand_borders]; (void)Q[K_invert_mask]; (void)Q[K_show_glow_width];

    /* ---- early out --------------------------------------------------------------------
     * "A zero glow width still enhances the bright areas; set the brightness parameter to zero
     * if you want to pass the Source through unchanged." So only Brightness 0 is a pass-through;
     * a zero width still adds the un-blurred thresholded image.                               */
    f32 sigma0 = glow_width * WIDTH_REF * (f32)(w < h ? w : h);
    if (brightness <= 0.0f && show == 0) {
        if (bg_bright != 1.0f) {
            for (size_t i = 0; i < n * 4; i += 4) {
                px[i] = pc_fin(px[i]) * bg_bright;
                px[i + 1] = pc_fin(px[i + 1]) * bg_bright;
                px[i + 2] = pc_fin(px[i + 2]) * bg_bright;
            }
        }
        return 0;
    }

    /* ---- level plan ----------------------------------------------------------------------- */
    int mw[MAX_MIP + 1], mh[MAX_MIP + 1];
    size_t mipn[MAX_MIP + 1];
    for (int m = 0; m <= MAX_MIP; m++) {
        mw[m] = pc_mip_w(w, m); mh[m] = pc_mip_w(h, m);
        if (mw[m] < 1) mw[m] = 1;
        if (mh[m] < 1) mh[m] = 1;
        mipn[m] = (size_t)mw[m] * mh[m];
    }
    int oct_lvl[3][PSF_OCTAVES];
    int floor_lvl = MAX_MIP, top_lvl[3] = {0, 0, 0};
    for (int c = 0; c < 3; c++) {
        f32 base = sigma0 * width_c[c];
        for (int k = 0; k < PSF_OCTAVES; k++) {
            f32 sg = base * (f32)(1 << k);
            /* The mip chain is isotropic, so the level must be the one the *narrower* axis can
             * tolerate: picking it from the wider axis would let the 2x2 downsample spread the
             * glow along the axis the user set to zero ("Width X ... Set to 0 for vertical
             * only"). Taking the minimum costs resolution only when the widths are strongly
             * anisotropic, and the box passes are O(1) per pixel whatever the radius, so the
             * extra work is bounded.                                                          */
            f32 narrow = pc_min(sg * width_x, sg * width_y);
            int lvl = pc_level_for(narrow, w, h, MAX_MIP);
            oct_lvl[c][k] = lvl;
            if (lvl < floor_lvl) floor_lvl = lvl;
            if (lvl > top_lvl[c]) top_lvl[c] = lvl;
        }
    }

    /* ---- arena sizing ----------------------------------------------------------------- */
    const int PAD = PC_PAD_MAX;
    int reflect = (edge_mode == PC_EDGE_REFLECT);
    size_t padn = reflect ? (size_t)(w + 2 * PAD) * (size_t)(h + 2 * PAD) : 0;
    size_t blurn = reflect ? padn : mipn[0];

    size_t floats = 0;
    floats += n * 3;                               /* T3: three threshold planes, full res */
    for (int m = 1; m <= MAX_MIP; m++) floats += mipn[m];      /* mip chain of one channel */
    for (int m = 0; m <= MAX_MIP; m++) floats += mipn[m];      /* per-level accumulators */
    floats += mipn[floor_lvl] * 3;                 /* the assembled glow, three channels */
    floats += mipn[0];                             /* lvlbuf: one blurred level, unpadded */
    floats += blurn;                               /* blur scratch */
    if (reflect) floats += padn * 2;               /* mirrored border copy + its blur target */
    floats += (size_t)w + 2 * PAD + 64;            /* box_v column accumulator */
    floats += (size_t)w * 2 + 32;                  /* tap weights + row buffer */
    floats += (size_t)w * 2 + 64;                  /* tap index arrays */
    /* pc_take rounds every block up to a multiple of 4 floats; ~26 blocks are taken, and on a
     * tiny frame that rounding is most of the total. Reserve the slack explicitly. */
    floats += 256;
    size_t atmos_floats = 0;
    f32 atmos_lambda = 0.0f;
    int atmos_on = atmos_amp > 0.0005f;
    if (atmos_on) {
        atmos_lambda = pc_max((f32)(w < h ? w : h) / (atmos_freq * 6.0f), 3.0f);
        atmos_floats = pc_grid_floats(w, h, atmos_lambda) + 8;
        floats += atmos_floats;
    }

    PcArena A;
    if (!pc_arena_begin(&A, px, n, floats)) return 2;
    f32 *T3 = pc_take(&A, n * 3);
    f32 *mip[MAX_MIP + 1], *ACC[MAX_MIP + 1];
    for (int m = 1; m <= MAX_MIP; m++) mip[m] = pc_take(&A, mipn[m]);
    for (int m = 0; m <= MAX_MIP; m++) ACC[m] = pc_take(&A, mipn[m]);
    f32 *GL[3];
    for (int c = 0; c < 3; c++) GL[c] = pc_take(&A, mipn[floor_lvl]);
    f32 *lvlbuf  = pc_take(&A, mipn[0]);
    f32 *tmp     = pc_take(&A, blurn);
    f32 *scratch = reflect ? pc_take(&A, padn) : 0;
    f32 *tmp2    = reflect ? pc_take(&A, padn) : 0;
    f32 *acc     = pc_take(&A, (size_t)w + 2 * PAD + 64);
    f32 *tapw    = pc_take(&A, (size_t)w + 16);
    f32 *rowbuf  = pc_take(&A, (size_t)w + 16);
    int *tapi0   = (int *)pc_take(&A, (size_t)w + 16);
    int *tapi1   = (int *)pc_take(&A, (size_t)w + 16);
    PcTaps taps = {tapi0, tapi1, tapw};

    PcGrid atmos;
    atmos.v = 0;
    if (atmos_on) {
        f32 *gm = pc_take(&A, atmos_floats);
        /* "The cloudy noise evolves over time like real dust clouds": the lattice drifts and its
         * cell values are re-seeded on a slow clock, so the pattern changes rather than sliding. */
        double drift = tt * (double)atmos_speed;
        uint32_t tseed = (uint32_t)pc_i((f32)(drift * 8.0));
        pc_grid_build(&atmos, gm, w, h, atmos_lambda, 0.0f,
                      (f32)(drift * atmos_lambda * 0.35), tseed,
                      (uint32_t)pc_i(atmos_seed * 1000.0f) + 1u);
    }
    if (!pc_arena_ok(&A)) return 3;

    /* ---- threshold (all three channels in one pass over the frame) --------------------- */
    build_threshold(px, T3, n, w, h, threshold, thr_add, from_alpha);

    if (show == 1) {                               /* Show: Threshold */
        for (size_t i = 0; i < n; i++) {
            f32 *p = px + i * 4;
            p[0] = T3[i]; p[1] = T3[n + i]; p[2] = T3[2 * n + i]; p[3] = 1.0f;
        }
        return 0;
    }

    f32 norm = 0.0f;
    { f32 wgt = 1.0f; for (int k = 0; k < PSF_OCTAVES; k++) { norm += wgt; wgt *= PSF_RATIO; } }
    f32 inv_norm = pc_rcp(norm);

    /* ---- per-channel glow -------------------------------------------------------------- */
    for (int c = 0; c < 3; c++) {
        f32 *out = GL[c];
        for (size_t i = 0; i < mipn[floor_lvl]; i++) out[i] = 0.0f;
        f32 base = sigma0 * width_c[c];

        mip[0] = T3 + (size_t)c * n;
        for (int m = 1; m <= top_lvl[c]; m++)
            pc_downsample(mip[m - 1], mw[m - 1], mh[m - 1], mip[m], mw[m], mh[m]);
        for (int m = floor_lvl; m <= top_lvl[c]; m++)
            for (size_t i = 0; i < mipn[m]; i++) ACC[m][i] = 0.0f;

        f32 weight = 1.0f;
        for (int k = 0; k < PSF_OCTAVES; k++) {
            f32 sg = base * (f32)(1 << k);
            f32 sx = sg * width_x, sy = sg * width_y;
            int lvl = oct_lvl[c][k];
            f32 kk = 1.0f / (f32)(1 << lvl);
            f32 *a = ACC[lvl];
            if (pc_max(sx, sy) > 0.05f) {
                pc_blur_edge(mip[lvl], lvlbuf, tmp, acc, mw[lvl], mh[lvl],
                             sx * kk, sy * kk, edge_mode, scratch, tmp2);
                for (size_t i = 0; i < mipn[lvl]; i++) a[i] += weight * lvlbuf[i];
            } else {
                /* zero width: the octave is the thresholded image itself, un-blurred */
                const f32 *src = mip[lvl];
                for (size_t i = 0; i < mipn[lvl]; i++) a[i] += weight * src[i];
            }
            weight *= PSF_RATIO;
        }
        for (int m = top_lvl[c]; m > floor_lvl; m--)
            upsample_add(ACC[m], mw[m], mh[m], ACC[m - 1], mw[m - 1], mh[m - 1],
                         subpixel, &taps, rowbuf);
        for (size_t i = 0; i < mipn[floor_lvl]; i++) out[i] = ACC[floor_lvl][i] * inv_norm;
    }
    if (!pc_arena_ok(&A)) return 3;

    /* ---- composite ----------------------------------------------------------------------
     * With no Background input, the reference uses the Source as the Background, so:
     *
     *   bg      = Source * Bg Brightness
     *   glow    = G * Brightness * Color, modulated by the atmosphere field
     *   combined= Combine(bg, glow)                        Mult / Add / Screen / Diff / Overlay
     *   lit     = bg * (1 + glow)                          the glow casting light on the bg
     *   base    = lerp(combined, lit, Light Background)    at 1, Combine has no effect
     *   under   = glow * (1 - src_alpha) + Source * Source Opacity      Source over the glows
     *   result  = lerp(base, under, Glow Under Source)
     *
     * Alpha: "the maximum of the red, green and blue glow brightness is scaled by [Affect Alpha]
     * and combined with the background Alpha at each pixel."
     *
     * The glow lives on mip level `floor_lvl`; its x taps are the same for all three channels
     * and all rows, so they are built once.                                                  */
    f32 gain[3] = {brightness * col[0] * mocha_k,
                   brightness * col[1] * mocha_k,
                   brightness * col[2] * mocha_k};
    int fw = mw[floor_lvl], fh = mh[floor_lvl];
    f32 fk = 1.0f / (f32)(1 << floor_lvl);
    pc_taps_build(&taps, w, fw, floor_lvl, 0.0f);
    if (!subpixel) for (int x = 0; x < w; x++) tapw[x] = tapw[x] < 0.5f ? 0.0f : 1.0f;

    for (int y = 0; y < h; y++) {
        f32 *p = px + (size_t)y * w * 4;
        f32 fy = ((f32)y + 0.5f) * fk - 0.5f;
        int y0 = pc_ifloor(fy); f32 ty = fy - (f32)y0; int y1 = y0 + 1;
        if (y0 < 0) y0 = 0; if (y1 < 0) y1 = 0;
        if (y0 > fh - 1) y0 = fh - 1; if (y1 > fh - 1) y1 = fh - 1;
        if (!subpixel) ty = ty < 0.5f ? 0.0f : 1.0f;
        const f32 *q0 = GL[0] + (size_t)y0 * fw, *q1 = GL[0] + (size_t)y1 * fw;
        const f32 *r0 = GL[1] + (size_t)y0 * fw, *r1 = GL[1] + (size_t)y1 * fw;
        const f32 *u0 = GL[2] + (size_t)y0 * fw, *u1 = GL[2] + (size_t)y1 * fw;
        for (int x = 0; x < w; x++, p += 4) {
            int a_ = tapi0[x], b_ = tapi1[x];
            f32 t_ = tapw[x];
            f32 qa = q0[a_] + (q0[b_] - q0[a_]) * t_, qb = q1[a_] + (q1[b_] - q1[a_]) * t_;
            f32 ga_ = r0[a_] + (r0[b_] - r0[a_]) * t_, gb_ = r1[a_] + (r1[b_] - r1[a_]) * t_;
            f32 ua = u0[a_] + (u0[b_] - u0[a_]) * t_, ub = u1[a_] + (u1[b_] - u1[a_]) * t_;
            f32 gr = qa + (qb - qa) * ty;
            f32 gg = ga_ + (gb_ - ga_) * ty;
            f32 gb = ua + (ub - ua) * ty;

            if (atmos_on) {
                f32 m = pc_fbm(&atmos, (f32)x, (f32)y, 4, atmos_detail);
                f32 k = pc_max(0.0f, 1.0f + atmos_amp * (m * 2.0f - 1.0f));
                gr *= k; gg *= k; gb *= k;
            }
            gr *= gain[0]; gg *= gain[1]; gb *= gain[2];

            f32 pr = pc_fin(p[0]), pg = pc_fin(p[1]), pb = pc_fin(p[2]);
            f32 pa = pc_clamp(pc_fin(p[3]), 0.0f, 64.0f);
            f32 br = pr * bg_bright, bgn = pg * bg_bright, bb = pb * bg_bright;

            f32 rr = pc_combine(combine, br, gr);
            f32 rg = pc_combine(combine, bgn, gg);
            f32 rb = pc_combine(combine, bb, gb);
            if (light_bg > 0.0f) {
                rr = pc_lerp(rr, br * (1.0f + gr), light_bg);
                rg = pc_lerp(rg, bgn * (1.0f + gg), light_bg);
                rb = pc_lerp(rb, bb * (1.0f + gb), light_bg);
            }

            f32 glow_a = pc_min(1.0f, pc_max(gr, pc_max(gg, gb)) * affect_alpha);
            f32 ralpha = pa + glow_a * (1.0f - pc_clamp(pa, 0.0f, 1.0f));

            if (under_source > 0.0f) {
                f32 sa = pa * src_opacity;
                f32 ia = 1.0f - pc_clamp(sa, 0.0f, 1.0f);
                rr = pc_lerp(rr, gr * ia + pr * src_opacity, under_source);
                rg = pc_lerp(rg, gg * ia + pg * src_opacity, under_source);
                rb = pc_lerp(rb, gb * ia + pb * src_opacity, under_source);
                ralpha = pc_lerp(ralpha, sa + glow_a * (1.0f - pc_clamp(sa, 0.0f, 1.0f)), under_source);
            }

            p[0] = pc_sat(rr, 1.0e6f);
            p[1] = pc_sat(rg, 1.0e6f);
            p[2] = pc_sat(rb, 1.0e6f);
            p[3] = pc_sat(ralpha, 64.0f);
        }
    }
    return pc_arena_ok(&A) ? 0 : 3;
}
