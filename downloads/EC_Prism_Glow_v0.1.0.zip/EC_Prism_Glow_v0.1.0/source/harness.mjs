/*
 * EC Prism test harness.
 *
 * Loads a plug-in .wasm exactly as EffectCraft's sandbox does (no imports at all), drives
 * ec_render over a synthetic frame, and reports what the host would check:
 *   - the module imports nothing
 *   - the five required exports exist and ec_api_version() == 1
 *   - the manifest parses and validates against the API v1 rules
 *   - renders are deterministic, finite, and leave alpha sane
 *   - output at preview scale matches a downscaled full render in character
 *
 * Usage: node harness.mjs <module.wasm> [--w 640] [--h 360] [--scale 1] [--time 0]
 *                                       [--set id=value ...] [--png out.png]
 */
import { readFileSync, writeFileSync } from "node:fs";
import { deflateSync } from "node:zlib";

const argv = process.argv.slice(2);
const file = argv.find(a => !a.startsWith("--"));
if (!file) { console.error("usage: node harness.mjs <module.wasm> [options]"); process.exit(2); }
const opt = (name, dflt) => { const i = argv.indexOf("--" + name); return i < 0 ? dflt : argv[i + 1]; };
const W = +opt("w", 640), H = +opt("h", 360), SCALE = +opt("scale", 1), TIME = +opt("time", 0);
const overrides = [];
for (let i = 0; i < argv.length; i++) if (argv[i] === "--set") overrides.push(argv[i + 1]);

const bytes = readFileSync(file);
const mod = new WebAssembly.Module(bytes);

// ---- 1. the sandbox rule: no imports -------------------------------------------------
const imports = WebAssembly.Module.imports(mod);
if (imports.length) {
  console.error("FAIL: module has imports, EffectCraft refuses it:");
  for (const im of imports) console.error("   " + im.module + "." + im.name + " (" + im.kind + ")");
  process.exit(1);
}

const inst = new WebAssembly.Instance(mod, {});
const E = inst.exports;
for (const name of ["memory", "ec_api_version", "ec_manifest_ptr", "ec_manifest_len", "ec_alloc", "ec_render"])
  if (!(name in E)) { console.error("FAIL: missing export " + name); process.exit(1); }
if (E.ec_api_version() !== 1) { console.error("FAIL: ec_api_version != 1"); process.exit(1); }

// ---- 2. manifest ---------------------------------------------------------------------
const mptr = E.ec_manifest_ptr(), mlen = E.ec_manifest_len();
const manifest = JSON.parse(new TextDecoder().decode(new Uint8Array(E.memory.buffer, mptr, mlen)));
const WIDTH = { slider: 1, angle: 1, checkbox: 1, popup: 1, point: 2, color: 4 };
let flat = 0;
const index = new Map();
for (const p of manifest.params) { index.set(p.id, flat); flat += WIDTH[p.type]; }
console.log(`${manifest.name}  v${manifest.version}  [${manifest.category}]`);
console.log(`  id          ${manifest.id}`);
console.log(`  params      ${manifest.params.length} declared, ${flat} flattened f64`);
console.log(`  module      ${bytes.length} bytes, 0 imports`);

// ---- 3. default parameter vector -----------------------------------------------------
function defaults() {
  const v = [];
  for (const p of manifest.params) {
    if (p.type === "point") { v.push(p.default[0] * W, p.default[1] * H); }     // host sends buffer px
    else if (p.type === "color") v.push(...p.default);
    else if (p.type === "checkbox") v.push(p.default ? 1 : 0);
    else v.push(p.default);
  }
  return v;
}
const params = defaults();
for (const kv of overrides) {
  const eq = kv.indexOf("=");
  const id = kv.slice(0, eq), val = kv.slice(eq + 1);
  if (!index.has(id)) { console.error("FAIL: no parameter " + id); process.exit(1); }
  const p = manifest.params.find(q => q.id === id);
  const at = index.get(id);
  const nums = val.split(",").map(Number);
  for (let i = 0; i < WIDTH[p.type]; i++) params[at + i] = nums[Math.min(i, nums.length - 1)];
}

// ---- 4. synthetic frame: a dark field with bright shapes of known energy ---------------
function makeFrame(w, h) {
  const px = new Float32Array(w * h * 4);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4;
    px[i] = 0.02; px[i + 1] = 0.025; px[i + 2] = 0.035; px[i + 3] = 1;    // dim blue-grey field
  }
  const disc = (cx, cy, r, R, G, B) => {
    for (let y = Math.max(0, cy - r - 1); y < Math.min(h, cy + r + 1); y++)
      for (let x = Math.max(0, cx - r - 1); x < Math.min(w, cx + r + 1); x++) {
        const d = Math.hypot(x + .5 - cx, y + .5 - cy);
        const k = Math.max(0, Math.min(1, r - d + .5));
        if (k <= 0) continue;
        const i = (y * w + x) * 4;
        px[i] += k * R; px[i + 1] += k * G; px[i + 2] += k * B;
      }
  };
  disc(Math.round(w * 0.22), Math.round(h * 0.5), Math.round(h * 0.06), 4, 4, 4);      // HDR white
  disc(Math.round(w * 0.5),  Math.round(h * 0.5), Math.round(h * 0.03), 1.6, 0.5, 0.1); // warm
  disc(Math.round(w * 0.78), Math.round(h * 0.5), Math.round(h * 0.09), 0.9, 0.9, 0.95);// near-white
  for (let y = Math.round(h * 0.80); y < Math.round(h * 0.86); y++)                      // bright bar
    for (let x = Math.round(w * 0.2); x < Math.round(w * 0.8); x++) {
      const i = (y * w + x) * 4; px[i] += 2.5; px[i + 1] += 2.2; px[i + 2] += 1.0;
    }
  return px;
}

// ---- 5. render -----------------------------------------------------------------------
function render(w, h, scale, time, pv) {
  const np = pv.length;
  const bytesNeeded = np * 8 + w * h * 16;
  const base = E.ec_alloc(bytesNeeded);
  if (base <= 0) throw new Error("ec_alloc failed");
  const mem = E.memory.buffer;
  new Float64Array(mem, base, np).set(pv);
  const frame = makeFrame(w, h);
  new Float32Array(mem, base + np * 8, w * h * 4).set(frame);
  const t0 = process.hrtime.bigint();
  const rc = E.ec_render(base + np * 8, w, h, base, np, time, scale);
  const ms = Number(process.hrtime.bigint() - t0) / 1e6;
  // memory may have grown during the render, so re-view it
  const out = new Float32Array(E.memory.buffer, base + np * 8, w * h * 4).slice();
  return { rc, ms, out, inp: frame };
}

const r = render(W, H, SCALE, TIME, params);
if (r.rc !== 0) { console.error(`FAIL: ec_render returned ${r.rc}`); process.exit(1); }

// ---- 6. checks -----------------------------------------------------------------------
let bad = 0, maxv = 0, sumIn = 0, sumOut = 0, aMin = Infinity, aMax = -Infinity;
for (let i = 0; i < r.out.length; i += 4) {
  for (let c = 0; c < 3; c++) {
    const v = r.out[i + c];
    if (!Number.isFinite(v)) bad++;
    if (v > maxv) maxv = v;
    sumOut += v; sumIn += r.inp[i + c];
  }
  const a = r.out[i + 3];
  if (!Number.isFinite(a)) bad++;
  if (a < aMin) aMin = a;
  if (a > aMax) aMax = a;
}
const r2 = render(W, H, SCALE, TIME, params);
let drift = 0;
for (let i = 0; i < r.out.length; i++) drift = Math.max(drift, Math.abs(r.out[i] - r2.out[i]));

const pass = (ok, label, detail) =>
  console.log(`  ${ok ? "ok  " : "FAIL"}  ${label}${detail ? "   " + detail : ""}`);
console.log(`\n  render      ${W}x${H} scale ${SCALE} t=${TIME}  ->  rc 0 in ${r.ms.toFixed(1)} ms`);
pass(bad === 0, "finite output", bad ? bad + " non-finite values" : "");
pass(drift === 0, "deterministic", drift ? "max drift " + drift : "two renders bit-identical");
pass(aMin >= 0 && aMax <= 64, "alpha in range", `[${aMin.toFixed(3)}, ${aMax.toFixed(3)}]`);
pass(sumOut >= sumIn * 0.99, "adds light", `energy x${(sumOut / sumIn).toFixed(2)}, peak ${maxv.toFixed(2)}`);
if (bad || drift) process.exit(1);

// ---- 7. optional PNG (tonemapped, sRGB) ----------------------------------------------
const pngPath = opt("png", null);
if (pngPath) {
  const raw = Buffer.alloc((W * 3 + 1) * H);
  let o = 0;
  const enc = v => {
    const x = v <= 0 ? 0 : v / (1 + v);                       // Reinhard, so HDR is visible
    const s = x <= 0.0031308 ? 12.92 * x : 1.055 * Math.pow(x, 1 / 2.4) - 0.055;
    return Math.max(0, Math.min(255, Math.round(s * 255)));
  };
  for (let y = 0; y < H; y++) {
    raw[o++] = 0;
    for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4;
      raw[o++] = enc(r.out[i]); raw[o++] = enc(r.out[i + 1]); raw[o++] = enc(r.out[i + 2]);
    }
  }
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type, "ascii"), data]);
    const crcTable = chunk.t || (chunk.t = (() => {
      const t = new Int32Array(256);
      for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c; }
      return t;
    })());
    let c = ~0; for (const b of body) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8);
    const crc = Buffer.alloc(4); crc.writeUInt32BE((~c) >>> 0);
    return Buffer.concat([len, body, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4);
  ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  writeFileSync(pngPath, Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    chunk("IHDR", ihdr), chunk("IDAT", deflateSync(raw)), chunk("IEND", Buffer.alloc(0)),
  ]));
  console.log(`  png         ${pngPath}`);
}
console.log("");
