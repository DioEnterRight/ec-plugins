#!/usr/bin/env python3
"""Builds prism_glow.wasm - EC Prism Glow.

Parameter names, order, defaults and ranges are the reference plug-in's, verbatim, so that
existing muscle memory, tutorials and parameter notes carry over unchanged. Only the product
name is ours.

Two reference controls have no equivalent in EffectCraft plug-in API v1 and are therefore not
declared: "Load Preset" and "Save Preset" are push-buttons (API v1 has slider / angle /
checkbox / popup / point / color only), and EffectCraft provides preset load/save itself through
Effect Controls. Nothing else is renamed, reordered or dropped.

API v1 has no parameter groups, so declaration order *is* the panel tree. Keep it identical.
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "common"))
import ecbuild

HERE = os.path.dirname(os.path.abspath(__file__))
P = ecbuild.Params()

# ---------------------------------------------------------------- Mocha mask block
# The shared block every reference effect carries at the top of its panel. It stays inert while
# Mocha Project is 0 (no project chosen), which is also how the reference behaves with no project.
P.slider("mocha_project",   "Mocha Project",      0,    0, 1000, smax=16,  dec=0)
P.slider("blur_mocha",      "Blur Mocha",         0,    0, 100,  smax=20,  dec=2)
P.slider("mocha_opacity",   "Mocha Opacity",      1,    0, 1,              dec=3)
P.check ("invert_mocha",    "Invert Mocha",       False)
P.slider("resize_mocha",    "Resize Mocha",       1,    0, 2,              dec=3)
P.slider("resize_rel_x",    "Resize Rel X",       1,    0, 2,              dec=3)
P.slider("resize_rel_y",    "Resize Rel Y",       1,    0, 2,              dec=3)
P.point ("shift_mocha",     "Shift Mocha: X & Y", [0.0, 0.0])
P.slider("dilate_mocha",    "Dilate Mocha",       0, -100, 100, smin=-20, smax=20, dec=2)
P.popup ("dilation_quality","Dilation Quality",   ["Fast", "High"], 0)
P.check ("bypass_mocha",    "Bypass Mocha",       False)
P.check ("show_mocha_only", "Show Mocha Only",    False)
P.popup ("combine_masks",   "Combine Masks",      ["Union", "Intersect", "Mocha Only"], 0)

# ---------------------------------------------------------------- glow
P.slider("brightness",      "Brightness",         2,    0, 100,  smax=10,  dec=3)
P.color ("color",           "Color",              [1.0, 1.0, 1.0])
P.slider("threshold",       "Threshold",          0.5,  0, 100,  smax=2,   dec=3)
P.color ("threshold_add_color", "Threshold Add Color", [0.0, 0.0, 0.0])
P.slider("glow_width",      "Glow Width",         0.4,  0, 100,  smax=2,   dec=3)
P.slider("width_x",         "Width X",            1,    0, 100,  smax=4,   dec=3)
P.slider("width_y",         "Width Y",            1,    0, 100,  smax=4,   dec=3)
P.slider("width_red",       "Width Red",          1,    0, 100,  smax=4,   dec=3)
P.slider("width_green",     "Width Green",        1.2,  0, 100,  smax=4,   dec=3)
P.slider("width_blue",      "Width Blue",         1.4,  0, 100,  smax=4,   dec=3)
P.check ("subpixel",        "Subpixel",           True)
P.popup ("show",            "Show",               ["Result", "Threshold"], 0)
P.slider("affect_alpha",    "Affect Alpha",       0,    0, 100,  smax=1,   dec=3)
P.slider("glow_from_alpha", "Glow From Alpha",    0,    0, 1,              dec=3)
P.slider("glow_under_source","Glow Under Source", 0,    0, 1,              dec=3)
P.slider("light_background","Light Background",   0,    0, 1,              dec=3)
P.slider("source_opacity",  "Source Opacity",     1,    0, 1,              dec=3)
P.popup ("combine",         "Combine",            ["Mult", "Add", "Screen", "Difference", "Overlay"], 2)
P.popup ("edge_mode",       "Edge Mode",          ["Transparent", "Reflect"], 1)
P.slider("bg_brightness",   "Bg Brightness",      1,    0, 100,  smax=4,   dec=3)
P.check ("expand_borders",  "Expand Borders",     False)
P.check ("invert_mask",     "Invert Mask",        False)
P.slider("atmosphere_amp",  "Atmosphere Amp",     0,    0, 100,  smax=2,   dec=3)
P.slider("atmosphere_freq", "Atmosphere Freq",    1,    0.1, 20, smax=10,  dec=3)
P.slider("atmosphere_detail","Atmosphere Detail", 0.6,  0, 1,              dec=3)
P.slider("atmosphere_seed", "Atmosphere Seed",    0.123, 0, 1000, smax=10, dec=3)
P.slider("atmosphere_speed","Atmosphere Speed",   1, -100, 100, smin=-10, smax=10, dec=3)
P.check ("show_glow_width", "Show Glow Width",    True)

# ---------------------------------------------------------------- EC extensions (appended, never interleaved)
# EffectCraft plug-in API v1 caches a plug-in's output by its parameter values, so an effect that
# animates on `time` alone would be served a stale frame. Driving this with the expression
#   time - thisLayer.startTime
# makes the cache key change every frame. 0 means "use the host's time", which is correct for
# everything except Atmosphere Speed.
P.slider("ec_time", "Time (s)", 0, -100000, 100000, smin=0, smax=60, dec=4)

manifest = {
    "api": 1,
    "id": "org.dioenterright.ec-prism.glow",
    "name": "EC Prism Glow",
    "category": "Stylize",
    "version": "0.1.0",
    "author": "DioEnterRight",
    "description": "Thresholded multi-scale glow with per-channel width dispersion. "
                   "Clean-room implementation from published parameter behaviour; "
                   "parameter names and order follow the reference plug-in.",
}

ecbuild.emit(HERE, manifest, P.items, "prism_glow.c", "prism_glow.wasm")
