/*
 * Behavioural conformance tests for EC Prism Glow.
 *
 * Every assertion here is a sentence from the reference plug-in's own published documentation,
 * turned into something measurable. This is what "1:1" is checked against: not a pixel diff
 * against a render we cannot produce, but the documented behaviour of every control.
 *
 * Usage: node behaviour.mjs ../glow/prism_glow.wasm
 */
import { readFileSync } from "node:fs";

const file = process.argv[2];
if (!file) { console.error("usage: node behaviour.mjs <module.wasm>"); process.exit(2); }
const mod = new WebAssembly.Module(readFileSync(file));
if (WebAssembly.Module.imports(mod).length) { console.error("module has imports"); process.exit(1); }
const E = new WebAssembly.Instance(mod, {}).exports;
const manifest = JSON.parse(new TextDecoder().decode(
  new Uint8Array(E.memory.buffer, E.ec_manifest_ptr(), E.ec_manifest_len())));

const WIDTH = { slider: 1, angle: 1, checkbox: 1, popup: 1, point: 2, color: 4 };
const index = new Map();
{ let f = 0; for (const p of manifest.params) { index.set(p.id, f); f += WIDTH[p.type]; } }

const W = 192, H = 192, CX = 96, CY = 96;

/* Test frames, built straight (non-premultiplied) and then premultiplied, since that is what
 * the host hands the plug-in. `kind` picks what is in the frame, so each assertion gets a frame
 * that isolates the one thing it is checking. */
function frame(kind, w = W, h = H) {
  const px = new Float32Array(w * h * 4);
  const put = (x, y, r, g, b, a) => {              // r,g,b straight; stored premultiplied
    if (x < 0 || x >= w || y < 0 || y >= h) return;
    const i = (y * w + x) * 4;
    px[i] = r * a; px[i + 1] = g * a; px[i + 2] = b * a; px[i + 3] = a;
  };
  const bgA = (kind === "transparent" || kind === "soft") ? 0 : 1;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) put(x, y, 0, 0, 0, bgA);
  const disc = (cx, cy, rad, r, g, b, a) => {
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++)
      if (Math.hypot(x + .5 - cx, y + .5 - cy) <= rad) put(x, y, r, g, b, a);
  };
  const sx = w / W, sy = h / H, rs = Math.min(sx, sy);
  if (kind === "white")       disc(CX * sx, CY * sy, 6 * rs, 1, 1, 1, 1);
  if (kind === "dim")         disc(CX * sx, CY * sy, 6 * rs, 0.75, 0.75, 0.75, 1);   // above the default 0.5 threshold
  if (kind === "red")         disc(CX * sx, CY * sy, 6 * rs, 1, 0, 0, 1);
  if (kind === "soft")        disc(CX * sx, CY * sy, 6 * rs, 1, 1, 1, 0.5);   // transparent bg, soft disc
  if (kind === "transparent") disc(CX * sx, CY * sy, 6 * rs, 1, 1, 1, 1);      // transparent bg, opaque disc
  if (kind === "ramp")        for (let y = 0; y < h; y++) for (let x = 0; x < w; x++)
                                 put(x, y, x / (w - 1), x / (w - 1), x / (w - 1), 1);
  if (kind === "edge")        disc(0, CY * sy, 5 * rs, 1, 1, 1, 1);           // half off the left border
  return px;
}

function render(set = {}, kind = "white", time = 0, scale = 1, w = W, h = H) {
  const pv = [];
  for (const p of manifest.params) {
    if (p.type === "point") pv.push(p.default[0] * w, p.default[1] * h);
    else if (p.type === "color") pv.push(...p.default);
    else if (p.type === "checkbox") pv.push(p.default ? 1 : 0);
    else pv.push(p.default);
  }
  for (const [id, v] of Object.entries(set)) {
    const p = manifest.params.find(q => q.id === id);
    if (!p) throw new Error("no parameter " + id);
    const at = index.get(id), nums = [].concat(v);
    for (let i = 0; i < WIDTH[p.type]; i++) pv[at + i] = nums[Math.min(i, nums.length - 1)];
  }
  const base = E.ec_alloc(pv.length * 8 + w * h * 16);
  new Float64Array(E.memory.buffer, base, pv.length).set(pv);
  const inp = frame(kind, w, h);
  new Float32Array(E.memory.buffer, base + pv.length * 8, w * h * 4).set(inp);
  const rc = E.ec_render(base + pv.length * 8, w, h, base, pv.length, time, scale);
  if (rc !== 0) throw new Error("ec_render rc " + rc);
  return { out: new Float32Array(E.memory.buffer, base + pv.length * 8, w * h * 4).slice(), inp, w, h };
}

const at = (r, x, y) => { const i = (y * r.w + x) * 4; return [r.out[i], r.out[i + 1], r.out[i + 2], r.out[i + 3]]; };
const atBuf = (buf, w, x, y) => { const i = (y * w + x) * 4; return [buf[i], buf[i+1], buf[i+2], buf[i+3]]; };
const sum = buf => { let s = 0; for (let i = 0; i < buf.length; i += 4) s += buf[i] + buf[i + 1] + buf[i + 2]; return s; };
const maxAbsDiff = (a, b) => { let m = 0; for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i] - b[i])); return m; };
const litPixels = (buf, thr) => { let c = 0; for (let i = 0; i < buf.length; i += 4) if (buf[i] + buf[i+1] + buf[i+2] > thr) c++; return c; };

let pass = 0, fail = 0;
function check(name, quote, ok, detail = "") {
  if (ok) { pass++; console.log(`  ok    ${name}${detail ? "   " + detail : ""}`); }
  else { fail++; console.log(`  FAIL  ${name}${detail ? "   " + detail : ""}\n          doc: "${quote}"`); }
}

console.log(`\n${manifest.name} - behavioural conformance\n`);

// --- Brightness -----------------------------------------------------------------------
{
  const r = render({ brightness: 0 });
  check("Brightness 0 passes the Source through unchanged",
        "set the brightness parameter to zero if you want to pass the Source through unchanged",
        maxAbsDiff(r.out, r.inp) === 0, "max diff " + maxAbsDiff(r.out, r.inp));
}
// --- Glow Width 0 (uses a sub-saturated disc so an increase is visible below the 1.0 cap) -----
{
  const r = render({ glow_width: 0 }, "dim");
  const centre = at(r, CX, CY)[0], inCentre = at({ out: r.inp, w: r.w }, CX, CY)[0];
  check("a zero Glow Width still enhances the bright areas",
        "Note that a zero glow width still enhances the bright areas",
        centre > inCentre + 1e-4, `centre ${inCentre.toFixed(3)} -> ${centre.toFixed(3)}`);
}
// --- Threshold: measured on Show:Threshold, which is exact and unblurred -----------------
{
  const lit = t => litPixels(render({ show: 1, threshold: t }, "ramp").out, 1e-6);
  const a = lit(0), b = lit(0.5), c = lit(0.9);
  check("raising Threshold glows at fewer places",
        "A value of 0.9 causes glows at only the brightest spots. A value of 0 causes glows for every non-black area",
        a > b && b > c, `thresholded px: thr0 ${a}, thr0.5 ${b}, thr0.9 ${c} (of ${W * H})`);
}
// --- Threshold Add Color --------------------------------------------------------------
{
  const base = sum(render({}, "red").out);
  const red  = sum(render({ threshold_add_color: [1, 0, 0, 1] }, "red").out);
  check("Threshold Add Color raises the threshold on that colour",
        "This can be used to raise the threshold on a specific color and thereby reduce the glows generated on areas of the source clip containing that color",
        red < base, `energy ${base.toFixed(1)} -> ${red.toFixed(1)}`);
}
// --- Width Red/Green/Blue equal -> glow matches source colour --------------------------
{
  const eq = render({ width_red: 1, width_green: 1, width_blue: 1 }, "red");
  const [r, g, b] = at(eq, CX + 20, CY);
  check("equal R/G/B widths: the glow matches the colour of the source",
        "If the red, green, and blue widths are equal, the glows will match the color of the source clip",
        r > 1e-3 && g < r * 1e-3 && b < r * 1e-3, `rgb ${r.toFixed(4)} ${g.toFixed(5)} ${b.toFixed(5)}`);
}
// --- unequal widths -> colour varies with distance ------------------------------------
{
  const d = render({}, "white");                        // defaults 1 / 1.2 / 1.4
  const ratio = p => { const [r, g, b] = at(d, CX + p, CY); return b / Math.max(r, 1e-9); };
  const near = ratio(12), far = ratio(45);
  check("unequal R/G/B widths: the glow varies in colour with distance",
        "If they are not equal, the glows will vary in color with distance",
        far > near * 1.05, `blue/red ${near.toFixed(3)} at 12px -> ${far.toFixed(3)} at 45px`);
}
// --- Width X / Width Y ----------------------------------------------------------------
{
  const v = render({ width_x: 0 });
  const horiz = at(v, CX + 30, CY)[0], vert = at(v, CX, CY + 30)[0];
  check("Width X 0 gives vertical spread only",
        "Scales the horizontal glow width. Set to 0 for vertical only",
        vert > 1e-4 && horiz < vert * 0.02, `h ${horiz.toExponential(2)} vs v ${vert.toExponential(2)}`);
  const hh = render({ width_y: 0 });
  const h2 = at(hh, CX + 30, CY)[0], v2 = at(hh, CX, CY + 30)[0];
  check("Width Y 0 gives horizontal spread only",
        "Scales the vertical glow width. Set to 0 for horizontal only",
        h2 > 1e-4 && v2 < h2 * 0.02, `h ${h2.toExponential(2)} vs v ${v2.toExponential(2)}`);
}
// --- Glow From Alpha ------------------------------------------------------------------
{
  const r = render({ glow_from_alpha: 1 }, "red");
  const [gr, gg, gb] = at(r, CX + 20, CY);
  const spread = Math.max(gr, gg, gb) - Math.min(gr, gg, gb);
  check("Glow From Alpha 1: the glow picks up no colour from the source",
        "In this case the glows will not pick up color from the source and will typically be brighter",
        gg > 1e-4 && spread < Math.max(gr, gg, gb) * 0.35,
        `rgb ${gr.toFixed(4)} ${gg.toFixed(4)} ${gb.toFixed(4)}`);
}
// --- Light Background overrides Combine -----------------------------------------------
{
  const outs = [0, 1, 2, 3, 4].map(c => render({ light_background: 1, combine: c }).out);
  let m = 0;
  for (let i = 1; i < outs.length; i++) m = Math.max(m, maxAbsDiff(outs[0], outs[i]));
  check("Light Background 1 makes Combine irrelevant",
        "This parameter has no effect if Light BG is set to 1",
        m === 0, m === 0 ? "all five Combine modes identical" : "max diff " + m);
}
// --- Light Background does something at all -------------------------------------------
{
  const off = render({ light_background: 0 }).out, on = render({ light_background: 1 }).out;
  check("Light Background changes the look",
        "Increase this to give a look of the glow casting light onto the background image",
        maxAbsDiff(off, on) > 1e-4);
}
// --- Glow Under Source ----------------------------------------------------------------
{
  const r = render({ glow_under_source: 1 }, "white");
  const [cr] = at(r, CX, CY), inC = at({ out: r.inp, w: r.w }, CX, CY)[0];
  check("Glow Under Source 1 composites the Source over the glows",
        "Set to 1 to composite the Source input over the glows",
        Math.abs(cr - inC) < 1e-5, `opaque source centre ${inC} -> ${cr.toFixed(6)}`);
}
// --- Source Opacity does not affect glow generation -------------------------------------
// Generation (threshold + blur) happens before compositing and before Glow Under Source is
// consulted at all; with Glow Under Source at its default (0), Source Opacity is not even read
// by the composite path, so the whole frame - not just a sample point - must be identical.
{
  const a = render({ source_opacity: 1 }).out;
  const b = render({ source_opacity: 0 }).out;
  check("Source Opacity does not affect the generation of the glows",
        "This does not affect the generation of the glows themselves",
        maxAbsDiff(a, b) === 0, "whole-frame diff " + maxAbsDiff(a, b));
}
// --- Affect Alpha: transparent background so the alpha contribution is visible ----------
{
  const off = render({ affect_alpha: 0 }, "soft").out;
  const on  = render({ affect_alpha: 1 }, "soft").out;
  const [, , , aOff] = atBuf(off, W, CX + 18, CY), [, , , aOn] = atBuf(on, W, CX + 18, CY);
  check("Affect Alpha adds glow opacity to the output alpha",
        "The maximum of the red, green, and blue glow brightness is scaled by this value and combined with the background Alpha at each pixel",
        aOn > aOff + 1e-5, `alpha at transparent bg ${aOff.toFixed(5)} -> ${aOn.toFixed(5)}`);
}
// --- Show: Threshold is exact ----------------------------------------------------------
{
  const r = render({ show: 1, threshold: 0.25 }, "ramp");
  let worst = 0;
  for (let x = 0; x < W; x++) {
    const want = Math.max(x / (W - 1) - 0.25, 0);
    worst = Math.max(worst, Math.abs(at(r, x, 10)[0] - want));
  }
  check("Show: Threshold shows exactly max(source - threshold, 0)",
        "Shows the thresholded image that is used to generate the glow",
        worst < 1e-6, "max error " + worst.toExponential(2));
}
// --- Edge Mode: a dim disc straddling the border; Reflect must look brighter near the edge ---
{
  const t = render({ edge_mode: 0, glow_width: 1.5 }, "edge");
  const rfl = render({ edge_mode: 1, glow_width: 1.5 }, "edge");
  const e1 = at(t, 22, CY)[0], e2 = at(rfl, 22, CY)[0];   // outside the disc itself (radius 5), inside the blur
  check("Edge Mode Reflect keeps the glow bright at the border",
        "Determines the behavior when accessing areas outside the source image",
        e2 > e1 * 1.02, `near the border ${e1.toFixed(5)} transparent vs ${e2.toFixed(5)} reflect`);
}
// --- Atmosphere -------------------------------------------------------------------------
{
  const a = render({ atmosphere_amp: 0 }).out, b = render({ atmosphere_amp: 0.8 }).out;
  check("Atmosphere Amp 0 gives a smooth glow",
        "Zero gives a smooth glow, higher values give more dusty look",
        maxAbsDiff(a, b) > 1e-4);
  const s0 = render({ atmosphere_amp: 0.8, atmosphere_speed: 0, ec_time: 0 }).out;
  const s1 = render({ atmosphere_amp: 0.8, atmosphere_speed: 0, ec_time: 5 }).out;
  check("Atmosphere Speed 0 gives a static pattern",
        "Set to zero for a static pattern",
        maxAbsDiff(s0, s1) === 0, "t=0 and t=5 identical");
  const m0 = render({ atmosphere_amp: 0.8, atmosphere_speed: 1, ec_time: 0 }).out;
  const m1 = render({ atmosphere_amp: 0.8, atmosphere_speed: 1, ec_time: 3 }).out;
  check("Atmosphere Speed non-zero evolves the pattern over time",
        "this parameter controls how fast the cloud pattern changes over time",
        maxAbsDiff(m0, m1) > 1e-5);
  const d0 = render({ atmosphere_amp: 0.8, atmosphere_seed: 0.123 }).out;
  const d1 = render({ atmosphere_amp: 0.8, atmosphere_seed: 7.5 }).out;
  check("Atmosphere Seed changes the pattern and is repeatable",
        "different seeds give different results and the same value should give a repeatable result",
        maxAbsDiff(d0, d1) > 1e-5 &&
        maxAbsDiff(d0, render({ atmosphere_amp: 0.8, atmosphere_seed: 0.123 }).out) === 0);
}
// --- energy conservation across width ---------------------------------------------------
{
  const e = wv => sum(render({ glow_width: wv, combine: 1 }).out);   // Add, so energy is readable
  const narrow = e(0.2), wide = e(1.2);
  const ratio = wide / narrow;
  check("widening the glow spreads light rather than adding it",
        "Glow Width: Scales the glow distance",
        ratio > 0.8 && ratio < 1.25, `total light x${ratio.toFixed(3)} from width 0.2 to 1.2`);
}
// --- resolution independence: a half-size buffer (a half-res preview) gives the same
// proportional glow as the full-size buffer, sampled at the corresponding position ----------
{
  const full = render({}, "white", 0, 1, 192, 192);
  const half = render({}, "white", 0, 0.5, 96, 96);
  const prof = (r, dFull) => at(r, Math.round(r.w / 2 + dFull * (r.w / 192)), Math.round(r.h / 2))[0];
  const fullAt = prof(full, 40), halfAt = prof(half, 40);
  const rel = Math.abs(fullAt - halfAt) / Math.max(fullAt, 1e-9);
  check("the glow looks the same at a smaller preview resolution",
        "a fraction of the frame's own short side scales with the buffer, so a half-size preview buffer reproduces the same look",
        rel < 0.15, `glow at the same proportional offset: ${fullAt.toFixed(4)} (192x192) vs ${halfAt.toFixed(4)} (96x96, half-res preview), differ by ${(rel * 100).toFixed(1)}%`);
}

console.log(`\n  ${pass} passed, ${fail} failed\n`);
process.exit(fail ? 1 : 0);
