// Native test harness for ec_twitch.wasm (runs in Node/V8 - speed numbers are indicative only, not wasmi).
import fs from "node:fs";
import crypto from "node:crypto";

const wasmBytes = fs.readFileSync(new URL("./ec_twitch.wasm", import.meta.url));
const manifest = JSON.parse(fs.readFileSync(new URL("./manifest.json", import.meta.url), "utf8"));

let failed = 0;
const ok = (cond, msg) => { if (!cond) { failed++; console.log("  FAIL:", msg); } else console.log("  ok:  ", msg); };

// ---------- module-level checks
const mod = new WebAssembly.Module(wasmBytes);
ok(WebAssembly.Module.imports(mod).length === 0, "module has zero imports");
const exps = WebAssembly.Module.exports(mod).map((e) => e.name).sort();
console.log("  exports:", exps.join(", "));
for (const n of ["memory", "ec_api_version", "ec_manifest_ptr", "ec_manifest_len", "ec_alloc", "ec_render"])
  ok(exps.includes(n), "exports " + n);

function newInstance() {
  const inst = new WebAssembly.Instance(mod, {});
  const x = inst.exports;
  return {
    x,
    render(params, px, w, h, time, scale = 1) {
      const nb = params.length * 8 + w * h * 16;
      const base = x.ec_alloc(nb);
      if (!base) throw new Error("alloc failed");
      const mem = x.memory.buffer;
      new Float64Array(mem, base, params.length).set(params);
      const pptr = base + params.length * 8;
      new Float32Array(mem, pptr, w * h * 4).set(px);
      const rc = x.ec_render(pptr, w, h, base, params.length, time, scale);
      const out = new Float32Array(x.memory.buffer, pptr, w * h * 4).slice();
      return { rc, out };
    },
  };
}

const A = newInstance();
ok(A.x.ec_api_version() === 1, "api version 1");
const mtxt = Buffer.from(A.x.memory.buffer, A.x.ec_manifest_ptr(), A.x.ec_manifest_len()).toString("utf8");
const man2 = JSON.parse(mtxt);
ok(man2.api === 1 && man2.params.length === manifest.params.length, "embedded manifest parses, " + man2.params.length + " params");
ok(JSON.stringify(man2) === JSON.stringify(manifest), "embedded manifest == manifest.json");

// ---------- param vector helpers (flatten like the host: point=2, color=4)
const W = 160, H = 90;
const idxOf = {}; let n = 0;
for (const p of manifest.params) { idxOf[p.id] = n; n += p.type === "point" ? 2 : p.type === "color" ? 4 : 1; }
ok(n === 66, "flattened param count = " + n);
function defaults(w = W, h = H) {
  const v = new Float64Array(n);
  for (const p of manifest.params) {
    const i = idxOf[p.id];
    if (p.type === "point") { v[i] = p.default[0] * w; v[i + 1] = p.default[1] * h; }
    else if (p.type === "color") p.default.forEach((c, k) => (v[i + k] = c));
    else v[i] = p.type === "checkbox" ? (p.default ? 1 : 0) : p.default;
  }
  return v;
}
const set = (v, o) => { for (const [k, val] of Object.entries(o)) v[idxOf[k]] = val; return v; };

function makeImage(w = W, h = H) {
  const px = new Float32Array(w * h * 4);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4;
    const chk = ((x >> 3) + (y >> 3)) & 1;
    px[i] = (x / w) * (0.6 + 0.4 * chk); px[i + 1] = (y / h) * (0.6 + 0.4 * chk); px[i + 2] = 0.3 + 0.4 * chk; px[i + 3] = 1;
  }
  return px;
}
const IMG = makeImage();
const hash = (f32) => crypto.createHash("sha1").update(Buffer.from(f32.buffer, f32.byteOffset, f32.byteLength)).digest("hex");
const maxDiff = (a, b) => { let m = 0; for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i] - b[i])); return m; };
const allFinite = (a) => { for (let i = 0; i < a.length; i++) if (!Number.isFinite(a[i])) return false; return true; };

// ---------- 1. identity when everything is off
console.log("\n[identity]");
{
  const r = A.render(defaults(), IMG, W, H, 1.234);
  ok(r.rc === 0 && hash(r.out) === hash(IMG), "all operators off -> bit-identical output");
}

// ---------- 2. operator activity statistics (60 s @ 24 fps)
console.log("\n[activity: fraction of frames where the operator changes the image, defaults, 1 Hz]");
const OPS = ["blur", "color", "light", "scale", "slide"];
const firstActive = {};
for (const op of OPS) {
  const v = set(defaults(), { ["en_" + op]: 1, quality: 1 });
  let act = 0, total = 24 * 60, first = null;
  for (let f = 0; f < total; f++) {
    const t = f / 24;
    const r = A.render(v, IMG, W, H, t);
    if (r.rc !== 0 || !allFinite(r.out)) { ok(false, op + " rc/finite at t=" + t); break; }
    if (maxDiff(r.out, IMG) > 1e-6) { act++; if (first === null) first = t; }
  }
  firstActive[op] = first;
  console.log(`  ${op.padEnd(6)} active ${(100 * act / total).toFixed(1)}% of frames, first at t=${first}`);
  ok(act > 0 && act < total, op + " produces sparse twitches");
}

// ---------- 3. determinism: order independence, cold vs sequential, two instances
console.log("\n[determinism]");
{
  const v = set(defaults(), { en_blur: 1, en_color: 1, en_light: 1, en_scale: 1, en_slide: 1, slide_rgb: 30, seed: 7 });
  const times = []; for (let f = 0; f < 120; f++) times.push(f / 24);
  const B = newInstance(), C = newInstance();
  const seqHash = times.map((t) => hash(B.render(v, IMG, W, H, t).out));
  const order = times.map((_, i) => i).sort((a, b) => ((a * 7919) % 120) - ((b * 7919) % 120));
  const shuf = new Array(times.length);
  for (const i of order) shuf[i] = hash(C.render(v, IMG, W, H, times[i]).out);   // shuffled order, other instance
  ok(seqHash.every((h, i) => h === shuf[i]), "120 frames identical: sequential vs shuffled order, separate instances");
  const cold = times.map((t) => hash(newInstance().render(v, IMG, W, H, t).out));
  ok(seqHash.every((h, i) => h === cold[i]), "120 frames identical: cold fresh instance vs warm instance");
  const clk = set(defaults(), { en_blur: 1, en_color: 1, en_light: 1, en_scale: 1, en_slide: 1, slide_rgb: 30, seed: 7 });
  clk[idxOf.clock] = 2.5;
  const a = hash(A.render(v, IMG, W, H, 2.5).out), b = hash(A.render(clk, IMG, W, H, 0).out);
  ok(a === b, "clock param == time argument (cache-freeze workaround)");
  const s1 = hash(A.render(set(v, { seed: 8 }), IMG, W, H, 2.5).out), s0 = hash(A.render(set(v, { seed: 7 }), IMG, W, H, 2.5).out);
  ok(s0 !== s1 || true, "different seeds are allowed to differ (info)");
}

// ---------- 4. per-operator correctness
console.log("\n[Light] exposure ratio");
{
  const v = set(defaults(), { en_light: 1, light_amount: 100, seed: 3 });
  const t = firstActive.light ?? 0;
  let best = null;
  for (let f = 0; f < 24 * 20; f++) { const r = A.render(v, IMG, W, H, f / 24); const d = maxDiff(r.out, IMG); if (!best || d > best.d) best = { d, t: f / 24, out: r.out }; }
  const ratios = new Set();
  for (let i = 0; i < IMG.length; i += 4) if (IMG[i] > 0.1) ratios.add((best.out[i] / IMG[i]).toFixed(4));
  ok(ratios.size === 1, "gain is uniform across pixels (ratio " + [...ratios][0] + " at t=" + best.t.toFixed(3) + ")");
  const g = parseFloat([...ratios][0]);
  ok(g > 1.0 && g <= 4.0001, "Brighter gain in (1, 2^2]");
  let alphaSame = true; for (let i = 3; i < IMG.length; i += 4) if (best.out[i] !== IMG[i]) alphaSame = false;
  ok(alphaSame, "alpha untouched by Light");
}
console.log("\n[Slide] pure translation, no split, no motion blur");
{
  const v = set(defaults(), { en_slide: 1, slide_amount: 60, slide_dir: 90, slide_mb: 0, slide_rgb: 0, border: 3, seed: 5 });
  let best = null;
  for (let f = 0; f < 24 * 20; f++) { const r = A.render(v, IMG, W, H, f / 24); const d = maxDiff(r.out, IMG); if (!best || d > best.d) best = { d, out: r.out, t: f / 24 }; }
  // horizontal direction => rows are shifted independently; estimate shift on a gradient row
  const row = 40, getR = (a, x) => a[(row * W + x) * 4];
  let bestS = 0, bestE = 1e9;
  for (let s = -W; s <= W; s += 0.25) {
    let e = 0, c = 0;
    for (let x = 30; x < W - 30; x++) {
      const xs = x - s, x0 = Math.floor(xs), tx = xs - x0;
      if (x0 < 0 || x0 + 1 >= W) continue;
      const pred = getR(IMG, x0) * (1 - tx) + getR(IMG, x0 + 1) * tx;
      e += Math.abs(pred - getR(best.out, x)); c++;
    }
    if (c > 40 && e / c < bestE) { bestE = e / c; bestS = s; }
  }
  console.log(`  best-fit horizontal shift ${bestS}px, mean err ${bestE.toExponential(2)} (t=${best.t.toFixed(3)})`);
  ok(Math.abs(bestS) > 1 && bestE < 5e-3, "output == input translated horizontally");
  let vert = true;
  for (let x = 40; x < W - 40; x++) { const a = best.out[((20) * W + x) * 4 + 1], b = best.out[((20) * W + x) * 4 + 1]; if (a !== b) vert = false; }
  ok(vert, "no vertical component for 90deg direction (sanity)");
}
console.log("\n[Slide] RGB split separates channels by (1+k):1:(1-k)");
{
  const k = 0.4;
  // non-periodic per-channel horizontal signal (two incommensurate sines) so the shift fit is unambiguous
  const SIG = new Float32Array(W * H * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4, T = Math.PI * 2;
    for (let c = 0; c < 3; c++) SIG[i + c] = 0.5 + 0.25 * Math.sin(T * x / 83 + c) + 0.2 * Math.sin(T * x / 131 + 2 * c);
    SIG[i + 3] = 1;
  }
  const v = set(defaults(), { en_slide: 1, slide_amount: 60, slide_dir: 90, slide_mb: 0, slide_rgb: k * 100, border: 3, seed: 5 });
  let best = null;
  for (let f = 0; f < 24 * 20; f++) { const r = A.render(v, SIG, W, H, f / 24); const d = maxDiff(r.out, SIG); if (!best || d > best.d) best = { d, out: r.out }; }
  const row = 40;
  // use a smooth horizontal ramp channel per channel: fit shift for each of R,G,B on the row
  const fit = (ch) => {
    let bestS = 0, bestE = 1e9;
    for (let s = -W; s <= W; s += 0.25) {
      let e = 0, c = 0;
      for (let x = 40; x < W - 40; x++) {
        const xs = x - s, x0 = Math.floor(xs), tx = xs - x0; if (x0 < 0 || x0 + 1 >= W) continue;
        const a = SIG[(row * W + x0) * 4 + ch], b = SIG[(row * W + x0 + 1) * 4 + ch];
        e += Math.abs(a * (1 - tx) + b * tx - best.out[(row * W + x) * 4 + ch]); c++;
      }
      if (c > 40 && e / c < bestE) { bestE = e / c; bestS = s; }
    }
    return bestS;
  };
  const sR = fit(0), sG = fit(1), sB = fit(2);
  console.log("  fitted shifts R,G,B =", sR, sG, sB);
  ok(Math.abs(sR / sG - (1 + k)) < 0.05 && Math.abs(sB / sG - (1 - k)) < 0.05, "R:G:B shifts = 1.4 : 1 : 0.6");
}
console.log("\n[Scale] zoom-in about origin");
{
  const smooth = new Float32Array(W * H * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const i = (y * W + x) * 4; smooth[i] = x / W; smooth[i + 1] = y / H; smooth[i + 2] = 0.5; smooth[i + 3] = 1; }
  const v = set(defaults(), { en_scale: 1, scale_amount: 80, scale_mb: 0, seed: 9 });
  let best = null;
  for (let f = 0; f < 24 * 20; f++) { const r = A.render(v, smooth, W, H, f / 24); const d = maxDiff(r.out, smooth); if (!best || d > best.d) best = { d, out: r.out, t: f / 24 }; }
  ok(best.d > 0.01, "scale changes the image (maxDiff " + best.d.toFixed(3) + ")");
  const ci = ((H / 2 | 0) * W + (W / 2 | 0)) * 4;
  ok(Math.abs(smooth[ci] - best.out[ci]) < 0.005, "centre pixel fixed (origin at centre)");
  // zoom-in: pixel at x=W/4 should now show content from closer to centre => larger value than input there? (x/W increasing) -> out < in on left half
  const li = ((H / 2 | 0) * W + (W / 4 | 0)) * 4;
  ok(best.out[li] > smooth[li], "left-half pixel shows content from nearer the centre (zoom in)");
}
console.log("\n[Color] colorize keeps luma-ish, alpha untouched");
{
  const v = set(defaults(), { en_color: 1, color_amount: 200, seed: 2 });
  let best = null;
  for (let f = 0; f < 24 * 20; f++) { const r = A.render(v, IMG, W, H, f / 24); const d = maxDiff(r.out, IMG); if (!best || d > best.d) best = { d, out: r.out }; }
  ok(best.d > 0.05, "colour twitch visible");
  let alphaSame = true; for (let i = 3; i < IMG.length; i += 4) if (best.out[i] !== IMG[i]) alphaSame = false;
  ok(alphaSame, "alpha untouched by Color");
}
console.log("\n[Blur] energy preserved in Normal mode, modes finite");
{
  const v = set(defaults(), { en_blur: 1, blur_amount: 120, seed: 4 });
  let best = null;
  for (let f = 0; f < 24 * 20; f++) { const r = A.render(v, IMG, W, H, f / 24); const d = maxDiff(r.out, IMG); if (!best || d > best.d) best = { d, out: r.out, t: f / 24 }; }
  ok(best.d > 0.02, "blur twitch visible (maxDiff " + best.d.toFixed(3) + ")");
  for (let mode = 0; mode < 6; mode++) for (let b = 0; b < 4; b++) {
    const vv = set(defaults(), { en_blur: 1, blur_amount: 200, blur_mode: mode, border: b, blur_holdout: 40, blur_aspect: 0.5, seed: 4 });
    const r = A.render(vv, IMG, W, H, best.t);
    if (r.rc !== 0 || !allFinite(r.out)) ok(false, `blur mode ${mode} border ${b} finite`);
  }
  ok(true, "all 6 blur modes x 4 borders finite");
  for (const lens of [0, 1]) { const r = A.render(set(defaults(), { en_blur: 1, blur_amount: 200, blur_lens: lens, seed: 4 }), IMG, W, H, best.t); ok(r.rc === 0 && allFinite(r.out), "lens=" + lens + " ok"); }
}
console.log("\n[Show Twitch Only]");
{
  const v = set(defaults(), { en_light: 1, twitch_only: 1, seed: 3 });
  let sawZero = false, sawImage = false;
  for (let f = 0; f < 24 * 20; f++) {
    const r = A.render(v, IMG, W, H, f / 24);
    const nz = r.out.some((x) => x !== 0);
    if (!nz) sawZero = true; else sawImage = true;
  }
  ok(sawZero && sawImage, "idle frames transparent, twitch frames render");
}
console.log("\n[Freeze Twitch]");
{
  const v = set(defaults(), { en_light: 1, en_slide: 1, freeze: 1, freeze_time: firstActive.light ?? 0.3, seed: 3 });
  const h0 = hash(A.render(v, IMG, W, H, 0.0).out);
  ok([0.5, 3.3, 17.1].every((t) => hash(A.render(v, IMG, W, H, t).out) === h0), "frozen output independent of time");
}


// ---------- 4b. Time operator: the Time Remap expression must agree with the plug-in's own schedule
console.log("\n[Time expression == plug-in schedule]");
{
  const ex = JSON.parse(fs.readFileSync(new URL("./expressions.json", import.meta.url), "utf8"));
  const body = ex.timeRemap.replace(/value \+ off\s*$/, "return value + off;");
  const run = new Function("effect", "time", "thisLayer", "value", body);
  const byName = {}; for (const p of manifest.params) byName[p.name] = p;
  let s = 777; const rand = () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296);
  let mism = 0, nonzero = 0, checks = 0;
  for (let c = 0; c < 60; c++) {
    const v = set(defaults(), {
      en_time: 1, speed: [1, 3, 10, 25, 60][c % 5], time_rate: 0.5 + rand() * 3, seed: Math.floor(rand() * 9999), time_seed: c % 3 ? 0 : Math.floor(rand() * 500),
      ease_in: [0, 1, 2.5, 6][c % 4], ease_out: [0, 1, 3][c % 3], hold_frames: [0, 1, 2][c % 3], time_amount: 10 + rand() * 90, time_dir: c % 3,
      rand_min: rand() * 60, amount: 30 + rand() * 200, frame_rate: [24, 25, 29.97, 30, 60][c % 5], clock: 0,
    });
    const fx = (name) => { const p = byName[name]; if (!p) throw new Error("no param " + name); const i = idxOf[p.id]; return { value: p.type === "checkbox" ? v[i] !== 0 : (p.type === "popup" ? v[i] + 1 : v[i]) }; };
    const B = newInstance();
    const base = B.x.ec_alloc(n * 8); new Float64Array(B.x.memory.buffer, base, n).set(v);
    for (let f = 0; f < 300; f++) {
      const t = f / v[idxOf.frame_rate] + (c % 2 ? 0.0 : 0.37);
      const a = B.x.ec_debug_time_offset(base, n, t);
      v[idxOf.clock] = 0;
      const b = run((nm) => { if (nm !== "EC Twitch") throw new Error(nm); return fx; }, t, { startTime: 0 }, 5.0) - 5.0;
      checks++;
      if (a !== 0) nonzero++;
      if (Math.abs(a - b) > 1e-9) { if (mism < 5) console.log("   mismatch", c, f, a, b); mism++; }
    }
  }
  ok(mism === 0, `expression offset == plug-in offset on ${checks} samples (${nonzero} non-zero)`);
  ok(nonzero > checks * 0.05, "Time operator actually offsets");
}

// ---------- 4c. Lens blur is a disc, Gaussian conserves energy, Scale can zoom out
console.log("\n[Lens disc / blur energy / zoom out]");
{
  const w = 121, h = 121;
  const dot = new Float32Array(w * h * 4); { const i = (60 * w + 60) * 4; dot[i] = dot[i + 1] = dot[i + 2] = dot[i + 3] = 1; }
  // snap envelope (ease 0, hold 1), rand_min 100 => value == amount at every active frame
  const v = set(defaults(w, h), { en_blur: 1, blur_lens: 1, blur_amount: 30, ease_in: 0, ease_out: 0, rand_min: 100, speed: 30, quality: 2, border: 2, freeze: 1 });
  let frozen = null;
  for (let f = 0; f < 200 && frozen === null; f++) { v[idxOf.freeze_time] = f / 30; const r = A.render(v, dot, w, h, 0); if (maxDiff(r.out, dot) > 1e-6) frozen = r.out; }
  ok(frozen !== null, "found an active lens frame");
  let cnt = 0, sum = 0, maxR = 0, vals = new Set();
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const a = frozen[(y * w + x) * 4 + 3]; if (a > 1e-7) { cnt++; sum += a; maxR = Math.max(maxR, Math.hypot(x - 60, y - 60)); vals.add(a.toFixed(6)); } }
  const R = 30 * 0.5; // radius = amount*0.5 (High quality keeps R<=16 at full res)
  console.log(`  disc: ${cnt} px (pi R^2 = ${(Math.PI * R * R).toFixed(0)}), max radius ${maxR.toFixed(1)}, distinct levels ${vals.size}, energy ${sum.toFixed(4)}`);
  ok(Math.abs(cnt - Math.PI * R * R) / (Math.PI * R * R) < 0.15 && maxR < R + 1.5, "support is a disc of the requested radius");
  ok(vals.size <= 3, "flat (bokeh) kernel, not gaussian falloff");
  ok(Math.abs(sum - 1) < 0.02, "lens blur conserves energy");

  for (const lens of [0, 1]) for (const q of [0, 1, 2]) {
    const img = makeImage(w, h);
    const vv = set(defaults(w, h), { en_blur: 1, blur_lens: lens, blur_amount: 200, ease_in: 0, ease_out: 0, rand_min: 100, speed: 30, quality: q, border: 0, freeze: 1 });
    let out = null;
    for (let f = 0; f < 200 && out === null; f++) { vv[idxOf.freeze_time] = f / 30; const r = A.render(vv, img, w, h, 0); if (maxDiff(r.out, img) > 1e-4) out = r.out; }
    let si = 0, so = 0; for (let i = 0; i < img.length; i++) { si += img[i]; so += out[i]; }
    ok(Math.abs(so / si - 1) < 0.03, `lens=${lens} quality=${q}: energy kept (ratio ${(so / si).toFixed(4)}) with downsampling`);
  }
  // zoom out: negative Scale Amount shrinks about the centre
  const smooth = new Float32Array(W * H * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const i = (y * W + x) * 4; smooth[i] = x / W; smooth[i + 1] = y / H; smooth[i + 2] = 0.5; smooth[i + 3] = 1; }
  const vz = set(defaults(), { en_scale: 1, scale_amount: -150, scale_mb: 0, border: 2, seed: 9, ease_in: 0, ease_out: 0, rand_min: 100, speed: 30, freeze: 1 });
  let zo = null;
  for (let f = 0; f < 200 && zo === null; f++) { vz[idxOf.freeze_time] = f / 30; const r = A.render(vz, smooth, W, H, 0); if (maxDiff(r.out, smooth) > 1e-4) zo = r.out; }
  ok(zo !== null && zo[3] === 0 && zo[((H / 2 | 0) * W + (W / 2 | 0)) * 4 + 3] === 1, "zoom out leaves transparent border (Ignore), centre stays");
}


console.log("\n[nearest-tap motion blur (Draft/Normal) vs bilinear (High)]");
{
  for (const [label, cfg] of [["slide+MB", { en_slide: 1, slide_amount: 80, slide_mb: 100, slide_spread: 1 }], ["slide+MB+rgb", { en_slide: 1, slide_amount: 80, slide_mb: 100, slide_rgb: 40 }], ["scale+MB", { en_scale: 1, scale_amount: 120, scale_mb: 100 }], ["horizontal streak", { en_slide: 1, slide_amount: 80, slide_mb: 100, slide_dir: 90, slide_spread: 0 }], ["vertical streak", { en_slide: 1, slide_amount: 80, slide_mb: 100, slide_dir: 0, slide_spread: 0, border: 1 }]]) {
    const base = { ...cfg, ease_in: 2, ease_out: 2, speed: 8, seed: 11, freeze: 1 };
    let worst = 0, n = 0;
    for (let f = 0; f < 60; f++) {
      const vq = set(defaults(), { ...base, freeze_time: f / 30, quality: 1 }), vh = set(defaults(), { ...base, freeze_time: f / 30, quality: 2 });
      const a = A.render(vq, IMG, W, H, 0).out, b = A.render(vh, IMG, W, H, 0).out;
      if (maxDiff(b, IMG) < 1e-4) continue;
      let m = 0; for (let i = 0; i < a.length; i++) m += Math.abs(a[i] - b[i]); m /= a.length;
      worst = Math.max(worst, m); n++;
    }
    console.log(`  ${label}: ${n} active frames, worst mean |Normal - High| = ${worst.toFixed(4)}`);
    ok(n > 0 && worst < 0.05, label + " nearest taps stay close to the bilinear reference");
  }
}

// ---------- 5. fuzz
console.log("\n[fuzz] 400 random param sets x random times, finite + rc==0 + memory bounded");
{
  let s = 12345; const rand = () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296);
  const F = newInstance();
  let bad = 0;
  for (let i = 0; i < 400; i++) {
    const v = defaults();
    for (const p of manifest.params) {
      const k = idxOf[p.id];
      if (p.type === "slider") v[k] = p.min + rand() * (p.max - p.min) * (rand() < 0.2 ? 1 : 0.3);
      else if (p.type === "checkbox") v[k] = rand() < 0.7 ? 1 : 0;
      else if (p.type === "popup") v[k] = Math.floor(rand() * p.options.length);
      else if (p.type === "angle") v[k] = rand() * 720 - 360;
      else if (p.type === "point") { v[k] = rand() * W; v[k + 1] = rand() * H; }
      else if (p.type === "color") for (let c = 0; c < 4; c++) v[k + c] = rand();
    }
    v[idxOf.clock] = rand() * 100; v[idxOf.freeze] = 0;
    const w = 8 + Math.floor(rand() * 120), h = 8 + Math.floor(rand() * 80);
    for (const p of manifest.params) if (p.type === "point") { v[idxOf[p.id]] = rand() * w; v[idxOf[p.id] + 1] = rand() * h; }
    const r = F.render(v, makeImage(w, h), w, h, rand() * 100, 0.25 + rand() * 2);
    if (r.rc !== 0 || !allFinite(r.out)) { bad++; console.log("   bad case", i, r.rc); }
  }
  ok(bad === 0, "no failures");
  ok(F.x.memory.buffer.byteLength < 64 * 1024 * 1024, "memory stayed small: " + (F.x.memory.buffer.byteLength / 1048576).toFixed(1) + " MiB");
}
console.log("\n[garbage params]");
{
  const v = defaults();
  v[idxOf.speed] = NaN; v[idxOf.amount] = Infinity; v[idxOf.blur_amount] = -1e30; v[idxOf.seed] = 1e30; v[idxOf.en_blur] = 1; v[idxOf.en_scale] = 1; v[idxOf.en_slide] = 1;
  const r = A.render(v, IMG, W, H, NaN, NaN);
  ok(r.rc === 0 && allFinite(r.out), "NaN/Inf params and time don't trap");
  const bad = A.render(new Float64Array(10), IMG, W, H, 0);
  ok(bad.rc === 1, "wrong param count -> error code 1, no trap");
}

// ---------- 6. perf + memory at 1080p / 4K worst case
console.log("\n[perf] V8 timing, all operators, worst-case frame (indicative only)");
for (const [w, h, label] of [[1920, 1080, "1080p"], [3840, 2160, "4K"]]) {
  const P = newInstance();
  const img = makeImage(w, h);
  const v = set(defaults(w, h), { en_blur: 1, en_color: 1, en_light: 1, en_scale: 1, en_slide: 1, slide_rgb: 40, blur_amount: 200, scale_amount: 200, slide_amount: 200, amount: 100, seed: 1 });
  // find the busiest frame in 10 s
  let tBest = 0, vBest = -1;
  for (let f = 0; f < 240; f += 1) {
    const t = f / 24; const r = P.render(set(v, { quality: 0 }), makeImage(32, 18), 32, 18, t);
    // use small image only to rank frames by amount of change
    const d = maxDiff(r.out, makeImage(32, 18)); if (d > vBest) { vBest = d; tBest = t; }
  }
  for (const q of [0, 1, 2]) {
    const t0 = performance.now();
    const r = P.render(set(v, { quality: q }), img, w, h, tBest);
    const dt = performance.now() - t0;
    console.log(`  ${label} quality=${q}: rc=${r.rc} ${dt.toFixed(0)} ms, memory ${(P.x.memory.buffer.byteLength / 1048576).toFixed(0)} MiB, finite=${allFinite(r.out)}`);
    ok(r.rc === 0 && allFinite(r.out), `${label} quality ${q} renders`);
  }
  const t0 = performance.now(); const idle = P.render(defaults(w, h), img, w, h, 0); console.log(`  ${label} idle (all off): ${(performance.now() - t0).toFixed(1)} ms rc=${idle.rc}`);
}

console.log(failed ? `\n${failed} FAILED` : "\nALL PASSED");
process.exit(failed ? 1 : 0);
