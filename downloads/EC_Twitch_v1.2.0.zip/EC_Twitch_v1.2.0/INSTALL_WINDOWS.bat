@echo off
setlocal
title Install EC Twitch
echo Installing EC Twitch for EffectCraft...
echo.
if not exist "%~dp01_Plugin\ec_twitch.wasm" (
  echo Could not find 1_Plugin\ec_twitch.wasm.
  echo Unzip the whole zip first, then double-click this file again.
  pause
  exit /b 1
)
set "PLUG=%APPDATA%\EffectCraft\Plug-ins"
if not exist "%PLUG%" mkdir "%PLUG%"
copy /Y "%~dp01_Plugin\ec_twitch.wasm" "%PLUG%\" >nul || goto fail
echo   Plug-in copied to:  %PLUG%
set "PRE=%USERPROFILE%\Documents\EffectCraft\Presets"
if not exist "%PRE%" mkdir "%PRE%"
copy /Y "%~dp02_Presets\*.ecpreset" "%PRE%\" >nul || goto fail
echo   Presets copied to:  %PRE%
echo.
echo Done. Restart EffectCraft, then search "EC Twitch" in Effects ^& Presets.
echo.
pause
exit /b 0
:fail
echo.
echo Something went wrong while copying. Copy the files by hand: see INSTALL.txt.
pause
exit /b 1
