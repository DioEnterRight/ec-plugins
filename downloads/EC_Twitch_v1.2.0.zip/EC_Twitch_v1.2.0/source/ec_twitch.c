/*
 * EC Twitch - clean-room behavioural clone of Video Copilot Twitch for EffectCraft plug-in API v1.
 *
 * Design rules
 *   - Stateless: every frame is a pure function of (params, time, input pixels).
 *     Event timing/values come from an integer hash of (seed, operator, slot index),
 *     so cold renders, sequential renders, any thread count and any order all match bit-for-bit.
 *   - No imports, no libm: sin/cos/exp2/log2 are implemented here with fixed polynomials
 *     (wasm f64 + - * / sqrt floor are IEEE-deterministic).
 *   - Bounded memory: one arena in linear memory, reset on every ec_alloc, never grown past 1 GiB.
 *   - Skips all work on frames where no twitch is active (the common case).
 *   - MVP wasm only: every double->int cast is clamped first (MVP casts trap on out-of-range).
 *
 * Time operator: wasm API v1 cannot read other frames, so Time is a declared no-op here.
 */
#include <stdint.h>
#include <stddef.h>
#include "params_gen.h"

#define EXPORT(name) __attribute__((export_name(name)))
#define PI 3.14159265358979323846
#define MAXTAPS 16

extern unsigned char __heap_base;

/* ------------------------------------------------------------------ freestanding libc bits */
void *memcpy(void *d, const void *s, size_t n) {
    unsigned char *dd = (unsigned char *)d;
    const unsigned char *ss = (const unsigned char *)s;
    while (n--) *dd++ = *ss++;
    return d;
}
void *memset(void *d, int v, size_t n) {
    unsigned char *dd = (unsigned char *)d;
    while (n--) *dd++ = (unsigned char)v;
    return d;
}

/* ------------------------------------------------------------------ math */
static inline double dfloor(double x) { return __builtin_floor(x); }
static inline double dsqrt(double x) { return __builtin_sqrt(x); }
static inline double dmin(double a, double b) { return a < b ? a : b; }
static inline double dmax(double a, double b) { return a > b ? a : b; }
static inline double dabs2(double x) { return x < 0 ? -x : x; }
static inline double clampd(double x, double a, double b) { return x < a ? a : (x > b ? b : x); }
static inline double sane(double v) { return (v == v && v > -1e18 && v < 1e18) ? v : 0.0; }

static double sin_r(double x) {
    x -= 2.0 * PI * dfloor(x / (2.0 * PI) + 0.5);
    if (x > PI / 2) x = PI - x;
    else if (x < -PI / 2) x = -PI - x;
    double x2 = x * x;
    return x * (1.0 + x2 * (-1.0 / 6 + x2 * (1.0 / 120 + x2 * (-1.0 / 5040 + x2 * (1.0 / 362880 +
           x2 * (-1.0 / 39916800 + x2 * (1.0 / 6227020800.0 + x2 * (-1.0 / 1307674368000.0))))))));
}
static double cos_r(double x) { return sin_r(x + PI / 2); }

static double exp2d(double x) {
    if (x < -1000.0) return 0.0;
    if (x > 1000.0) x = 1000.0;
    double n = dfloor(x + 0.5);
    double y = (x - n) * 0.6931471805599453;
    double p = 1.0 + y * (1.0 + y * (1.0 / 2 + y * (1.0 / 6 + y * (1.0 / 24 + y * (1.0 / 120 +
               y * (1.0 / 720 + y * (1.0 / 5040 + y * (1.0 / 40320 + y * (1.0 / 362880 +
               y * (1.0 / 3628800 + y * (1.0 / 39916800))))))))))) ;
    union { double d; uint64_t u; } c;
    c.u = (uint64_t)((int64_t)n + 1023) << 52;
    return p * c.d;
}
static inline double smoothstep(double a, double b, double x) {
    if (b <= a) return x >= a ? 1.0 : 0.0;
    double t = clampd((x - a) / (b - a), 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
}

/* ------------------------------------------------------------------ hashing (stateless RNG) */
static void pcg3d(uint32_t *px, uint32_t *py, uint32_t *pz) {
    uint32_t x = *px * 1664525u + 1013904223u;
    uint32_t y = *py * 1664525u + 1013904223u;
    uint32_t z = *pz * 1664525u + 1013904223u;
    x += y * z; y += z * x; z += x * y;
    x ^= x >> 16; y ^= y >> 16; z ^= z >> 16;
    x += y * z; y += z * x; z += x * y;
    *px = x; *py = y; *pz = z;
}
static uint32_t hash3(uint32_t a, uint32_t b, uint32_t c) { pcg3d(&a, &b, &c); return a; }
static double rnd(uint32_t seed, int32_t i, uint32_t n) {
    uint32_t x = seed, y = (uint32_t)i, z = n;
    pcg3d(&x, &y, &z);
    return (double)x * (1.0 / 4294967296.0);
}

/* ------------------------------------------------------------------ twitch engine */
/*
 * Twitch event model (mirrored 1:1 by the Time Remap expression in build.py - keep them in sync,
 * test.mjs checks they agree):
 *   rate  = Speed x Op Twitches  [twitches per second]        slot j = [j/rate, (j+1)/rate)
 *   event = starts at (j + u0)/rate, u0 = rnd(sT, j, 0)
 *           attack  Ease In  frames (smoothstep up)
 *           hold    Hold     frames (the twitch value itself)
 *           release Ease Out frames (smoothstep down)
 *   value = Amount x mag x env,  mag = RandMin + (1 - RandMin) x rnd(sV, j, 1)
 *   overlapping events: the largest wins (no jumps when a new twitch starts mid-release)
 */
typedef struct { double amount, rmin, att, hold, rel, len; uint32_t seed; } Eng;
typedef struct { double rate; uint32_t sT, sV; } Opr;
typedef struct { double v; int32_t slot; } Ev;

enum { K_BLUR = 1, K_COLOR, K_LIGHT, K_SCALE, K_SLIDE, K_TIME };

static Opr make_opr(const Eng *e, double speed, double twitches, uint32_t uniq, uint32_t k) {
    Opr o;
    o.rate = clampd(speed * twitches, 0.0, 2000.0);
    o.sV = hash3(e->seed, uniq, 0x1000u + k);
    /* unique seed 0 => operator shares the global slot stream, so equal-rate operators fire together */
    o.sT = uniq == 0 ? hash3(e->seed, 0xC0FFEEu, 0u) : hash3(e->seed, uniq, 0x2000u + k);
    return o;
}

static inline double ease01(double x) { x = clampd(x, 0.0, 1.0); return x * x * (3.0 - 2.0 * x); }

static double env_at(const Eng *g, double dt) {
    if (dt < 0.0 || dt >= g->len) return 0.0;
    if (dt < g->att) return ease01(dt / g->att);
    double r = dt - g->att - g->hold;
    if (r < 0.0) return 1.0;
    return g->rel > 0.0 ? ease01(1.0 - r / g->rel) : 0.0;
}

static Ev ev_eval(const Eng *g, const Opr *o, double t) {
    Ev best = {0.0, 0};
    if (o->rate <= 0.0 || g->amount <= 0.0) return best;
    double T = 1.0 / o->rate;
    double jmax = clampd(dfloor(t * o->rate), -2e9, 2e9);
    double jmin = clampd(dfloor((t - g->len) * o->rate) - 1.0, -2e9, 2e9);
    if (jmin < jmax - 63.0) jmin = jmax - 63.0;
    for (int32_t j = (int32_t)jmin; j <= (int32_t)jmax; j++) {
        double start = ((double)j + rnd(o->sT, j, 0)) * T;
        double env = env_at(g, t - start);
        if (env <= 0.0) continue;
        double mag = g->rmin + (1.0 - g->rmin) * rnd(o->sV, j, 1);
        double v = g->amount * mag * env;
        if (v > best.v) { best.v = v; best.slot = j; }
    }
    return best;
}

/* ------------------------------------------------------------------ memory arena */
static uint32_t g_main_end = 0;

static uint32_t align16(uint32_t v) { return (v + 15u) & ~15u; }
static int ensure_mem(uint64_t end) {
    if (end > 0x3F000000ull) return 0;
    uint64_t cur = (uint64_t)__builtin_wasm_memory_size(0) * 65536ull;
    if (end <= cur) return 1;
    uint64_t pages = (end - cur + 65535ull) / 65536ull;
    return __builtin_wasm_memory_grow(0, (size_t)pages) != (size_t)-1;
}

EXPORT("ec_api_version") int ec_api_version(void) { return 1; }
EXPORT("ec_manifest_ptr") int ec_manifest_ptr(void) { return (int)(uintptr_t)MANIFEST; }
EXPORT("ec_manifest_len") int ec_manifest_len(void) { return (int)(sizeof(MANIFEST) - 1); }

EXPORT("ec_alloc") int ec_alloc(int bytes) {
    if (bytes <= 0) return 0;
    uint32_t base = align16((uint32_t)(uintptr_t)&__heap_base);
    uint64_t end = (uint64_t)base + (uint64_t)(uint32_t)bytes + 16u;
    if (!ensure_mem(end)) return 0;
    g_main_end = align16((uint32_t)end);
    return (int)base;
}

/* ------------------------------------------------------------------ sampling */
static inline int bmap(int i, int n, int mode) {
    if ((unsigned)i < (unsigned)n) return i;
    switch (mode) {
    case 0: { int p = 2 * n; int m = i % p; if (m < 0) m += p; return m < n ? m : p - 1 - m; }
    case 1: { int m = i % n; if (m < 0) m += n; return m; }
    case 2: return -1;
    default: return i < 0 ? 0 : n - 1;
    }
}

static const float ZERO4[4] = {0, 0, 0, 0};

/* bilinear sample at texel-space (fx,fy). c<0: all four comps into o[0..3]; else channel c -> o[0], alpha -> o[1] */
static void bilin(const float *s, int w, int h, int mode, double fx, double fy, int c, double *o) {
    fx = clampd(fx, -1e6, 1e6);
    fy = clampd(fy, -1e6, 1e6);
    double fx0 = dfloor(fx), fy0 = dfloor(fy);
    int x0 = (int)fx0, y0 = (int)fy0;
    double tx = fx - fx0, ty = fy - fy0;
    double w00 = (1 - tx) * (1 - ty), w10 = tx * (1 - ty), w01 = (1 - tx) * ty, w11 = tx * ty;
    const float *p00, *p10, *p01, *p11;
    if (x0 >= 0 && y0 >= 0 && x0 + 1 < w && y0 + 1 < h) {
        p00 = s + ((size_t)y0 * w + x0) * 4;
        p10 = p00 + 4;
        p01 = p00 + (size_t)w * 4;
        p11 = p01 + 4;
    } else {
        int xa = bmap(x0, w, mode), xb = bmap(x0 + 1, w, mode);
        int ya = bmap(y0, h, mode), yb = bmap(y0 + 1, h, mode);
        p00 = (xa < 0 || ya < 0) ? ZERO4 : s + ((size_t)ya * w + xa) * 4;
        p10 = (xb < 0 || ya < 0) ? ZERO4 : s + ((size_t)ya * w + xb) * 4;
        p01 = (xa < 0 || yb < 0) ? ZERO4 : s + ((size_t)yb * w + xa) * 4;
        p11 = (xb < 0 || yb < 0) ? ZERO4 : s + ((size_t)yb * w + xb) * 4;
    }
    if (c < 0) {
        for (int k = 0; k < 4; k++) o[k] = w00 * p00[k] + w10 * p10[k] + w01 * p01[k] + w11 * p11[k];
    } else {
        o[0] = w00 * p00[c] + w10 * p10[c] + w01 * p01[c] + w11 * p11[c];
        o[1] = w00 * p00[3] + w10 * p10[3] + w01 * p01[3] + w11 * p11[3];
    }
}

/* ------------------------------------------------------------------ box blur (running sums, O(1) per pixel) */
static void box_h(const float *s, float *d, int w, int h, int r, int mode) {
    double inv = 1.0 / (double)(2 * r + 1);
    for (int y = 0; y < h; y++) {
        const float *row = s + (size_t)y * w * 4;
        float *out = d + (size_t)y * w * 4;
        double a0 = 0, a1 = 0, a2 = 0, a3 = 0;
        for (int i = -r; i <= r; i++) {
            int m = bmap(i, w, mode);
            if (m < 0) continue;
            const float *p = row + (size_t)m * 4;
            a0 += p[0]; a1 += p[1]; a2 += p[2]; a3 += p[3];
        }
        for (int x = 0; x < w; x++) {
            float *o = out + (size_t)x * 4;
            o[0] = (float)(a0 * inv); o[1] = (float)(a1 * inv); o[2] = (float)(a2 * inv); o[3] = (float)(a3 * inv);
            int ma = bmap(x + r + 1, w, mode), mr = bmap(x - r, w, mode);
            if (ma >= 0) { const float *p = row + (size_t)ma * 4; a0 += p[0]; a1 += p[1]; a2 += p[2]; a3 += p[3]; }
            if (mr >= 0) { const float *p = row + (size_t)mr * 4; a0 -= p[0]; a1 -= p[1]; a2 -= p[2]; a3 -= p[3]; }
        }
    }
}
static void box_v(const float *s, float *d, double *acc, int w, int h, int r, int mode) {
    double inv = 1.0 / (double)(2 * r + 1);
    size_t rowlen = (size_t)w * 4;
    for (size_t i = 0; i < rowlen; i++) acc[i] = 0.0;
    for (int i = -r; i <= r; i++) {
        int m = bmap(i, h, mode);
        if (m < 0) continue;
        const float *row = s + (size_t)m * rowlen;
        for (size_t k = 0; k < rowlen; k++) acc[k] += row[k];
    }
    for (int y = 0; y < h; y++) {
        float *out = d + (size_t)y * rowlen;
        for (size_t k = 0; k < rowlen; k++) out[k] = (float)(acc[k] * inv);
        int ma = bmap(y + r + 1, h, mode), mr = bmap(y - r, h, mode);
        if (ma >= 0) { const float *row = s + (size_t)ma * rowlen; for (size_t k = 0; k < rowlen; k++) acc[k] += row[k]; }
        if (mr >= 0) { const float *row = s + (size_t)mr * rowlen; for (size_t k = 0; k < rowlen; k++) acc[k] -= row[k]; }
    }
}
/* Kutskir box sizes approximating a gaussian of std-dev sigma with n passes */
static void box_radii(double sigma, int n, int *rad) {
    double wi = dsqrt(12.0 * sigma * sigma / n + 1.0);
    int wl = (int)dfloor(wi);
    if (wl % 2 == 0) wl--;
    if (wl < 1) wl = 1;
    int wu = wl + 2;
    double mi = (12.0 * sigma * sigma - n * wl * wl - 4.0 * n * wl - 3.0 * n) / (-4.0 * wl - 4.0);
    int m = (int)dfloor(clampd(mi, -1000.0, 1000.0) + 0.5);
    for (int i = 0; i < n; i++) rad[i] = ((i < m ? wl : wu) - 1) / 2;
}

/* ------------------------------------------------------------------ disc (lens) blur: per-row prefix sums in a ring of 2*ry+1 rows */
static void disc_fill(const float *s, double *ring, int w, int h, int rx, int ry, int mode, int v) {
    int rows = 2 * ry + 1, pw = w + 2 * rx + 1;
    int slot = v % rows; if (slot < 0) slot += rows;
    double *P = ring + (size_t)slot * (size_t)pw * 4;
    int sy = bmap(v, h, mode);
    P[0] = P[1] = P[2] = P[3] = 0.0;
    for (int i = 0; i < pw - 1; i++) {
        double *a = P + (size_t)i * 4, *b = a + 4;
        int sx = sy < 0 ? -1 : bmap(i - rx, w, mode);
        if (sx < 0) { b[0] = a[0]; b[1] = a[1]; b[2] = a[2]; b[3] = a[3]; continue; }
        const float *p = s + ((size_t)sy * w + sx) * 4;
        b[0] = a[0] + p[0]; b[1] = a[1] + p[1]; b[2] = a[2] + p[2]; b[3] = a[3] + p[3];
    }
}
static void disc_blur(const float *s, float *d, double *ring, int w, int h, int rx, int ry, int mode) {
    int hw[129];
    int rows = 2 * ry + 1, pw = w + 2 * rx + 1;
    double n = 0.0;
    for (int dy = -ry; dy <= ry; dy++) {
        double fy = ry > 0 ? (double)dy / ((double)ry + 0.5) : 0.0;
        int v = (int)dfloor((double)rx * dsqrt(dmax(0.0, 1.0 - fy * fy)) + 0.5);
        hw[dy + ry] = v;
        n += (double)(2 * v + 1);
    }
    double inv = 1.0 / n;
    for (int v = -ry; v <= ry; v++) disc_fill(s, ring, w, h, rx, ry, mode, v);
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            double a0 = 0, a1 = 0, a2 = 0, a3 = 0;
            for (int dy = -ry; dy <= ry; dy++) {
                int slot = (y + dy) % rows; if (slot < 0) slot += rows;
                const double *P = ring + (size_t)slot * (size_t)pw * 4;
                int r = hw[dy + ry];
                const double *hi = P + (size_t)(x + rx + r + 1) * 4, *lo = P + (size_t)(x + rx - r) * 4;
                a0 += hi[0] - lo[0]; a1 += hi[1] - lo[1]; a2 += hi[2] - lo[2]; a3 += hi[3] - lo[3];
            }
            float *o = d + ((size_t)y * w + x) * 4;
            o[0] = (float)(a0 * inv); o[1] = (float)(a1 * inv); o[2] = (float)(a2 * inv); o[3] = (float)(a3 * inv);
        }
        if (y + 1 < h) disc_fill(s, ring, w, h, rx, ry, mode, y + 1 + ry);
    }
}

/* ------------------------------------------------------------------ colour helpers */
static void rgb2hsv(double r, double g, double b, double *h, double *s, double *v) {
    double mx = dmax(r, dmax(g, b)), mn = dmin(r, dmin(g, b)), d = mx - mn;
    *v = mx;
    *s = mx > 0 ? d / mx : 0;
    double hh = 0;
    if (d > 1e-12) {
        if (mx == r) { hh = (g - b) / d; hh -= 6.0 * dfloor(hh / 6.0); }
        else if (mx == g) hh = (b - r) / d + 2.0;
        else hh = (r - g) / d + 4.0;
    }
    *h = hh * 60.0;
}
static void hsv2rgb(double h, double s, double v, double *r, double *g, double *b) {
    h = h - 360.0 * dfloor(h / 360.0);
    double hh = h / 60.0, f = hh - dfloor(hh);
    int i = (int)dfloor(hh) % 6;
    double p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
    switch (i) {
    case 0: *r = v; *g = t; *b = p; break;
    case 1: *r = q; *g = v; *b = p; break;
    case 2: *r = p; *g = v; *b = t; break;
    case 3: *r = p; *g = q; *b = v; break;
    case 4: *r = t; *g = p; *b = v; break;
    default: *r = v; *g = p; *b = q; break;
    }
}

/* ------------------------------------------------------------------ per-frame context */
typedef struct { double a; double bx[3], by[3]; int split; } Tap;

typedef struct {
    int w, h, mode;
    int taps_n;
    int translate;   /* all taps unscaled -> constant bilinear weights */
    int nearest;     /* motion-blur taps sampled nearest-pixel (Draft/Normal with >1 tap) */
    Tap taps[MAXTAPS];
    /* per-pixel colour/light */
    int do_fx;
    double gain;
    double kcol, ccol[3];
} Frame;

static inline float finite_f(double v) { return (v == v && v > -3.0e38 && v < 3.0e38) ? (float)v : 0.0f; }

static inline void pixel_fx(const Frame *f, double *c) {
    if (f->gain != 1.0) { c[0] *= f->gain; c[1] *= f->gain; c[2] *= f->gain; }
    if (f->kcol > 0.0) {
        double L = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
        for (int k = 0; k < 3; k++) c[k] += (L * f->ccol[k] - c[k]) * f->kcol;
    }
}

/* ---- translation-only fast path: with no scaling the bilinear weights are constant per tap/channel,
 *      so they are hoisted out of the pixel loop and each tap becomes a row-wise multiply-add. */
typedef struct { const float *r0, *r1; double w00, w10, w01, w11; int ix; } RowS;

static inline void rs_init(RowS *s, const float *src, int w, int h, int mode, int y, double bx, double by) {
    bx = clampd(bx, -1e6, 1e6);
    by = clampd(by, -1e6, 1e6);
    double fx0 = dfloor(bx), fy0 = dfloor(by);
    double tx = bx - fx0, ty = by - fy0;
    int iy = (int)fy0;
    s->ix = (int)fx0;
    int ya = bmap(y + iy, h, mode), yb = bmap(y + iy + 1, h, mode);
    s->r0 = ya < 0 ? 0 : src + (size_t)ya * w * 4;
    s->r1 = yb < 0 ? 0 : src + (size_t)yb * w * 4;
    s->w00 = (1 - tx) * (1 - ty); s->w10 = tx * (1 - ty); s->w01 = (1 - tx) * ty; s->w11 = tx * ty;
}
static inline void rs_px(const RowS *s, int x, int w, int mode, int c, double *o) {
    int xa = x + s->ix, xb = xa + 1;
    if (xa < 0 || xb >= w) { xa = bmap(xa, w, mode); xb = bmap(xb, w, mode); }
    const float *p00 = (s->r0 && xa >= 0) ? s->r0 + (size_t)xa * 4 : ZERO4;
    const float *p10 = (s->r0 && xb >= 0) ? s->r0 + (size_t)xb * 4 : ZERO4;
    const float *p01 = (s->r1 && xa >= 0) ? s->r1 + (size_t)xa * 4 : ZERO4;
    const float *p11 = (s->r1 && xb >= 0) ? s->r1 + (size_t)xb * 4 : ZERO4;
    if (c < 0) {
        for (int k = 0; k < 4; k++) o[k] = s->w00 * p00[k] + s->w10 * p10[k] + s->w01 * p01[k] + s->w11 * p11[k];
    } else {
        o[0] = s->w00 * p00[c] + s->w10 * p10[c] + s->w01 * p01[c] + s->w11 * p11[c];
        o[1] = s->w00 * p00[3] + s->w10 * p10[3] + s->w01 * p01[3] + s->w11 * p11[3];
    }
}

static void pass_translate(const Frame *f, const float *src, float *dst, double *racc, double *ral) {
    const int w = f->w, h = f->h, N = f->taps_n;
    const double invN = 1.0 / (double)N;
    for (int y = 0; y < h; y++) {
        for (int i = 0; i < w * 4; i++) racc[i] = 0.0;
        for (int j = 0; j < N; j++) {
            const Tap *t = &f->taps[j];
            double o[4];
            RowS s;
            if (!t->split) {
                rs_init(&s, src, w, h, f->mode, y, t->bx[1], t->by[1]);
                for (int x = 0; x < w; x++) {
                    rs_px(&s, x, w, f->mode, -1, o);
                    double *a = racc + (size_t)x * 4;
                    a[0] += o[0]; a[1] += o[1]; a[2] += o[2]; a[3] += o[3];
                }
            } else {
                for (int x = 0; x < w; x++) ral[x] = 0.0;
                for (int c = 0; c < 3; c++) {
                    rs_init(&s, src, w, h, f->mode, y, t->bx[c], t->by[c]);
                    for (int x = 0; x < w; x++) {
                        rs_px(&s, x, w, f->mode, c, o);
                        racc[(size_t)x * 4 + c] += o[0];
                        if (o[1] > ral[x]) ral[x] = o[1];
                    }
                }
                for (int x = 0; x < w; x++) racc[(size_t)x * 4 + 3] += ral[x];
            }
        }
        float *out = dst + (size_t)y * w * 4;
        for (int x = 0; x < w; x++) {
            double c[4] = {racc[x * 4] * invN, racc[x * 4 + 1] * invN, racc[x * 4 + 2] * invN, racc[x * 4 + 3] * invN};
            if (f->do_fx) pixel_fx(f, c);
            out[x * 4] = finite_f(c[0]); out[x * 4 + 1] = finite_f(c[1]); out[x * 4 + 2] = finite_f(c[2]); out[x * 4 + 3] = finite_f(c[3]);
        }
    }
}

/* nearest translation taps: one integer offset per tap/channel, whole rows without bounds checks */
static void pass_translate_nearest(const Frame *f, const float *src, float *dst, double *racc, double *ral) {
    const int w = f->w, h = f->h, N = f->taps_n, mode = f->mode;
    const double invN = 1.0 / (double)N;
    int ix[MAXTAPS][3], iy[MAXTAPS][3];
    for (int j = 0; j < N; j++)
        for (int c = 0; c < 3; c++) {
            ix[j][c] = (int)dfloor(clampd(f->taps[j].bx[c] + 0.5, -1e6, 1e6));
            iy[j][c] = (int)dfloor(clampd(f->taps[j].by[c] + 0.5, -1e6, 1e6));
        }
    for (int y = 0; y < h; y++) {
        for (int i = 0; i < w * 4; i++) racc[i] = 0.0;
        for (int j = 0; j < N; j++) {
            const Tap *t = &f->taps[j];
            int c0 = t->split ? 0 : 1, c1 = t->split ? 3 : 2;
            if (t->split) for (int x = 0; x < w; x++) ral[x] = 0.0;
            for (int c = c0; c < c1; c++) {
                int sy = bmap(y + iy[j][c], h, mode);
                if (sy < 0) continue;                       /* Ignore: transparent row */
                const float *row = src + (size_t)sy * w * 4;
                int off = ix[j][c];
                int xlo = -off, xhi = w - off;               /* x in [xlo, xhi) maps inside the row */
                if (xlo < 0) xlo = 0;
                if (xhi > w) xhi = w;
                for (int x = 0; x < w; x++) {
                    const float *p;
                    if (x >= xlo && x < xhi) p = row + (size_t)(x + off) * 4;
                    else { int m = bmap(x + off, w, mode); if (m < 0) continue; p = row + (size_t)m * 4; }
                    double *a = racc + (size_t)x * 4;
                    if (!t->split) { a[0] += p[0]; a[1] += p[1]; a[2] += p[2]; a[3] += p[3]; }
                    else { a[c] += p[c]; if (p[3] > ral[x]) ral[x] = p[3]; }
                }
            }
            if (t->split) for (int x = 0; x < w; x++) racc[(size_t)x * 4 + 3] += ral[x];
        }
        float *out = dst + (size_t)y * w * 4;
        for (int x = 0; x < w; x++) {
            double c[4] = {racc[x * 4] * invN, racc[x * 4 + 1] * invN, racc[x * 4 + 2] * invN, racc[x * 4 + 3] * invN};
            if (f->do_fx) pixel_fx(f, c);
            out[x * 4] = (float)c[0]; out[x * 4 + 1] = (float)c[1]; out[x * 4 + 2] = (float)c[2]; out[x * 4 + 3] = (float)c[3];
        }
    }
}

/* nearest scale+slide taps: per row, each tap/channel walks the source row incrementally (fx += a) */
static void pass_geometry_nearest(const Frame *f, const float *src, float *dst, double *racc, double *ral) {
    const int w = f->w, h = f->h, N = f->taps_n, mode = f->mode;
    const double invN = 1.0 / (double)N;
    for (int y = 0; y < h; y++) {
        const double Y = (double)y + 0.5;
        for (int i = 0; i < w * 4; i++) racc[i] = 0.0;
        for (int j = 0; j < N; j++) {
            const Tap *t = &f->taps[j];
            const double a = t->a;
            int c0 = t->split ? 0 : 1, c1 = t->split ? 3 : 2;
            if (t->split) for (int x = 0; x < w; x++) ral[x] = 0.0;
            for (int c = c0; c < c1; c++) {
                int sy = (int)dfloor(clampd(a * Y + t->by[c], -1e6, 1e6));
                sy = bmap(sy, h, mode);
                if (sy < 0) continue;
                const float *row = src + (size_t)sy * w * 4;
                double fx = a * 0.5 + t->bx[c];
                double fend = fx + a * (double)(w - 1);
                int inside = fx >= 0.0 && fend >= 0.0 && fx < (double)w && fend < (double)w;
                for (int x = 0; x < w; x++, fx += a) {
                    int xi;
                    if (inside) xi = (int)fx;                       /* fx >= 0: truncation == floor */
                    else { xi = bmap((int)dfloor(clampd(fx, -1e6, 1e6)), w, mode); if (xi < 0) continue; }
                    const float *p = row + (size_t)xi * 4;
                    double *acc = racc + (size_t)x * 4;
                    if (!t->split) { acc[0] += p[0]; acc[1] += p[1]; acc[2] += p[2]; acc[3] += p[3]; }
                    else { acc[c] += p[c]; if (p[3] > ral[x]) ral[x] = p[3]; }
                }
            }
            if (t->split) for (int x = 0; x < w; x++) racc[(size_t)x * 4 + 3] += ral[x];
        }
        float *out = dst + (size_t)y * w * 4;
        for (int x = 0; x < w; x++) {
            double c[4] = {racc[x * 4] * invN, racc[x * 4 + 1] * invN, racc[x * 4 + 2] * invN, racc[x * 4 + 3] * invN};
            if (f->do_fx) pixel_fx(f, c);
            out[x * 4] = (float)c[0]; out[x * 4 + 1] = (float)c[1]; out[x * 4 + 2] = (float)c[2]; out[x * 4 + 3] = (float)c[3];
        }
    }
}

/* bilinear scale+slide taps, row-walk version of pass_geometry (fx += a per pixel, rows fixed per tap) */
static void pass_geometry_rows(const Frame *f, const float *src, float *dst, double *racc, double *ral) {
    const int w = f->w, h = f->h, N = f->taps_n, mode = f->mode;
    const double invN = 1.0 / (double)N;
    double o[4];
    for (int y = 0; y < h; y++) {
        const double Y = (double)y + 0.5;
        for (int i = 0; i < w * 4; i++) racc[i] = 0.0;
        for (int j = 0; j < N; j++) {
            const Tap *t = &f->taps[j];
            const double a = t->a;
            int c0 = t->split ? 0 : 1, c1 = t->split ? 3 : 2;
            if (t->split) for (int x = 0; x < w; x++) ral[x] = 0.0;
            for (int c = c0; c < c1; c++) {
                double fy = clampd(a * Y + t->by[c] - 0.5, -1e6, 1e6), fy0 = dfloor(fy), ty = fy - fy0;
                int y0 = (int)fy0;
                int ya = bmap(y0, h, mode), yb = bmap(y0 + 1, h, mode);
                const float *r0 = ya < 0 ? 0 : src + (size_t)ya * w * 4, *r1 = yb < 0 ? 0 : src + (size_t)yb * w * 4;
                double fx = a * 0.5 + t->bx[c] - 0.5, fend = fx + a * (double)(w - 1);
                int inside = r0 && r1 && fx >= 0.0 && fend >= 0.0 && fx + 1.0 < (double)w && fend + 1.0 < (double)w;
                for (int x = 0; x < w; x++, fx += a) {
                    double *acc = racc + (size_t)x * 4;
                    if (inside) {
                        int x0 = (int)fx;
                        double tx = fx - (double)x0;
                        const float *p00 = r0 + (size_t)x0 * 4, *p01 = r1 + (size_t)x0 * 4;
                        if (!t->split) {
                            for (int k = 0; k < 4; k++) {
                                double top = p00[k] + (p00[k + 4] - p00[k]) * tx, bot = p01[k] + (p01[k + 4] - p01[k]) * tx;
                                acc[k] += top + (bot - top) * ty;
                            }
                        } else {
                            double top = p00[c] + (p00[c + 4] - p00[c]) * tx, bot = p01[c] + (p01[c + 4] - p01[c]) * tx;
                            acc[c] += top + (bot - top) * ty;
                            double ta = p00[3] + (p00[7] - p00[3]) * tx, ba = p01[3] + (p01[7] - p01[3]) * tx, al = ta + (ba - ta) * ty;
                            if (al > ral[x]) ral[x] = al;
                        }
                    } else {
                        bilin(src, w, h, mode, fx, fy, t->split ? c : -1, o);
                        if (!t->split) { acc[0] += o[0]; acc[1] += o[1]; acc[2] += o[2]; acc[3] += o[3]; }
                        else { acc[c] += o[0]; if (o[1] > ral[x]) ral[x] = o[1]; }
                    }
                }
            }
            if (t->split) for (int x = 0; x < w; x++) racc[(size_t)x * 4 + 3] += ral[x];
        }
        float *out = dst + (size_t)y * w * 4;
        for (int x = 0; x < w; x++) {
            double c[4] = {racc[x * 4] * invN, racc[x * 4 + 1] * invN, racc[x * 4 + 2] * invN, racc[x * 4 + 3] * invN};
            if (f->do_fx) pixel_fx(f, c);
            out[x * 4] = (float)c[0]; out[x * 4 + 1] = (float)c[1]; out[x * 4 + 2] = (float)c[2]; out[x * 4 + 3] = (float)c[3];
        }
    }
}

static void pass_fx_inplace(const Frame *f, float *px) {
    size_t n = (size_t)f->w * f->h;
    for (size_t i = 0; i < n; i++) {
        float *p = px + i * 4;
        double c[4] = {p[0], p[1], p[2], p[3]};
        pixel_fx(f, c);
        p[0] = finite_f(c[0]); p[1] = finite_f(c[1]); p[2] = finite_f(c[2]);
    }
}

/* ------------------------------------------------------------------ operator state at a time */
typedef struct {
    Eng g;
    Opr op[7];
    double W, H, scale;
    double scale_amt, scale_ox, scale_oy, scale_rand;
    double slide_amt, slide_dir, slide_spread, slide_tend, slide_rgb;
} Ctx;

static void scale_state(const Ctx *c, double ts, double *s, double *ox, double *oy) {
    Ev e = ev_eval(&c->g, &c->op[K_SCALE], ts);
    *s = 1.0; *ox = c->scale_ox; *oy = c->scale_oy;
    if (e.v <= 1e-9) return;
    double kz = e.v * c->scale_amt / 100.0 * 0.5;
    *s = kz >= 0.0 ? 1.0 + kz : 1.0 / (1.0 - kz);   /* negative Scale Amount zooms out */
    const Opr *o = &c->op[K_SCALE];
    *ox += (rnd(o->sV, e.slot, 2) - 0.5) * c->W * c->scale_rand / 100.0;
    *oy += (rnd(o->sV, e.slot, 3) - 0.5) * c->H * c->scale_rand / 100.0;
}
static void slide_state(const Ctx *c, double ts, double *dx, double *dy) {
    Ev e = ev_eval(&c->g, &c->op[K_SLIDE], ts);
    *dx = 0; *dy = 0;
    if (e.v <= 1e-9) return;
    const Opr *o = &c->op[K_SLIDE];
    double th = c->slide_dir + (rnd(o->sV, e.slot, 2) - 0.5) * 360.0 * c->slide_spread;
    double sgn = rnd(o->sV, e.slot, 3) < 0.5 * (1.0 + c->slide_tend) ? 1.0 : -1.0;
    double mag = sgn * e.v * c->slide_amt / 100.0 * 0.5 * c->W;
    double r = th * PI / 180.0;       /* AE convention: 0 deg = up */
    *dx = mag * sin_r(r);
    *dy = -mag * cos_r(r);
}

/* ------------------------------------------------------------------ blend modes (premultiplied rgb, per channel) */
static double blend_ch(int mode, double g, double b, double k) {
    switch (mode) {
    case 0: return g + (b - g) * k;
    case 1: return g + b * k;
    case 2: return g + k * b * (1.0 - clampd(g, 0.0, 1.0));
    case 3: return g + k * (g * b - g);
    case 4: {
        double gc = clampd(g, 0.0, 1.0), bc = clampd(b, 0.0, 1.0);
        double ov = gc < 0.5 ? 2.0 * gc * bc : 1.0 - 2.0 * (1.0 - gc) * (1.0 - bc);
        return g + k * (ov - g);
    }
    default: return g + k * (dmax(g, b) - g);
    }
}

static void init_engine(const double *q, Ctx *c, double *fps_o, double *fd_o) {
    c->g.amount = clampd(q[K_amount], 0, 1000) / 100.0;
    c->g.rmin = clampd(q[K_rand_min], 0, 100) / 100.0;
    double fps = clampd(q[K_frame_rate], 1, 240), fd = 1.0 / fps;
    *fps_o = fps; *fd_o = fd;
    c->g.att = clampd(q[K_ease_in], 0, 10) * fd;
    c->g.rel = clampd(q[K_ease_out], 0, 10) * fd;
    c->g.hold = clampd(q[K_hold_frames], 0, 10) * fd;
    if (c->g.att + c->g.hold + c->g.rel <= 0.0) c->g.hold = fd;   /* all zero: a one-frame snap */
    c->g.len = c->g.att + c->g.hold + c->g.rel;
    c->g.seed = (uint32_t)clampd(q[K_seed], 0, 1e6);
    double speed = clampd(q[K_speed], 0, 1000);
    c->op[K_BLUR]  = make_opr(&c->g, speed, clampd(q[K_blur_rate], 0, 100),  (uint32_t)clampd(q[K_blur_seed], 0, 1e6),  K_BLUR);
    c->op[K_COLOR] = make_opr(&c->g, speed, clampd(q[K_color_rate], 0, 100), (uint32_t)clampd(q[K_color_seed], 0, 1e6), K_COLOR);
    c->op[K_LIGHT] = make_opr(&c->g, speed, clampd(q[K_light_rate], 0, 100), (uint32_t)clampd(q[K_light_seed], 0, 1e6), K_LIGHT);
    c->op[K_SCALE] = make_opr(&c->g, speed, clampd(q[K_scale_rate], 0, 100), (uint32_t)clampd(q[K_scale_seed], 0, 1e6), K_SCALE);
    c->op[K_SLIDE] = make_opr(&c->g, speed, clampd(q[K_slide_rate], 0, 100), (uint32_t)clampd(q[K_slide_seed], 0, 1e6), K_SLIDE);
    c->op[K_TIME]  = make_opr(&c->g, speed, clampd(q[K_time_rate], 0, 100),  (uint32_t)clampd(q[K_time_seed], 0, 1e6),  K_TIME);
}

static double clock_time(const double *q, double time) {
    double t = q[K_clock] != 0.0 ? q[K_clock] : time;
    if (q[K_freeze] != 0.0) t = q[K_freeze_time];
    return t;
}

/* Time operator offset in seconds (what the Time Remap expression adds). Mirrors build.py TIME_EXPR. */
static double time_offset(const double *q, const Ctx *c, double fps, double t) {
    if (q[K_en_time] == 0.0) return 0.0;
    Ev e = ev_eval(&c->g, &c->op[K_TIME], t);
    if (e.v <= 1e-9) return 0.0;
    int dir = (int)clampd(q[K_time_dir], 0, 2);
    double sign = dir == 1 ? 1.0 : (dir == 2 ? -1.0 : (rnd(c->op[K_TIME].sV, e.slot, 2) < 0.5 ? -1.0 : 1.0));
    double off = sign * e.v * clampd(q[K_time_amount], 0, 100) / 100.0;
    return dfloor(off * fps + 0.5) / fps;
}

static int load_params(const double *pp, int np, double *q) {
    if (np != NPARAMS) return 0;
    for (int i = 0; i < NPARAMS; i++) q[i] = sane(pp[i]);
    return 1;
}

/* Debug exports (ignored by EffectCraft): let the test-suite compare the plug-in's schedule with the expression. */
EXPORT("ec_debug_event") double ec_debug_event(double *pp, int np, int op, double time) {
    double q[NPARAMS], fps, fd;
    if (op < 1 || op > 6 || !load_params(pp, np, q)) return -1.0;
    Ctx c;
    init_engine(q, &c, &fps, &fd);
    return ev_eval(&c.g, &c.op[op], clock_time(q, sane(time))).v;
}
EXPORT("ec_debug_time_offset") double ec_debug_time_offset(double *pp, int np, double time) {
    double q[NPARAMS], fps, fd;
    if (!load_params(pp, np, q)) return -1e9;
    Ctx c;
    init_engine(q, &c, &fps, &fd);
    return time_offset(q, &c, fps, clock_time(q, sane(time)));
}

/* ------------------------------------------------------------------ render */
EXPORT("ec_render")
int ec_render(float *px, int w, int h, double *pp, int np, double time, double scale) {
    double q[NPARAMS];
    if (w <= 0 || h <= 0 || w > 16384 || h > 16384 || !load_params(pp, np, q)) return 1;
    time = sane(time);
    scale = clampd(sane(scale), 1e-3, 1e3);

    /* ---- time source: clock param (expression = time) wins when non-zero, so the layer cache can't freeze it */
    double t = clock_time(q, time);

    Ctx c;
    double fps, fd;
    init_engine(q, &c, &fps, &fd);
    c.W = (double)w; c.H = (double)h; c.scale = scale;
    c.scale_amt = clampd(q[K_scale_amount], -200, 200);
    c.scale_ox = q[K_scale_origin]; c.scale_oy = q[K_scale_origin + 1];
    c.scale_rand = clampd(q[K_scale_origin_rand], 0, 100);
    c.slide_amt = clampd(q[K_slide_amount], 0, 200);
    c.slide_dir = q[K_slide_dir];
    c.slide_spread = clampd(q[K_slide_spread], 0, 1);
    c.slide_tend = clampd(q[K_slide_tendency], -1, 1);
    c.slide_rgb = clampd(q[K_slide_rgb], 0, 100) / 100.0;

    int mode = (int)clampd(q[K_border], 0, 3);
    int quality = (int)clampd(q[K_quality], 0, 2);

    /* ---- evaluate operators at t ---- */
    Frame f;
    f.w = w; f.h = h; f.mode = mode;
    f.do_fx = 0; f.gain = 1.0; f.kcol = 0.0; f.taps_n = 1; f.translate = 0; f.nearest = 0;

    Ev eb = {0, 0}, ec = {0, 0}, el = {0, 0};
    if (q[K_en_blur] != 0.0)  eb = ev_eval(&c.g, &c.op[K_BLUR], t);
    if (q[K_en_color] != 0.0) ec = ev_eval(&c.g, &c.op[K_COLOR], t);
    if (q[K_en_light] != 0.0) el = ev_eval(&c.g, &c.op[K_LIGHT], t);

    /* light */
    if (el.v > 1e-9) {
        double stops = el.v * clampd(q[K_light_amount], 0, 300) / 100.0 * 2.0;
        int beh = (int)clampd(q[K_light_behaviour], 0, 2);
        double sign = beh == 0 ? 1.0 : (beh == 1 ? -1.0 : (rnd(c.op[K_LIGHT].sV, el.slot, 2) < 0.5 ? -1.0 : 1.0));
        f.gain = exp2d(sign * stops);
        f.do_fx = stops > 1e-3;
    }
    /* colour */
    if (ec.v > 1e-9) {
        double hh, ss, vv, r, g, b;
        rgb2hsv(clampd(q[K_colorize], 0, 1), clampd(q[K_colorize + 1], 0, 1), clampd(q[K_colorize + 2], 0, 1), &hh, &ss, &vv);
        hh += (rnd(c.op[K_COLOR].sV, ec.slot, 2) - 0.5) * 360.0 * clampd(q[K_color_random], 0, 100) / 100.0;
        hsv2rgb(hh, ss, vv, &r, &g, &b);
        f.ccol[0] = r; f.ccol[1] = g; f.ccol[2] = b;
        f.kcol = dmin(1.0, ec.v * clampd(q[K_color_amount], 0, 200) / 100.0);
        if (f.kcol < 1e-3) f.kcol = 0.0;
        f.do_fx = f.do_fx || f.kcol > 0.0;
    }

    /* geometry: scale + slide, with shutter taps */
    double shutter = clampd(q[K_shutter_angle], 0, 720) / 360.0 / fps;
    double dts = shutter * clampd(q[K_scale_mb], 0, 100) / 100.0;
    double dtd = shutter * clampd(q[K_slide_mb], 0, 100) / 100.0;
    int geo = 0;
    f.taps[0].a = 1.0;
    {
        int sc_on = q[K_en_scale] != 0.0, sl_on = q[K_en_slide] != 0.0;
        double s0 = 1, ox0 = 0, oy0 = 0, dx0 = 0, dy0 = 0;
        if (sc_on) scale_state(&c, t, &s0, &ox0, &oy0);
        if (sl_on) slide_state(&c, t, &dx0, &dy0);
        /* does anything move within the shutter window? sample 5 points to size the tap count */
        double smin = s0, smax = s0, dxmin = dx0, dxmax = dx0, dymin = dy0, dymax = dy0;
        for (int m = 1; m <= 4; m++) {
            double fr = (double)m / 4.0, s1 = 1, ox1, oy1, dx1 = 0, dy1 = 0;
            if (sc_on && dts > 0) { scale_state(&c, t - dts * fr, &s1, &ox1, &oy1); smin = dmin(smin, s1); smax = dmax(smax, s1); }
            if (sl_on && dtd > 0) { slide_state(&c, t - dtd * fr, &dx1, &dy1); dxmin = dmin(dxmin, dx1); dxmax = dmax(dxmax, dx1); dymin = dmin(dymin, dy1); dymax = dmax(dymax, dy1); }
        }
        /* below 0.05 px of motion anywhere in the frame = nothing visible: skip the geometry pass */
        double diag0 = dsqrt(c.W * c.W + c.H * c.H) * 0.5, eps = 0.05;
        int moving_now = dabs2(s0 - 1.0) * diag0 > eps || dabs2(dx0) > eps || dabs2(dy0) > eps;
        int moving_win = dabs2(smax - 1.0) * diag0 > eps || dabs2(smin - 1.0) * diag0 > eps || dabs2(dxmax) > eps || dabs2(dxmin) > eps || dabs2(dymax) > eps || dabs2(dymin) > eps;
        if (moving_now || moving_win) {
            geo = 1;
            double split = c.slide_rgb;
            double diag = dsqrt(c.W * c.W + c.H * c.H);
            double span = dsqrt((dxmax - dxmin) * (dxmax - dxmin) + (dymax - dymin) * (dymax - dymin)) * (1.0 + split)
                        + (smax - smin) * 0.5 * diag;
            int nmax = quality == 0 ? 4 : (quality == 1 ? 8 : MAXTAPS);
            double spacing = quality == 0 ? 8.0 : (quality == 1 ? 4.0 : 2.0);
            int N = (int)clampd(dfloor(span * scale / spacing) + 1.0, 1.0, (double)nmax);
            f.taps_n = N;
            for (int j = 0; j < N; j++) {
                double fr = (double)j / (double)N;
                double s = 1, ox = c.scale_ox, oy = c.scale_oy, dx = 0, dy = 0;
                if (sc_on) scale_state(&c, t - dts * fr, &s, &ox, &oy);
                if (sl_on) slide_state(&c, t - dtd * fr, &dx, &dy);
                Tap *tp = &f.taps[j];
                double a = 1.0 / s;
                tp->a = a;
                tp->split = (split > 0.0) && (dx != 0.0 || dy != 0.0);
                for (int ch = 0; ch < 3; ch++) {
                    double kc = ch == 0 ? 1.0 + split : (ch == 1 ? 1.0 : 1.0 - split);
                    tp->bx[ch] = ox * (1.0 - a) - dx * kc * a;
                    tp->by[ch] = oy * (1.0 - a) - dy * kc * a;
                }
            }
            f.translate = 1;
            for (int j = 0; j < N; j++) if (f.taps[j].a != 1.0) f.translate = 0;
            /* nearest sampling: Draft always; Normal for motion-blur taps and pure slides (sub-pixel is invisible at twitch speed) */
            f.nearest = quality == 0 || (quality == 1 && (N > 1 || f.translate));
        }
    }

    int blur_on = eb.v > 1e-9;
    int any = geo || f.do_fx || blur_on;
    size_t npx = (size_t)w * (size_t)h;

    if (!any) {
        /* Show Twitch Only: a frame where nothing twitches (Time included, done by the Time Remap expression) goes transparent */
        int time_active = q[K_en_time] != 0.0 && ev_eval(&c.g, &c.op[K_TIME], t).v > 1e-9;
        if (q[K_twitch_only] != 0.0 && !time_active) { for (size_t i = 0; i < npx * 4; i++) px[i] = 0.0f; }
        return 0;
    }

    /* ---- blur sizing (needed for the arena) ---- */
    double radius = eb.v * clampd(q[K_blur_amount], 0, 200) * 0.5 * scale;
    double aspect = clampd(q[K_blur_aspect], -1, 1);
    int lens = q[K_blur_lens] != 0.0;
    double ax = 1.0 + dmin(aspect, 0.0), ay = 1.0 - dmax(aspect, 0.0);
    /* Gaussian sigma = radius/2; lens disc radius = radius. Big kernels run on a downsampled copy. */
    double big = lens ? radius * dmax(ax, ay) : radius * 0.5 * dmax(ax, ay);
    double thr = lens ? (quality == 0 ? 4.0 : (quality == 1 ? 6.0 : 16.0)) : (quality == 0 ? 2.0 : (quality == 1 ? 4.0 : 8.0));
    int k = 1;
    while (blur_on && k < 32 && big / k > thr && (w / (k * 2)) >= 2 && (h / (k * 2)) >= 2) k *= 2;
    int sw = (w + k - 1) / k, sh = (h + k - 1) / k;
    int drx = 0, dry = 0;
    if (lens) {
        drx = (int)dfloor(clampd(radius * ax / k, 0, 64) + 0.5);
        dry = (int)dfloor(clampd(radius * ay / k, 0, 64) + 0.5);
    }

    /* ---- scratch buffers from the arena (bounded: <= 1 full frame + 2 small frames + row scratch) ---- */
    uint64_t bytes = (uint64_t)npx * 16u;
    uint64_t sbytes = (uint64_t)sw * (uint64_t)sh * 16u;
    uint64_t start = ((uint64_t)(uintptr_t)px + bytes + 15u) & ~15ull;
    if ((uint64_t)g_main_end > start) start = g_main_end;
    uint64_t accb = (uint64_t)w * 48u;
    uint64_t ringb = (uint64_t)(2 * dry + 1) * (uint64_t)(sw + 2 * drx + 2) * 32u;
    if (ringb > accb) accb = ringb;
    float *S1 = 0, *A = 0, *B = 0;
    double *acc = 0;
    uint64_t top = start;
    if (top + bytes + 2 * sbytes + accb + 256 > 0x3F000000ull) return 2;
    if (geo) { S1 = (float *)(uintptr_t)top; top += bytes; }
    if (blur_on) { A = (float *)(uintptr_t)top; top += (sbytes + 15u) & ~15ull; B = (float *)(uintptr_t)top; top += (sbytes + 15u) & ~15ull; }
    acc = (double *)(uintptr_t)top; top += accb;
    if (!ensure_mem(top + 64)) return 2;

    /* ---- geometry (+ colour/light folded in) ---- */
    float *G;
    if (geo) {
        G = S1;
        /* near-axis slide streak (no RGB split): one sub-pixel shift + running-sum box along the axis.
           Exact line blur for horizontal/vertical motion, O(1) per pixel whatever the streak length.
           This is an exact continuous-motion box filter, so it is at least as accurate as discrete
           per-tap bilinear sampling - it is not gated on f.nearest (High quality used to skip it
           entirely, forcing a full O(N*w*h) bilinear pass per frame for every motion-blurred slide). */
        int streak = 0;
        if (f.translate && f.taps_n > 1) {
            double mnx = 1e300, mxx = -1e300, mny = 1e300, mxy = -1e300, sx = 0, sy = 0;
            int sp = 0;
            for (int j = 0; j < f.taps_n; j++) {
                const Tap *tp = &f.taps[j];
                sp |= tp->split;
                mnx = dmin(mnx, tp->bx[1]); mxx = dmax(mxx, tp->bx[1]); mny = dmin(mny, tp->by[1]); mxy = dmax(mxy, tp->by[1]);
                sx += tp->bx[1]; sy += tp->by[1];
            }
            double spx = mxx - mnx, spy = mxy - mny, big2 = dmax(spx, spy), small2 = dmin(spx, spy);
            if (!sp && big2 >= 2.0 && small2 <= 0.15 * big2 && big2 < 4.0 * (double)(w > h ? w : h)) {
                streak = 1;
                Frame f1 = f;
                f1.taps_n = 1; f1.nearest = 0;
                f1.taps[0].a = 1.0; f1.taps[0].split = 0;
                for (int ch = 0; ch < 3; ch++) { f1.taps[0].bx[ch] = sx / f.taps_n; f1.taps[0].by[ch] = sy / f.taps_n; }
                pass_translate(&f1, px, S1, acc, acc + (size_t)w * 4);      /* px is now free scratch */
                int r = (int)dfloor(big2 * 0.5 + 0.5);
                if (spx >= spy) box_h(S1, px, w, h, r, mode);
                else box_v(S1, px, acc, w, h, r, mode);
                G = px;
            }
        }
        if (!streak) {
            if (f.translate && f.nearest) pass_translate_nearest(&f, px, S1, acc, acc + (size_t)w * 4);
            else if (f.translate) pass_translate(&f, px, S1, acc, acc + (size_t)w * 4);
            else if (f.nearest) pass_geometry_nearest(&f, px, S1, acc, acc + (size_t)w * 4);
            else pass_geometry_rows(&f, px, S1, acc, acc + (size_t)w * 4);
        }
    } else {
        if (f.do_fx) pass_fx_inplace(&f, px);
        G = px;
    }

    if (!blur_on) {
        if (G != px) { for (size_t i = 0; i < npx * 4; i++) px[i] = G[i]; }
        return 0;
    }

    /* ---- blur: holdout-weighted k x k downsample -> kernel -> bilinear upsample + blend ---- */
    double H = clampd(q[K_blur_holdout], 0, 100) / 100.0;
    double soft = 1.0 - clampd(q[K_blur_holdout_sharp], 0, 100) / 100.0;
    double lo = H * (1.0 - soft), hi = H * (1.0 + soft);
    for (int yy = 0; yy < sh; yy++) {
        int y0 = yy * k, y1 = y0 + k < h ? y0 + k : h;
        for (int xx = 0; xx < sw; xx++) {
            int x0 = xx * k, x1 = x0 + k < w ? x0 + k : w;
            double a0 = 0, a1 = 0, a2 = 0, a3 = 0;
            for (int y = y0; y < y1; y++) {
                const float *row = G + ((size_t)y * w) * 4;
                for (int x = x0; x < x1; x++) {
                    const float *g = row + (size_t)x * 4;
                    double wgt = 1.0;
                    if (H > 0.0) wgt = smoothstep(lo, hi, 0.2126 * g[0] + 0.7152 * g[1] + 0.0722 * g[2]);
                    a0 += g[0] * wgt; a1 += g[1] * wgt; a2 += g[2] * wgt; a3 += g[3] * wgt;
                }
            }
            double inv = 1.0 / (double)((y1 - y0) * (x1 - x0));
            float *o = A + ((size_t)yy * sw + xx) * 4;
            o[0] = (float)(a0 * inv); o[1] = (float)(a1 * inv); o[2] = (float)(a2 * inv); o[3] = (float)(a3 * inv);
        }
    }
    float *cur = A, *oth = B;
    if (lens) {
        if (drx > 0 || dry > 0) { disc_blur(A, B, acc, sw, sh, drx, dry, mode); cur = B; oth = A; }
    } else {
        int passes = quality == 0 ? 1 : (quality == 1 ? 2 : 3);
        int rx[3] = {0, 0, 0}, ry[3] = {0, 0, 0};
        double sx = radius * 0.5 * ax / k, sy = radius * 0.5 * ay / k;
        if (sx >= 0.3) box_radii(sx, passes, rx);
        if (sy >= 0.3) box_radii(sy, passes, ry);
        for (int i = 0; i < passes; i++)
            if (rx[i] > 0) { box_h(cur, oth, sw, sh, rx[i], mode); float *t2 = cur; cur = oth; oth = t2; }
        for (int i = 0; i < passes; i++)
            if (ry[i] > 0) { box_v(cur, oth, acc, sw, sh, ry[i], mode); float *t2 = cur; cur = oth; oth = t2; }
    }
    /* cur = blurred (small) layer */
    double kb = clampd(clampd(q[K_blur_opacity], 0, 100) / 100.0 * dmin(1.0, eb.v), 0.0, 1.0);
    int bm = (int)clampd(q[K_blur_mode], 0, 5);
    double gainb = 1.0 + clampd(q[K_blur_boost], 0, 500) / 100.0;
    double tr = clampd(q[K_blur_tint], 0, 4) * gainb, tg = clampd(q[K_blur_tint + 1], 0, 4) * gainb, tb = clampd(q[K_blur_tint + 2], 0, 4) * gainb;
    double invk = 1.0 / (double)k, bo[4];
    /* separable bilinear upsample: per-column taps computed once (acc has >= 6 doubles per column) */
    double *xt = acc;
    int32_t *xa = (int32_t *)(acc + w), *xb = xa + w;
    for (int x = 0; x < w; x++) {
        double fx = ((double)x + 0.5) * invk - 0.5, f0 = dfloor(fx);
        int x0 = (int)clampd(f0, 0.0, (double)(sw - 1));
        double tx = fx - f0;
        if (fx <= 0.0) tx = 0.0;
        if (x0 >= sw - 1) { x0 = sw - 1; tx = 0.0; }
        xt[x] = tx; xa[x] = x0; xb[x] = x0 + 1 < sw ? x0 + 1 : x0;
    }
    for (int y = 0; y < h; y++) {
        double fy = ((double)y + 0.5) * invk - 0.5, f0 = dfloor(fy);
        int y0 = (int)clampd(f0, 0.0, (double)(sh - 1));
        double ty = fy - f0;
        if (fy <= 0.0) ty = 0.0;
        if (y0 >= sh - 1) { y0 = sh - 1; ty = 0.0; }
        int y1 = y0 + 1 < sh ? y0 + 1 : y0;
        const float *r0 = cur + (size_t)y0 * sw * 4, *r1 = cur + (size_t)y1 * sw * 4;
        for (int x = 0; x < w; x++) {
            size_t i = (size_t)y * w + x;
            const float *g = G + i * 4;
            if (k == 1) { const float *b = cur + i * 4; bo[0] = b[0]; bo[1] = b[1]; bo[2] = b[2]; bo[3] = b[3]; }
            else {
                const float *p00 = r0 + (size_t)xa[x] * 4, *p10 = r0 + (size_t)xb[x] * 4, *p01 = r1 + (size_t)xa[x] * 4, *p11 = r1 + (size_t)xb[x] * 4;
                double tx = xt[x];
                for (int c2 = 0; c2 < 4; c2++) {
                    double top = p00[c2] + (p10[c2] - p00[c2]) * tx, bot = p01[c2] + (p11[c2] - p01[c2]) * tx;
                    bo[c2] = top + (bot - top) * ty;
                }
            }
            float *o = px + i * 4;  /* px may alias G: same-index in-place is safe */
            double ga = g[3];
            double ra = ga + (bo[3] - ga) * kb;
            double c0, c1, c2b;
            if (bm == 0) {
                c0 = g[0] + (bo[0] * tr - g[0]) * kb; c1 = g[1] + (bo[1] * tg - g[1]) * kb; c2b = g[2] + (bo[2] * tb - g[2]) * kb;
            } else {
                ra = dmax(ra, ga);
                c0 = blend_ch(bm, g[0], bo[0] * tr, kb); c1 = blend_ch(bm, g[1], bo[1] * tg, kb); c2b = blend_ch(bm, g[2], bo[2] * tb, kb);
            }
            o[0] = (float)c0; o[1] = (float)c1; o[2] = (float)c2b; o[3] = (float)ra;
        }
    }
    return 0;
}
