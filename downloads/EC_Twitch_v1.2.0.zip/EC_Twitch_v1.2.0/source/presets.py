"""EC Twitch preset definitions -> presets.json (consumed by the harness, which writes real .ecpreset files).

Twitch ships 25 effect presets (Toolfarm product page). Their names/values are not public except a partial
dump of two ("Transition Side Swiped", "Crazy Man"), reconstructed below. The other 23 are original presets
covering the same jobs (transitions, flicker, shake, glitch, colour, blur, time).

Every preset wires: Time (s) <- `time - thisLayer.startTime`, Frame Rate <- comp frame rate.
"keys": Amount keyframes (seconds, relative) for drop-on-the-cut transitions.
"time_remap": also writes the Time operator expression onto Time Remap (layer needs Time Remapping enabled).
"""
import json, os

T = [[0.0, 0.0], [0.2, 100.0], [0.4, 0.0]]          # 12-frame transition at 30 fps, peak on the cut
ORANGE = [1.0, 0.635, 0.0, 1.0]

P = [
    ("Setup (Defaults)", {}, None, False),

    # --- reconstructed from the public dump (values partially known) ---
    ("Transition Side Swiped", dict(speed=10, en_slide=1, en_blur=1, en_light=1, slide_amount=100, slide_dir=90, slide_spread=0,
        slide_mb=100, light_amount=125, color_amount=50, colorize=ORANGE, blur_amount=50, blur_aspect=1), T, False),
    ("Crazy Man", dict(speed=25, en_blur=1, en_color=1, en_light=1, en_scale=1, en_slide=1, color_amount=155, color_random=27,
        colorize=ORANGE, light_amount=153, light_rate=6.6, slide_dir=0, slide_spread=1, slide_rgb=21), None, False),

    # --- transitions (Amount keyed 0 -> 100 -> 0 around the cut) ---
    ("Transition Glitch Hit", dict(speed=15, en_slide=1, en_color=1, en_blur=1, slide_amount=40, slide_dir=90, slide_spread=0.2,
        slide_rgb=80, slide_mb=30, color_amount=100, color_random=100, blur_amount=30, blur_aspect=1, ease_in=0, ease_out=0), T, False),
    ("Transition Flash Cut", dict(speed=12, en_light=1, en_blur=1, light_amount=250, blur_amount=80, blur_mode=1, blur_boost=50,
        ease_in=0, ease_out=2), T, False),
    ("Transition Zoom Punch", dict(speed=8, en_scale=1, en_blur=1, en_light=1, scale_amount=120, blur_amount=40, light_amount=80,
        ease_in=1, ease_out=3), T, False),
    ("Transition Whip Left", dict(speed=8, en_slide=1, en_blur=1, slide_amount=150, slide_dir=270, slide_spread=0, slide_tendency=1,
        blur_amount=60, blur_aspect=1, ease_in=1, ease_out=2), T, False),
    ("Transition Whip Up", dict(speed=8, en_slide=1, en_blur=1, slide_amount=150, slide_dir=0, slide_spread=0, slide_tendency=1,
        blur_amount=60, blur_aspect=-1, ease_in=1, ease_out=2), T, False),

    # --- light ---
    ("Strobe Light", dict(speed=12, en_light=1, light_behaviour=2, light_amount=200, ease_in=0, ease_out=0, rand_min=60), None, False),
    ("Fluorescent Flicker", dict(speed=4, light_rate=3, en_light=1, light_behaviour=1, light_amount=150, ease_in=0, ease_out=0,
        rand_min=30), None, False),
    ("Neon Flicker", dict(speed=6, en_light=1, light_behaviour=2, light_amount=120, en_color=1, color_amount=60,
        colorize=[0.0, 0.9, 1.0, 1.0], ease_in=0, ease_out=0, rand_min=20), None, False),
    ("Paparazzi Flash", dict(speed=2, light_rate=2, en_light=1, light_amount=300, ease_in=0, ease_out=3, hold_frames=0, rand_min=50,
        en_blur=1, blur_amount=15, blur_mode=1, blur_boost=100), None, False),

    # --- motion ---
    ("Camera Shake", dict(speed=15, en_slide=1, slide_amount=6, slide_spread=1, en_scale=1, scale_amount=4), None, False),
    ("Earthquake", dict(speed=20, en_slide=1, slide_amount=15, slide_spread=1, en_scale=1, scale_amount=10, scale_origin_rand=50,
        en_blur=1, blur_amount=10), None, False),
    ("Heartbeat Pulse", dict(speed=1.2, en_scale=1, scale_amount=25, scale_mb=50, en_light=1, light_amount=40, ease_in=1, ease_out=4,
        hold_frames=0), None, False),
    ("Beat Bounce", dict(speed=2, en_scale=1, scale_amount=35, en_light=1, light_amount=50, ease_in=0, ease_out=5, hold_frames=0,
        rand_min=70), None, False),

    # --- glitch / colour ---
    ("RGB Jitter", dict(speed=12, en_slide=1, slide_amount=4, slide_spread=1, slide_rgb=100, slide_mb=0, ease_in=0, ease_out=0), None, False),
    ("VHS Damage", dict(speed=8, en_slide=1, slide_amount=8, slide_dir=90, slide_spread=0.05, slide_rgb=60, slide_mb=0, en_blur=1,
        blur_amount=25, blur_aspect=1, en_color=1, color_amount=40, colorize=[1.0, 0.2, 0.8, 1.0], color_random=30, ease_in=0,
        ease_out=1), None, False),
    ("Color Pop", dict(speed=4, en_color=1, color_amount=120, color_random=100, ease_in=0, ease_out=2), None, False),
    ("Signal Fragments", dict(speed=3, twitch_only=1, en_slide=1, slide_amount=20, slide_spread=1, slide_rgb=50, en_light=1,
        light_behaviour=1, light_amount=100, ease_in=0, ease_out=0, hold_frames=2), None, False),

    # --- blur ---
    ("Blur Pulse", dict(speed=2, en_blur=1, blur_amount=60, ease_in=3, ease_out=5, hold_frames=2), None, False),
    ("Dream Glow", dict(speed=1.5, en_blur=1, blur_amount=120, blur_mode=2, blur_holdout=50, blur_holdout_sharp=30, blur_boost=100,
        blur_tint=[1.0, 0.85, 0.7, 1.0], ease_in=6, ease_out=8, hold_frames=3, en_light=1, light_amount=30), None, False),
    ("Bokeh Hits", dict(speed=3, en_blur=1, blur_lens=1, blur_amount=80, blur_holdout=30, ease_in=1, ease_out=3), None, False),

    # --- time (need Time Remapping on the layer) ---
    ("Time Stutter", dict(speed=6, en_time=1, time_amount=40, ease_in=0, ease_out=0, hold_frames=2, en_slide=1, slide_amount=3,
        slide_spread=1), None, True),
    ("Rewind Glitch", dict(speed=3, en_time=1, time_amount=80, time_dir=2, ease_in=0, ease_out=0, hold_frames=4, en_slide=1,
        slide_amount=5, slide_dir=90, slide_spread=0.3, slide_rgb=60, en_color=1, color_amount=60, color_random=100), None, True),

    # --- everything ---
    ("Total Chaos", dict(speed=30, en_blur=1, en_color=1, en_light=1, en_scale=1, en_slide=1, en_time=1, color_random=100,
        light_behaviour=2, slide_spread=1, slide_rgb=40, scale_origin_rand=60, time_amount=30), None, True),
]

assert len([p for p in P if not p[0].startswith("Setup")]) == 25, len(P)
out = [{"name": "EC Twitch - " + n, "params": p, "amountKeys": k, "timeRemap": tr} for n, p, k, tr in P]
out.append({"name": "EC Twitch - Time Remap (apply to a layer with Time Remapping)", "params": None, "amountKeys": None, "timeRemap": True})
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "presets.json"), "w") as f:
    json.dump(out, f, indent=1)
print(len(out), "preset definitions")
