@echo off
setlocal
title Install Slizzy Neon Outline v3
echo Installing Slizzy Neon Outline v3 for EffectCraft...
echo.
if not exist "%~dp01_Plugin\ec_slizzy_neon.wasm" (
  echo Could not find 1_Plugin\ec_slizzy_neon.wasm.
  echo Unzip the whole zip first, then double-click this file again.
  pause
  exit /b 1
)
set "PLUG=%APPDATA%\EffectCraft\Plug-ins"
if not exist "%PLUG%" mkdir "%PLUG%"
copy /Y "%~dp01_Plugin\ec_slizzy_neon.wasm" "%PLUG%\" >nul || goto fail
echo   Plug-in copied to:  %PLUG%
echo.
echo Done. Restart EffectCraft, then search "Slizzy Neon Outline v3" in Effects ^& Presets.
echo.
pause
exit /b 0
:fail
echo.
echo Something went wrong while copying. Copy the files by hand: see INSTALL.txt.
pause
exit /b 1
