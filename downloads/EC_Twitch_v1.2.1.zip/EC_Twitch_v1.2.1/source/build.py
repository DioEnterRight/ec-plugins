#!/usr/bin/env python3
"""Builds ec_twitch.wasm.

Single source of truth for the parameter list lives here. Running this script:
  1. writes manifest.json
  2. writes params_gen.h (flattened-f64 indices + embedded manifest string)
  3. compiles ec_twitch.c -> ec_twitch.wasm (no imports, MVP instructions only)
"""
import json, subprocess, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))

params = []

def slider(id, name, default, mn, mx, smax=None, dec=2):
    d = {"id": id, "name": name, "type": "slider", "default": default, "min": mn, "max": mx, "decimals": dec}
    if smax is not None:
        d["sliderMax"] = smax
    params.append(d)

def check(id, name, default=False):
    params.append({"id": id, "name": name, "type": "checkbox", "default": default})

def popup(id, name, options, default=0):
    params.append({"id": id, "name": name, "type": "popup", "options": options, "default": default})

def angle(id, name, default=0):
    params.append({"id": id, "name": name, "type": "angle", "default": default})

def point(id, name, default):
    params.append({"id": id, "name": name, "type": "point", "default": default})

def color(id, name, default):
    params.append({"id": id, "name": name, "type": "color", "default": default})

def seed(id, name):
    slider(id, name, 0, 0, 10000, dec=0)

# ---------------------------------------------------------------- global
slider("clock", "Time (s)", 0, -100000, 100000, dec=4)
slider("amount", "Amount", 100, 0, 1000, 100)
slider("speed", "Speed", 10, 0, 1000, 100)
check("en_blur", "Blur", True)
check("en_color", "Color", True)
check("en_light", "Light", True)
check("en_scale", "Scale", True)
check("en_slide", "Slide", True)
check("en_time", "Time")
slider("ease_in", "Ease In", 1, 0, 10)
slider("ease_out", "Ease Out", 1, 0, 10)
popup("border", "Border", ["Mirror", "Tile", "Ignore", "Expand"], 0)
check("twitch_only", "Show Twitch Only")
seed("seed", "Seed")
slider("rand_min", "Randomize Minimum", 0, 0, 100)
check("freeze", "Freeze Twitch")
slider("freeze_time", "Freeze Time (s)", 0, 0, 100000, dec=3)
# ---------------------------------------------------------------- blur
slider("blur_amount", "Blur Amount", 50, 0, 200)
slider("blur_rate", "Blur Twitches [sec]", 1, 0, 10)
color("blur_tint", "Blur Tint", [1.0, 1.0, 1.0, 1.0])
slider("blur_holdout", "Blur Holdout", 0, 0, 100)
slider("blur_holdout_sharp", "Blur Holdout Sharpness", 50, 0, 100)
slider("blur_boost", "Blur Boost", 0, 0, 500)
slider("blur_opacity", "Blur Opacity", 100, 0, 100)
popup("blur_mode", "Blur Transfer Mode", ["Normal", "Add", "Screen", "Multiply", "Overlay", "Lighten"], 0)
slider("blur_aspect", "Blur Aspect", 0, -1, 1)
check("blur_lens", "Use Lens Blur")
seed("blur_seed", "Unique Blur Seed")
# ---------------------------------------------------------------- color
slider("color_amount", "Color Amount", 50, 0, 200)
slider("color_rate", "Color Twitches [sec]", 1, 0, 10)
color("colorize", "Colorize", [1.0, 0.635, 0.0, 1.0])
slider("color_random", "Color Randomize", 0, 0, 100)
seed("color_seed", "Unique Color Seed")
# ---------------------------------------------------------------- light
slider("light_amount", "Light Amount", 100, 0, 300)
slider("light_rate", "Light Twitches [sec]", 1, 0, 20)
popup("light_behaviour", "Light Behaviour", ["Brighter", "Darker", "Both"], 0)
seed("light_seed", "Unique Light Seed")
# ---------------------------------------------------------------- scale
slider("scale_amount", "Scale Amount", 50, -200, 200)
slider("scale_rate", "Scale Twitches [sec]", 1, 0, 10)
point("scale_origin", "Scale Origin", [0.5, 0.5])
slider("scale_origin_rand", "Scale Origin Randomize", 0, 0, 100)
slider("scale_mb", "Scale Motion Blur", 100, 0, 100)
seed("scale_seed", "Unique Scale Seed")
# ---------------------------------------------------------------- slide
slider("slide_amount", "Slide Amount", 50, 0, 200)
slider("slide_rate", "Slide Twitches [sec]", 1, 0, 10)
angle("slide_dir", "Slide Direction", 0)
slider("slide_spread", "Slide Spread", 0, 0, 1)
slider("slide_tendency", "Slide Tendency", 0, -1, 1)
slider("slide_rgb", "Slide RGB Split", 0, 0, 100)
slider("slide_mb", "Slide Motion Blur", 100, 0, 100)
seed("slide_seed", "Unique Slide Seed")
# ---------------------------------------------------------------- time (rendered by the Time Remap expression, see TIME_EXPR)
slider("time_amount", "Time Amount", 50, 0, 100)
slider("time_rate", "Time Twitches [sec]", 1, 0, 10)
popup("time_dir", "Time Direction", ["Both", "Forward Only", "Backward Only"], 0)
seed("time_seed", "Unique Time Seed")
# ---------------------------------------------------------------- extended (not in original Twitch)
slider("frame_rate", "Frame Rate", 30, 1, 240, dec=2)
slider("shutter_angle", "Shutter Angle", 180, 0, 720, 360, dec=1)
popup("quality", "Quality", ["Draft", "Normal", "High"], 1)
slider("hold_frames", "Hold Frames", 1, 0, 10, dec=1)

manifest = {
    "api": 1,
    "id": "org.dexter.ec-twitch",
    "name": "EC Twitch",
    "category": "Stylize",
    "version": "1.2.1",
    "author": "DioEnterRight",
    "description": "Synchronized random Blur / Color / Light / Scale / Slide / Time twitches (clean-room behavioural clone of Twitch). Time works through the EC Twitch Time Remap expression preset.",
    "params": params,
}

# ---------------------------------------------------------------- panel layout (1.2.0)
# API v1 has no folding groups, so each section starts with a do-nothing header checkbox.
_by = {p["id"]: p for p in params}
_layout = [
    ("hdr_master", "MASTER CONTROLS", ["amount", "speed"]),
    ("hdr_enable", "ENABLE / OPERATORS", ["en_blur", "en_color", "en_light", "en_scale", "en_slide", "en_time"]),
    ("hdr_behavior", "BEHAVIOR", ["ease_in", "ease_out", "hold_frames", "border", "twitch_only", "seed", "rand_min", "freeze", "freeze_time",
                                  "frame_rate", "shutter_angle", "quality", "clock"]),
]
for _op in ["blur", "color", "light", "scale", "slide", "time"]:
    _layout.append(("hdr_" + _op, _op.upper() + " CONTROLS", [p["id"] for p in params if p["id"].startswith(_op + "_") or (_op == "color" and p["id"] == "colorize")]))
_new, _used = [], []
for _hid, _title, _ids in _layout:
    _new.append({"id": _hid, "name": "=== %s ===" % _title, "type": "checkbox", "default": False})
    _new += [_by[i] for i in _ids]; _used += _ids
assert sorted(_used) == sorted(_by), set(_by) ^ set(_used)
params[:] = _new

# ---------------------------------------------------------------- companion expressions
# Clock: makes the layer cache re-render every frame (EffectCraft API v1 caches plug-ins by params only).
CLOCK_EXPR = "time - thisLayer.startTime"
FPS_EXPR = "1 / thisComp.frameDuration"
POPUP_BASE = int(os.environ.get("EC_POPUP_BASE", "1"))   # verified in EffectCraft: popups read 1-based in expressions (AE style)
# Time operator: Time Remap expression that mirrors ec_twitch.c ev_eval()/time_offset() exactly.
TIME_EXPR = """// EC Twitch - Time operator. Needs Time Remapping on this layer and an "EC Twitch" effect.
var fx = effect("EC Twitch");
function P(n) { var v = fx(n).value; return v === true ? 1 : (v === false ? 0 : Number(v)); }
function cl(x, a, b) { return x < a ? a : (x > b ? b : x); }
function pcg(x, y, z) {
  x = (Math.imul(x, 1664525) + 1013904223) >>> 0; y = (Math.imul(y, 1664525) + 1013904223) >>> 0; z = (Math.imul(z, 1664525) + 1013904223) >>> 0;
  x = (x + Math.imul(y, z)) >>> 0; y = (y + Math.imul(z, x)) >>> 0; z = (z + Math.imul(x, y)) >>> 0;
  x = (x ^ (x >>> 16)) >>> 0; y = (y ^ (y >>> 16)) >>> 0; z = (z ^ (z >>> 16)) >>> 0;
  x = (x + Math.imul(y, z)) >>> 0; y = (y + Math.imul(z, x)) >>> 0; z = (z + Math.imul(x, y)) >>> 0;
  return x;
}
function rnd(s, i, n) { return pcg(s >>> 0, i >>> 0, n >>> 0) / 4294967296; }
function e01(x) { x = cl(x, 0, 1); return x * x * (3 - 2 * x); }
var off = 0;
if (P("Time") != 0) {
  var c0 = P("Time (s)"), tt = c0 != 0 ? c0 : time - thisLayer.startTime;
  if (P("Freeze Twitch") != 0) tt = P("Freeze Time (s)");
  var fps = cl(P("Frame Rate"), 1, 240), fd = 1 / fps;
  var amount = cl(P("Amount"), 0, 1000) / 100, rmin = cl(P("Randomize Minimum"), 0, 100) / 100;
  var att = cl(P("Ease In"), 0, 10) * fd, rel = cl(P("Ease Out"), 0, 10) * fd, hold = cl(P("Hold Frames"), 0, 10) * fd;
  if (att + hold + rel <= 0) hold = fd;
  var len = att + hold + rel;
  var seed = Math.floor(cl(P("Seed"), 0, 1e6)), uniq = Math.floor(cl(P("Unique Time Seed"), 0, 1e6));
  var rate = cl(cl(P("Speed"), 0, 1000) * cl(P("Time Twitches [sec]"), 0, 100), 0, 2000);
  var sV = pcg(seed, uniq, 4102), sT = uniq == 0 ? pcg(seed, 12648430, 0) : pcg(seed, uniq, 8198);
  if (rate > 0 && amount > 0) {
    var T = 1 / rate, jmax = cl(Math.floor(tt * rate), -2e9, 2e9), jmin = cl(Math.floor((tt - len) * rate) - 1, -2e9, 2e9);
    if (jmin < jmax - 63) jmin = jmax - 63;
    var bv = 0, bs = 0;
    for (var j = jmin; j <= jmax; j++) {
      var dt = tt - (j + rnd(sT, j, 0)) * T, env = 0;
      if (dt >= 0 && dt < len) {
        if (dt < att) env = e01(dt / att);
        else { var r = dt - att - hold; env = r < 0 ? 1 : (rel > 0 ? e01(1 - r / rel) : 0); }
      }
      if (env <= 0) continue;
      var v = amount * (rmin + (1 - rmin) * rnd(sV, j, 1)) * env;
      if (v > bv) { bv = v; bs = j; }
    }
    if (bv > 1e-9) {
      var dir = Math.floor(cl(P("Time Direction") - POPUP_BASE, 0, 2));
      var sg = dir == 1 ? 1 : (dir == 2 ? -1 : (rnd(sV, bs, 2) < 0.5 ? -1 : 1));
      off = Math.floor(sg * bv * cl(P("Time Amount"), 0, 100) / 100 * fps + 0.5) / fps;
    }
  }
}
value + off""".replace("POPUP_BASE", str(POPUP_BASE))
assert 0x1000 + 6 == 4102 and 0xC0FFEE == 12648430 and 0x2000 + 6 == 8198

# ---------------------------------------------------------------- validate against the EffectCraft v1 manifest rules
ids = set()
for p in params:
    assert all(c.isalnum() or c == "_" for c in p["id"]), p["id"]
    assert p["id"] not in ids, "dup " + p["id"]
    ids.add(p["id"])
    if p["type"] == "slider":
        assert p["min"] <= p["default"] <= p["max"], p["id"]
        if "sliderMax" in p:
            assert p["sliderMax"] <= p["max"], p["id"]
assert len(params) <= 256
text = json.dumps(manifest, separators=(",", ":"))
assert text.isascii() and len(text) < 1 << 20

with open(os.path.join(HERE, "manifest.json"), "w") as f:
    json.dump(manifest, f, indent=2)
with open(os.path.join(HERE, "expressions.json"), "w") as f:
    json.dump({"clock": CLOCK_EXPR, "frameRate": FPS_EXPR, "timeRemap": TIME_EXPR}, f, indent=2)

# ---------------------------------------------------------------- flattened index header
widths = {"point": 2, "color": 4}
idx = 0
lines = ["/* generated by build.py - do not edit */", "#pragma once"]
for p in params:
    lines.append("#define K_%s %d" % (p["id"], idx))
    idx += widths.get(p["type"], 1)
lines.append("#define NPARAMS %d" % idx)
esc = text.replace("\\", "\\\\").replace('"', '\\"')
lines.append('static const char MANIFEST[] = "%s";' % esc)
with open(os.path.join(HERE, "params_gen.h"), "w") as f:
    f.write("\n".join(lines) + "\n")
print("params: %d declared, %d flattened f64" % (len(params), idx))

# ---------------------------------------------------------------- compile
out = os.path.join(HERE, "ec_twitch.wasm")
cmd = [
    "clang", "--target=wasm32", "-mcpu=mvp", "-O2", "-Wall", "-Wextra",
    "-ffreestanding", "-fno-builtin", "-nostdlib", "-fuse-ld=lld",
    "-Wl,--no-entry", "-Wl,--strip-all", "-Wl,-z,stack-size=262144",
    os.path.join(HERE, "ec_twitch.c"), "-o", out,
]
if "--no-compile" not in sys.argv:
    subprocess.check_call(cmd)
    print("wrote", out, os.path.getsize(out), "bytes")
